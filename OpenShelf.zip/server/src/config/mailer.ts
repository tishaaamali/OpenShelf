
import nodemailer from "nodemailer";

const {
  SMTP_HOST,
  SMTP_PORT,
  SMTP_USER,
  SMTP_PASS,
  MAIL_FROM,
} = process.env;

if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS || !MAIL_FROM) {
  throw new Error("Missing SMTP settings in backend .env file");
}

export const mailer = nodemailer.createTransport({
  host: SMTP_HOST,
  port: Number(SMTP_PORT),
  secure: false,
  auth: {
    user: SMTP_USER,
    pass: SMTP_PASS,
  },
});

export async function sendPasswordResetEmail(
  email: string,
  resetUrl: string,
): Promise<void> {
  await mailer.sendMail({
    from: MAIL_FROM,
    to: email,
    subject: "Reset your OpenShelf password",
    text: `You requested a password reset for OpenShelf.

Click this link to reset your password:
${resetUrl}

This link expires in 15 minutes. If you did not request this, ignore this email.`,
    html: `
      <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:24px">
        <h2>Reset your OpenShelf password</h2>
        <p>Click below to choose a new password.</p>
        <a href="${resetUrl}"
           style="display:inline-block;background:#2563eb;color:white;padding:12px 20px;text-decoration:none;border-radius:8px">
          Reset Password
        </a>
        <p>This link expires in 15 minutes.</p>
        <p>If you did not request this, ignore this email.</p>
      </div>
    `,
  });
}
