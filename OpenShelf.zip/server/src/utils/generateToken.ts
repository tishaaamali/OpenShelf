import jwt from "jsonwebtoken";
import { UserRole } from "../types";

export function generateToken(id: string, role: UserRole): string {
  const secret = process.env.JWT_SECRET as string;
  return jwt.sign({ id, role }, secret, { expiresIn: "7d" });
}
