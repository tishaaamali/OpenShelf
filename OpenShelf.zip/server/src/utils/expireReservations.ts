import { Book } from "../models/Book";
import { BookRequest } from "../models/BookRequest";

/**
 * Releases expired reservations and marks their pending request records expired.
 * Optional filters let callers clean up a particular user/book before creating a request.
 */
export async function expireReservations(filter: { user?: unknown; book?: unknown; token?: unknown } = {}) {
  const now = new Date();
  const query: any = { status: "Pending", expiresAt: { $lte: now } };
  if (filter.user) query.user = filter.user;
  if (filter.book) query.book = filter.book;
  if (filter.token) query.token = filter.token;

  const expired = await BookRequest.find(query).select("_id user book copyId");
  if (!expired.length) return 0;

  const expiredIds = expired.map((r) => r._id);
  await BookRequest.updateMany(
    { _id: { $in: expiredIds }, status: "Pending" },
    { $set: { status: "Expired" } }
  );

  for (const request of expired) {
    const book = await Book.findById(request.book);
    if (!book) continue;
    const copy = book.copies.find((c: any) =>
      c._id?.toString() === request.copyId?.toString()
    );
    if (
      copy &&
      copy.status === "Reserved" &&
      copy.reservedBy?.toString() === request.user.toString()
    ) {
      copy.status = "Available";
      copy.reservedBy = null;
      copy.reservedUntil = null;
      book.syncStatus();
      await book.save();
    }
  }
  return expired.length;
}
