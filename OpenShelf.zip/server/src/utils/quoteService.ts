import { Types } from "mongoose";
import { Quote, normaliseQuoteText } from "../models/Quote";
import { Book } from "../models/Book";

// Only the book fields a quote card needs: availability is derived from
// copies[].status, so full copy records are never sent to the client.
export const QUOTE_BOOK_FIELDS =
  "title author category coverImage isbn13 isbn10 copies.status copies.borrowedBy waitlist.user";

export const escapeRegex = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function shapeBook(book: any, userId: string) {
  // Book removed from the catalogue (or never linked): no link, no borrow button.
  if (!book || !book._id) return null;
  const copies: any[] = Array.isArray(book.copies) ? book.copies : [];
  const waitlist: any[] = Array.isArray(book.waitlist) ? book.waitlist : [];
  const available = copies.filter((c) => c.status === "Available");
  return {
    _id: book._id,
    title: book.title,
    author: book.author,
    category: book.category,
    coverImage: book.coverImage,
    isbn13: book.isbn13 || "",
    isbn10: book.isbn10 || "",
    availableCount: available.length,
    availableCopyId: available[0]?._id || null,
    waitlistCount: waitlist.length,
    onWaitlist: waitlist.some((w) => w.user?.toString() === userId),
    haveIt: copies.some(
      (c) => c.status === "Borrowed" && c.borrowedBy?.toString() === userId
    ),
  };
}

export function shapeQuote(q: any, userId: string, liked: boolean) {
  const book = shapeBook(q.book, userId);
  return {
    _id: q._id,
    text: q.text,
    author: q.author || book?.author || "",
    sourceTitle: q.sourceTitle || book?.title || "",
    attribution: q.attribution || "",
    kind: q.kind || "member",
    page: q.page || "",
    addedByName: q.addedByName || "OpenShelf",
    mine: Boolean(q.addedBy) && q.addedBy.toString() === userId,
    likeCount: q.likeCount || 0,
    liked,
    createdAt: q.createdAt,
    book,
  };
}

// Turns lean quote documents (with `book` populated, `likes` excluded) into
// API objects. Whether the current user liked each quote is answered with ONE
// extra indexed query for the whole page, so the likes arrays are never loaded.
export async function hydrateQuotes(docs: any[], userId: string, allLiked = false) {
  if (docs.length === 0) return [];
  let likedIds = new Set<string>();
  if (!allLiked) {
    const rows = await Quote.find({
      _id: { $in: docs.map((d) => d._id) },
      likes: new Types.ObjectId(userId),
    })
      .select("_id")
      .lean();
    likedIds = new Set(rows.map((r: any) => r._id.toString()));
  }
  return docs.map((d) => shapeQuote(d, userId, allLiked || likedIds.has(d._id.toString())));
}

// The single place where a like / save is applied. One atomic update adds or
// removes the user from `likes` and recomputes `likeCount`, so repeated clicks,
// retries and concurrent requests can never create duplicates or drift.
export async function setQuoteLike(
  quoteId: string | Types.ObjectId,
  userId: string | Types.ObjectId,
  liked: boolean
): Promise<{ liked: boolean; likeCount: number } | null> {
  const _id = new Types.ObjectId(String(quoteId));
  const uid = new Types.ObjectId(String(userId));
  const current = { $ifNull: ["$likes", []] };

  const result = await Quote.updateOne({ _id }, [
    {
      $set: {
        likes: liked
          ? { $setUnion: [current, [uid]] }
          : { $setDifference: [current, [uid]] },
      },
    },
    { $set: { likeCount: { $size: "$likes" } } },
  ] as any);
  if (!result.matchedCount) return null;

  const doc: any = await Quote.findById(_id).select("likeCount").lean();
  return { liked, likeCount: doc?.likeCount ?? 0 };
}

// Idempotent upgrade for quotes created before pagination / attribution
// existed. Safe to run on every start; it only touches documents that need it.
export async function ensureQuoteData() {
  // Older quotes have no `kind`; without it the "From readers" filter would miss them.
  await Quote.updateMany({ kind: { $exists: false } }, { $set: { kind: "member" } });

  await Quote.updateMany({ likeCount: { $exists: false } }, [
    { $set: { likeCount: { $size: { $ifNull: ["$likes", []] } } } },
  ] as any);

  const legacy = Quote.find({
    $or: [{ textKey: { $exists: false } }, { kind: { $exists: false } }, { author: { $exists: false } }],
  })
    .populate("book", "title author")
    .cursor();

  for await (const doc of legacy as any) {
    const set: Record<string, unknown> = {};
    if (!doc.textKey) set.textKey = normaliseQuoteText(doc.text);
    if (!doc.kind) set.kind = "member";
    if (doc.author === undefined || doc.author === "") set.author = doc.book?.author || "";
    if (doc.sourceTitle === undefined || doc.sourceTitle === "") set.sourceTitle = doc.book?.title || "";
    if (Object.keys(set).length === 0) continue;
    try {
      await Quote.updateOne({ _id: doc._id }, { $set: set });
    } catch (err: any) {
      // Two legacy quotes with identical text: keep both, skip the duplicate key.
      if (err?.code === 11000 && "textKey" in set) {
        delete set.textKey;
        if (Object.keys(set).length) await Quote.updateOne({ _id: doc._id }, { $set: set });
      } else {
        throw err;
      }
    }
  }
}

export async function findBookIdsByTitle(titles: string[]) {
  const books = await Book.find({ title: { $in: titles } }).select("_id title").lean();
  return new Map<string, Types.ObjectId>(
    books.map((b: any) => [b.title as string, b._id as Types.ObjectId])
  );
}
