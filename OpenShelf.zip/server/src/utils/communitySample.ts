import { Types } from "mongoose";
import { User, IUser } from "../models/User";
import { Book } from "../models/Book";
import { Discussion } from "../models/Discussion";
import { ReadingList } from "../models/ReadingList";
import { Notification } from "../models/Notification";
import { CURATED_QUOTES, seedCuratedQuotes } from "./quoteSeed";
import { setQuoteLike } from "./quoteService";
import { Quote, normaliseQuoteText } from "../models/Quote";

// Sample content for the community features (discussion rooms, reading lists,
// book highlights, notifications). Safe to run more than once: every item is
// created only if it doesn't exist yet, so nothing is duplicated and no
// existing data is touched.
//
// Quotes come from quoteSeed.ts (public-domain excerpts and original lines).

type Key = "admin" | "demo" | "aarav" | "meera" | "kabir" | "diya";

const MEMBERS: { key: Exclude<Key, "admin">; name: string; first: string; last: string; email: string }[] = [
  { key: "demo", name: "Demo Member", first: "Demo", last: "Member", email: "member@openshelf.com" },
  { key: "aarav", name: "Aarav Shah", first: "Aarav", last: "Shah", email: "aarav@openshelf.com" },
  { key: "meera", name: "Meera Patel", first: "Meera", last: "Patel", email: "meera@openshelf.com" },
  { key: "kabir", name: "Kabir Mehta", first: "Kabir", last: "Mehta", email: "kabir@openshelf.com" },
  { key: "diya", name: "Diya Nair", first: "Diya", last: "Nair", email: "diya@openshelf.com" },
];

const hoursAgo = (h: number) => new Date(Date.now() - h * 3600_000);

async function getUsers(): Promise<Record<Key, IUser>> {
  let admin = await User.findOne({ role: "admin" });
  if (!admin) {
    admin = await User.create({
      name: "Library Admin",
      firstName: "Library",
      lastName: "Admin",
      email: "admin@openshelf.com",
      password: "admin123",
      role: "admin",
    });
  }

  const users: Partial<Record<Key, IUser>> = { admin };
  for (const m of MEMBERS) {
    let u = await User.findOne({ email: m.email });
    if (!u) {
      u = await User.create({
        name: m.name,
        firstName: m.first,
        lastName: m.last,
        email: m.email,
        password: "member123",
        role: "member",
      });
    }
    users[m.key] = u;
  }
  return users as Record<Key, IUser>;
}

/* ------------------------------ Discussions ------------------------------ */

interface DiscussionSeed {
  book: string;
  by: Key;
  title: string;
  body: string;
  spoiler?: boolean;
  pinned?: boolean;
  upvotes: Key[];
  hoursAgo: number;
  replies: { by: Key; body: string; spoiler?: boolean; hoursAgo: number }[];
}

const DISCUSSIONS: DiscussionSeed[] = [
  {
    book: "Dune",
    by: "admin",
    title: "Welcome to the Dune discussion room",
    body: "Share your thoughts on Arrakis, the politics and the spice. Please tick the spoiler box if you talk about plot twists!",
    pinned: true,
    upvotes: ["demo", "aarav", "meera"],
    hoursAgo: 200,
    replies: [
      { by: "aarav", body: "Just started it — the worldbuilding in the first 50 pages is unreal.", hoursAgo: 150 },
    ],
  },
  {
    book: "Dune",
    by: "aarav",
    title: "Is it okay to read this as a first sci-fi book?",
    body: "I mostly read thrillers. Is Dune too dense for a beginner, or should I just dive in?",
    upvotes: ["demo", "kabir"],
    hoursAgo: 120,
    replies: [
      { by: "meera", body: "Dive in! Keep the glossary at the back handy and don't worry if the names blur at first.", hoursAgo: 100 },
      { by: "kabir", body: "It was my first too. It's slow to start but completely worth it.", hoursAgo: 90 },
    ],
  },
  {
    book: "The Hobbit",
    by: "demo",
    title: "Best riddle in the dark?",
    body: "Which riddle from the Gollum chapter is your favourite — and did you guess it before Bilbo did?",
    upvotes: ["aarav", "meera", "kabir"],
    hoursAgo: 72,
    replies: [
      { by: "meera", body: "The one about the thing that eats everything. I only got it after reading the answer!", hoursAgo: 60 },
      { by: "demo", body: "Same here. Bilbo being that quick under pressure is why I love him.", hoursAgo: 55 },
    ],
  },
  {
    book: "Atomic Habits",
    by: "kabir",
    title: "Which habit trick actually worked for you?",
    body: "I've tried habit stacking and the two-minute rule. Stacking stuck, the two-minute rule fizzled out. What about you?",
    upvotes: ["demo", "aarav"],
    hoursAgo: 48,
    replies: [
      { by: "demo", body: "Two-minute rule for me — I started with just putting on my running shoes. Everything else followed.", hoursAgo: 40 },
      { by: "aarav", body: "Environment design. I moved my phone out of the bedroom and my sleep improved a lot.", hoursAgo: 30 },
    ],
  },
  {
    book: "Pride and Prejudice",
    by: "meera",
    title: "Mr. Darcy: hero or snob?",
    body: "Is Darcy really a romantic hero, or does he just get a lot of credit for being less rude later? Curious what everyone thinks.",
    upvotes: ["demo", "aarav", "kabir"],
    hoursAgo: 36,
    replies: [
      { by: "demo", body: "A bit of both! The first proposal is a disaster, but the way he changes afterwards is what wins me over.", hoursAgo: 28 },
      { by: "kabir", body: "Honestly I liked Elizabeth's wit more than the romance.", hoursAgo: 20 },
    ],
  },
  {
    book: "1984",
    by: "aarav",
    title: "That ending — still thinking about it (spoilers)",
    body: "The final chapter left me cold. Did anyone read it as completely hopeless, or is there a flicker of something else?",
    spoiler: true,
    upvotes: ["meera"],
    hoursAgo: 24,
    replies: [
      { by: "meera", body: "Hopeless, for me. The scariest part is how quietly it happens.", spoiler: true, hoursAgo: 14 },
    ],
  },
  {
    book: "Dracula",
    by: "demo",
    title: "Why the story is told through letters and diaries",
    body: "I loved the diary-and-letters format — it makes the story feel like a real file of evidence. Does it work for you?",
    upvotes: ["meera", "kabir"],
    hoursAgo: 10,
    replies: [
      { by: "kabir", body: "Yes — it reads like a real file of evidence, and that makes the scary parts feel more believable.", hoursAgo: 5 },
    ],
  },
  {
    book: "Ikigai: The Japanese Secret to a Long and Happy Life",
    by: "diya",
    title: "Did you find your own ikigai while reading?",
    body: "The four-circles idea is simple, but I found it hard to fill in honestly. Did anyone actually finish the exercise?",
    upvotes: ["demo", "kabir", "meera"],
    hoursAgo: 96,
    replies: [
      { by: "kabir", body: "I did it twice. The second time I was far more honest, and the answer changed.", hoursAgo: 80 },
      { by: "demo", body: "I liked the chapters on small daily rituals more than the diagram itself.", hoursAgo: 70 },
    ],
  },
  {
    book: "The Alchemist",
    by: "meera",
    title: "Inspiring or too simple?",
    body: "Some friends say it changed their outlook, others find it too neat. Where do you land?",
    upvotes: ["aarav", "diya"],
    hoursAgo: 84,
    replies: [
      { by: "aarav", body: "Simple, yes, but I think the simplicity is the point. It reads like a fable.", hoursAgo: 66 },
      { by: "diya", body: "I read it at a low point and it helped. I'd probably read it differently now.", hoursAgo: 50 },
    ],
  },
  {
    book: "Harry Potter and the Philosopher's Stone",
    by: "aarav",
    title: "Which house would you be sorted into?",
    body: "Be honest: the house you want and the house you would actually get might be different ones!",
    upvotes: ["demo", "meera", "kabir", "diya"],
    hoursAgo: 60,
    replies: [
      { by: "diya", body: "I want Ravenclaw but I think I'd end up in Hufflepuff, and I'm fine with that.", hoursAgo: 52 },
      { by: "kabir", body: "Gryffindor on paper, Slytherin in the way I plan everything.", hoursAgo: 44 },
      { by: "demo", body: "Hufflepuff, no question. I always root for the loyal friend.", hoursAgo: 38 },
    ],
  },
  {
    book: "To Kill a Mockingbird",
    by: "demo",
    title: "Reading it as an adult vs. at school",
    body: "I read it at school and found it slow. Reading it again now, it hits very differently. Has that happened to you with a book?",
    upvotes: ["meera", "diya"],
    hoursAgo: 30,
    replies: [
      { by: "meera", body: "Yes! Same with Jane Eyre. Some books need a few more years of life before they land.", hoursAgo: 22 },
    ],
  },
  {
    book: "The Hunger Games",
    by: "kabir",
    title: "Best-paced first book in a series?",
    body: "I couldn't put this one down. Does any other first book in a series pull you in this fast?",
    upvotes: ["aarav", "diya"],
    hoursAgo: 20,
    replies: [
      { by: "aarav", body: "The Lightning Thief comes close. It's quick, funny and never slows down.", hoursAgo: 15 },
    ],
  },
  {
    book: "Sapiens: A Brief History of Humankind",
    by: "diya",
    title: "A chapter that changed how you see things",
    body: "For me it was the idea of shared stories, like money and nations, holding large groups together. Which part stayed with you?",
    upvotes: ["kabir", "demo"],
    hoursAgo: 14,
    replies: [
      { by: "kabir", body: "The agricultural revolution chapter. I'd never thought of it as a trade-off before.", hoursAgo: 8 },
    ],
  },
  {
    book: "Jane Eyre",
    by: "meera",
    title: "Is Jane the original independent heroine?",
    body: "She speaks her mind long before it was expected of her. Who are the other heroines like her?",
    upvotes: ["demo", "diya"],
    hoursAgo: 8,
    replies: [
      { by: "demo", body: "Elizabeth Bennet comes to mind, though she is sparkier and less serious.", hoursAgo: 4 },
    ],
  },
  {
    book: "The Great Gatsby",
    by: "aarav",
    title: "Is Gatsby a tragedy or a warning?",
    body: "I can't decide whether the book wants us to admire Gatsby or learn from him. What do you think?",
    upvotes: ["kabir", "meera"],
    hoursAgo: 6,
    replies: [],
  },
  {
    book: "Clean Code",
    by: "kabir",
    title: "Rules from Clean Code you actually follow",
    body: "Small functions and meaningful names have stuck with me. Which rules do you really use day to day?",
    upvotes: ["aarav"],
    hoursAgo: 3,
    replies: [
      { by: "aarav", body: "Naming, mostly. A good name saves a comment every time.", hoursAgo: 1 },
    ],
  },
];

/* ------------------------------ Reading lists ----------------------------- */

interface ListSeed {
  owner: Key;
  name: string;
  description: string;
  isPublic: boolean;
  books: string[];
  followers: Key[];
}

const LISTS: ListSeed[] = [
  {
    owner: "demo",
    name: "Weekend starter pack",
    description: "A mix of comfort reads and habit-building.",
    isPublic: true,
    books: ["Atomic Habits", "The Hobbit", "The Alchemist"],
    followers: ["aarav", "meera"],
  },
  {
    owner: "meera",
    name: "Classics worth the hype",
    description: "Old books that are still genuinely good.",
    isPublic: true,
    books: ["Pride and Prejudice", "Jane Eyre", "Dracula", "The Great Gatsby", "1984"],
    followers: ["demo", "kabir"],
  },
  {
    owner: "kabir",
    name: "Habits & mindset",
    description: "Books that changed how I plan my days.",
    isPublic: true,
    books: ["Atomic Habits", "Ikigai: The Japanese Secret to a Long and Happy Life", "Rich Dad Poor Dad", "The Power of Now"],
    followers: ["demo"],
  },
  {
    owner: "aarav",
    name: "Sci-fi & fantasy night",
    description: "For when the lights are low and the tea is hot.",
    isPublic: true,
    books: ["Dune", "The Hobbit", "The Hunger Games", "Percy Jackson & the Olympians: The Lightning Thief"],
    followers: [],
  },
  {
    owner: "diya",
    name: "Mind & meaning",
    description: "Slower books for thinking about purpose and attention.",
    isPublic: true,
    books: ["Ikigai: The Japanese Secret to a Long and Happy Life", "Man's Search for Meaning", "The Power of Now", "The Alchemist"],
    followers: ["demo", "kabir"],
  },
  {
    owner: "aarav",
    name: "Page-turners for a long journey",
    description: "Fast, gripping reads that make a train ride disappear.",
    isPublic: true,
    books: ["The Hunger Games", "The Da Vinci Code", "And Then There Were None", "Gone Girl"],
    followers: ["diya"],
  },
  {
    owner: "meera",
    name: "Books about money and success",
    description: "Practical and thoughtful reads about work, money and habits.",
    isPublic: true,
    books: ["The Psychology of Money", "Rich Dad Poor Dad", "Deep Work: Rules for Focused Success in a Distracted World", "Atomic Habits"],
    followers: ["kabir", "aarav"],
  },
  {
    owner: "kabir",
    name: "For developers",
    description: "Books I come back to when I want to write better code.",
    isPublic: true,
    books: ["Clean Code", "The Pragmatic Programmer", "Introduction to Algorithms"],
    followers: ["aarav"],
  },
  {
    owner: "demo",
    name: "To read next",
    description: "My private queue.",
    isPublic: false,
    books: ["Dune", "Jane Eyre"],
    followers: [],
  },
];

/* ------------------------------ Demo likes ------------------------------- */

// Which curated quotes each demo member "keeps" (matched by the start of the
// text). Applied only to quotes created in the same run, so re-running the
// script never re-likes something a user has since removed.
const DEMO_LIKES: Record<Exclude<Key, "admin">, string[]> = {
  demo: [
    "It is a truth universally acknowledged",
    "I am no bird",
    "So we beat on",
    "Listen to them",
    "A shelf is a map",
    "The course of true love",
  ],
  aarav: ["So we beat on", "Call me Ishmael", "Underline what surprises you"],
  meera: ["It is a truth universally acknowledged", "Reader, I married him", "I could easily forgive his pride", "Do you think, because I am poor"],
  kabir: ["Curiouser and curiouser", "Her voice is full of money", "It was the best of times"],
  diya: ["I declare after all there is no enjoyment", "Till this moment I never knew myself", "Small habits do not shout", "A reason to get up in the morning"],
};

/* ---------------------------------- Main ---------------------------------- */

export async function seedCommunity() {
  const users = await getUsers();

  // Look books up once; anything missing from the catalogue is skipped.
  const titles = new Set<string>();
  DISCUSSIONS.forEach((d) => titles.add(d.book));
  LISTS.forEach((l) => l.books.forEach((b) => titles.add(b)));

  const found = await Book.find({ title: { $in: Array.from(titles) } }).select("_id title");
  const bookId = new Map<string, Types.ObjectId>(
    found.map((b) => [b.title, b._id] as [string, Types.ObjectId])
  );
  const uid = (k: Key) => users[k]._id;

  let created = { discussions: 0, lists: 0, quotes: 0 };

  for (const d of DISCUSSIONS) {
    const book = bookId.get(d.book);
    if (!book) continue;
    if (await Discussion.exists({ book, title: d.title })) continue;

    const lastActivity = d.replies.length
      ? hoursAgo(Math.min(...d.replies.map((r) => r.hoursAgo)))
      : hoursAgo(d.hoursAgo);

    await Discussion.create(({
      book,
      user: uid(d.by),
      userName: users[d.by].name,
      title: d.title,
      body: d.body,
      spoiler: Boolean(d.spoiler),
      pinned: Boolean(d.pinned),
      upvotes: d.upvotes.map(uid),
      replies: d.replies.map((r) => ({
        user: uid(r.by),
        userName: users[r.by].name,
        body: r.body,
        spoiler: Boolean(r.spoiler),
        createdAt: hoursAgo(r.hoursAgo),
      })),
      lastActivityAt: lastActivity,
      createdAt: hoursAgo(d.hoursAgo),
    }) as any);
    created.discussions++;
  }

  for (const l of LISTS) {
    if (await ReadingList.exists({ owner: uid(l.owner), name: l.name })) continue;
    const books = l.books.map((t) => bookId.get(t)).filter((b): b is Types.ObjectId => Boolean(b));
    if (books.length === 0) continue;

    await ReadingList.create({
      owner: uid(l.owner),
      ownerName: users[l.owner].name,
      name: l.name,
      description: l.description,
      isPublic: l.isPublic,
      books,
      followers: l.isPublic ? l.followers.map(uid) : [],
    });
    created.lists++;
  }

  const quoteRun = await seedCuratedQuotes();
  created.quotes = quoteRun.created;
  for (const [key, snippets] of Object.entries(DEMO_LIKES) as [Exclude<Key, "admin">, string[]][]) {
    for (const snippet of snippets) {
      const curated = CURATED_QUOTES.find((q) => q.text.startsWith(snippet));
      if (!curated) continue;
      const textKey = normaliseQuoteText(curated.text);
      if (!quoteRun.createdKeys.has(textKey)) continue;
      const doc = await Quote.findOne({ textKey }).select("_id");
      if (doc) await setQuoteLike(doc._id, uid(key), true);
    }
  }

  // A couple of notifications for the demo member (only when the demo
  // member has none yet, so reruns don't pile up).
  const demoId = uid("demo");
  if (!(await Notification.exists({ user: demoId }))) {
    const hobbit = await Discussion.findOne({ title: "Best riddle in the dark?" }).select("_id");
    const dracula = await Discussion.findOne({
      title: "Why the story is told through letters and diaries",
    }).select("_id");
    if (hobbit && dracula) {
      await Notification.create([
        {
          user: demoId,
          message: `${users.meera.name} replied to your discussion "Best riddle in the dark?"`,
          link: `/discussions/${hobbit._id}`,
          createdAt: hoursAgo(60),
        },
        {
          user: demoId,
          message: `${users.kabir.name} replied to your discussion "Why the story is told through letters and diaries"`,
          link: `/discussions/${dracula._id}`,
          createdAt: hoursAgo(5),
        },
      ]);
    }
  }

  console.log(
    `   Community sample data: ${created.discussions} discussions, ${created.lists} lists, ${created.quotes} quotes added`
  );
  return created;
}

// Runs on every server start. When the library has books and an admin but no
// community content yet (no discussions, no reading lists, no curated quotes),
// it adds the sample data so Discussions, Discover and Book Highlights are not
// empty on a fresh install. It never deletes anything and does nothing once the
// content exists. Set AUTO_SEED_SAMPLE_DATA=false in server/.env to turn it off.
export async function autoSeedSampleData() {
  if (process.env.AUTO_SEED_SAMPLE_DATA === "false") return;
  if (!(await Book.exists({}))) return; // seed the catalogue first (npm run seed)
  if (!(await User.exists({ role: "admin" }))) return;

  const noCommunity = !(await Discussion.exists({})) && !(await ReadingList.exists({}));
  const noCuratedQuotes = !(await Quote.exists({ addedBy: null }));

  if (noCommunity) {
    await seedCommunity();
  } else if (noCuratedQuotes) {
    const { created } = await seedCuratedQuotes();
    console.log(`   Book Highlights: ${created} sample quotes added`);
  }
}
