import { IUser } from "../models/User";

// Older accounts (e.g. seeded before first/last name existed) only have `name`.
// Derive first/last from it so the API always returns both.
export function splitName(user: Pick<IUser, "name" | "firstName" | "lastName">) {
  const parts = (user.name || "").trim().split(/\s+/);
  return {
    firstName: user.firstName || parts[0] || "",
    lastName: user.lastName || parts.slice(1).join(" "),
  };
}

// The user shape returned to the client (never includes the password hash)
export function publicUser(user: IUser) {
  const { firstName, lastName } = splitName(user);
  return {
    id: user._id,
    name: user.name,
    firstName,
    lastName,
    email: user.email,
    phone: user.phone || "",
    role: user.role,
    createdAt: user.createdAt,
  };
}
