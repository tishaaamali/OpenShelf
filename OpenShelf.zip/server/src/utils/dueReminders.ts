import { Types } from "mongoose";
import { Book } from "../models/Book";
import { Notification } from "../models/Notification";

// Due-date reminders. A borrower gets exactly two notifications per loan:
//  - "soon":    when the book is due within REMIND_DAYS days (or today)
//  - "overdue": once the due date has passed
// Each is stored with a unique key (user + copy + due date + stage), so running
// this as often as we like never creates a duplicate.

const REMIND_DAYS = Number(process.env.DUE_REMINDER_DAYS || 2);
const DAY = 86400000;

const formatDate = (d: Date) =>
  new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });

export interface ReminderPlan {
  key: string;
  user: Types.ObjectId;
  message: string;
  link: string;
  createdAt: Date;
}

// Pure function: which reminders does this set of books call for right now?
// Kept separate from the database so it is easy to test.
export function planDueReminders(books: any[], now = new Date(), onlyUser?: string): ReminderPlan[] {
  const horizon = now.getTime() + REMIND_DAYS * DAY;
  const plans: ReminderPlan[] = [];

  for (const book of books) {
    for (const copy of book.copies || []) {
      if (copy.status !== "Borrowed" || !copy.borrowedBy || !copy.dueDate) continue;
      if (onlyUser && copy.borrowedBy.toString() !== onlyUser) continue;

      const due = new Date(copy.dueDate);
      if (Number.isNaN(due.getTime())) continue;

      const overdue = due.getTime() < now.getTime();
      if (!overdue && due.getTime() > horizon) continue;

      const stage = overdue ? "overdue" : "soon";
      plans.push({
        key: `due:${copy._id}:${due.toISOString()}:${stage}`,
        user: copy.borrowedBy,
        message: overdue
          ? `"${book.title}" was due on ${formatDate(due)} and is now overdue. Please return it to avoid late fees.`
          : `Reminder: "${book.title}" is due back on ${formatDate(due)}.`,
        link: "/account",
        createdAt: now,
      });
    }
  }
  return plans;
}

// Creates any reminder that has not been sent yet. Pass a user id to check only
// that member's loans (used when they open the bell), or nothing to sweep everyone.
export async function sendDueReminders(userId?: string) {
  const horizon = new Date(Date.now() + REMIND_DAYS * DAY);
  const copyFilter: Record<string, unknown> = {
    status: "Borrowed",
    dueDate: { $lte: horizon },
  };
  if (userId) copyFilter.borrowedBy = new Types.ObjectId(userId);

  const books = await Book.find({ copies: { $elemMatch: copyFilter } })
    .select("title copies._id copies.status copies.borrowedBy copies.dueDate")
    .lean();

  const plans = planDueReminders(books as any[], new Date(), userId);
  let created = 0;
  for (const plan of plans) {
    try {
      const exists = await Notification.exists({ user: plan.user, key: plan.key });
      if (exists) continue;
      await Notification.create(plan);
      created++;
    } catch (err: any) {
      // Lost a race with another run: the unique index already has it.
      if (err?.code !== 11000) console.error("Due reminder failed:", err);
    }
  }
  return created;
}

// Per-member throttle so the bell's 60-second polling does not rescan the library each time.
const lastChecked = new Map<string, number>();
export async function sendDueRemindersThrottled(userId: string, everyMs = 5 * 60_000) {
  const last = lastChecked.get(userId) || 0;
  if (Date.now() - last < everyMs) return 0;
  lastChecked.set(userId, Date.now());
  return sendDueReminders(userId);
}
