import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { Book } from "../models/Book";

dotenv.config();

async function setBookRatings() {
  try {
    await connectDB();

    console.log("⭐ Adding initial book ratings...");

    const books = await Book.find({}).sort({
      addedDate: 1,
    });

    if (books.length === 0) {
      console.log("❌ No books found in database.");
      process.exit(0);
    }

    const ratings = [
      4.9, 4.8, 4.8, 4.7, 4.7, 4.6, 4.6, 4.5, 4.5, 4.4,
      4.4, 4.3, 4.3, 4.2, 4.2, 4.1, 4.1, 4.0, 4.0, 4.8,
      4.7, 4.6, 4.5, 4.4, 4.3, 4.2, 4.1, 4.0, 4.9, 4.8,
      4.7, 4.6, 4.5, 4.4, 4.3, 4.2, 4.1, 4.0, 4.8, 4.7,
      4.6, 4.5, 4.4, 4.3, 4.2, 4.1, 4.0, 4.9, 4.8, 4.7,
      4.6, 4.5, 4.4, 4.3, 4.2, 4.1, 4.0, 4.8, 4.7,
    ];

    for (let i = 0; i < books.length; i++) {
      const book = books[i];

      book.rating = ratings[i] ?? 4.5;

      book.ratingCount = 20 + ((i * 7) % 110);

      await book.save();
    }

    console.log("");
    console.log("==============================");
    console.log("⭐ RATINGS ADDED SUCCESSFULLY");
    console.log("==============================");
    console.log(`📚 Books updated: ${books.length}`);
    console.log("==============================");

    process.exit(0);
  } catch (error) {
    console.error("❌ Failed to add ratings:", error);
    process.exit(1);
  }
}

setBookRatings();