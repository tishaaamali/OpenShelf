import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { seedCommunity } from "./communitySample";

dotenv.config();

// Adds sample discussions, reading lists and quotes WITHOUT deleting anything.
// Run with: npm run seed:community
async function run() {
  try {
    await connectDB();
    await seedCommunity();
    console.log("✅ Community sample data ready");
    console.log("   Extra demo members (password member123): aarav@, meera@, kabir@, diya@openshelf.com");
    process.exit(0);
  } catch (err) {
    console.error("Community seed failed:", err);
    process.exit(1);
  }
}

run();
