import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { ensureQuoteData } from "./quoteService";
import { seedCuratedQuotes } from "./quoteSeed";

dotenv.config();

// Adds the curated Book Highlights quotes WITHOUT deleting anything.
// Run with: npm run seed:quotes
async function run() {
  try {
    await connectDB();
    await ensureQuoteData();
    const { created, total } = await seedCuratedQuotes();
    console.log(`✅ Book Highlights: ${created} new quotes added (${total} curated in total)`);
    process.exit(0);
  } catch (err) {
    console.error("Quote seed failed:", err);
    process.exit(1);
  }
}

run();
