import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { Book } from "../models/Book";
import { extraBooks } from "./extraBooks";
import { curatedBooks } from "./curatedBooks";
import { isRealIsbn, coverUrlForIsbn } from "./coverUtils";

dotenv.config();

async function addBooks() {
  try {
    // Connect to MongoDB
    await connectDB();

    // Remove the old generated placeholder titles (fake 97800000xxxxx ISBNs, no cover).
    // Only books that are not currently borrowed are removed.
    const purged = await Book.deleteMany({
      isbn13: /^97800000/,
      "copies.status": { $ne: "Borrowed" },
    });
    if (purged.deletedCount) console.log(`Removed ${purged.deletedCount} placeholder books without covers`);

    // This script is additive: preserve the existing catalogue and only insert missing ISBNs.
    const knownIsbns = new Set<string>(await Book.distinct("isbn13"));
    const catalogueBooks = [...extraBooks, ...curatedBooks].filter((book) => !knownIsbns.has(book.isbn13));
    let barcodeSeq = Date.now();

    const booksToAdd = catalogueBooks.map((b) => {
      const copies = Array.from({ length: b.copies }).map(() => {
        const currentBarcode = `LIB-${String(barcodeSeq).padStart(5, "0")}`;

        const shelfIndex = barcodeSeq - 1;

        barcodeSeq++;

        return {
          barcode: currentBarcode,

          shelf: `${String.fromCharCode(
            65 + (shelfIndex % 6)
          )}-${(shelfIndex % 20) + 1}`,

          condition: "Good" as const,

          status: "Available" as const,
        };
      });

      return {
        title: b.title,
        author: b.author,
        category: b.category,
        language: b.language,
        publisher: b.publisher,
        edition: b.edition,
        year: b.year,

        // Your actual schema uses isbn13
        isbn13: b.isbn13,
        isbn10: b.isbn10,

        format: b.format,

        status: "Available",

        description: b.desc,
        coverImage: isRealIsbn(b.isbn13) ? coverUrlForIsbn(b.isbn13) : "",
        previewText: b.previewText || b.desc,
        nextReaderNote: "Enjoy this book and pass it on to another reader.",

        borrowCount: b.borrowCount,

        addedDate: new Date(),

        copies,

        waitlist: [],
      };
    });

    console.log(`📚 Preparing ${booksToAdd.length} books...`);

    // --------------------------------------------------
    // 4. Insert all books
    // --------------------------------------------------

    await Book.insertMany(booksToAdd);

    // --------------------------------------------------
    // 5. Success
    // --------------------------------------------------

    console.log("");
    console.log("====================================");
    console.log("✅ BOOKS ADDED SUCCESSFULLY!");
    console.log("====================================");
    console.log(`📚 Total books added: ${booksToAdd.length}`);
    console.log("👤 Users were NOT deleted");
    console.log("📋 Other database data was NOT deleted");
    console.log("====================================");

    process.exit(0);

  } catch (err) {
    console.error("");
    console.error("❌ Adding books failed:");
    console.error(err);

    process.exit(1);
  }
}

addBooks();
