// Phone is optional — only validate when a value was actually provided.
// Accepts digits with an optional leading "+", spaces, dashes and brackets (7–15 digits).
export function isValidPhone(phone: string): boolean {
  const value = phone.trim();
  if (!/^\+?[\d\s\-()]+$/.test(value)) return false;
  const digits = value.replace(/\D/g, "");
  return digits.length >= 7 && digits.length <= 15;
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
