// Original book covers via Open Library's free Covers API (looked up by ISBN).
// https://openlibrary.org/dev/docs/api/covers
//
// `default=false` makes Open Library return a 404 when it has no cover, instead of
// a blank 1x1 image, so we can detect missing covers (and the UI can fall back).

// The generated "OpenShelf Press" sample titles use fake ISBNs (9780000000xxx);
// they are not real books, so no original cover exists for them.
export const isRealIsbn = (isbn13: string): boolean =>
  /^97[89]\d{10}$/.test(isbn13) && !isbn13.startsWith("97800000");

export const coverUrlForIsbn = (isbn13: string): string =>
  `https://covers.openlibrary.org/b/isbn/${isbn13}-L.jpg?default=false`;

// Returns the cover URL only if Open Library actually has an image for this ISBN.
export async function findCover(isbn13: string, isbn10?: string): Promise<string> {
  const candidates = [isbn13, isbn10]
    .filter((v): v is string => !!v && /^[0-9Xx]{10,13}$/.test(v))
    .map((v) => `https://covers.openlibrary.org/b/isbn/${v}-L.jpg?default=false`);

  for (const url of candidates) {
    try {
      const res = await fetch(url, { method: "HEAD", redirect: "follow" });
      if (res.ok) return url;
    } catch {
      /* network hiccup: try next candidate */
    }
  }
  return "";
}
