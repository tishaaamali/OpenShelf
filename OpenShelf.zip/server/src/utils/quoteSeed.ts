import { Quote, QuoteKind, normaliseQuoteText } from "../models/Quote";
import { findBookIdsByTitle } from "./quoteService";

// Curated starter quotes for Book Highlights.
//
//  - "literary": short excerpts from works in the public domain, attributed to
//    the author and the work (with chapter / act where it is certain).
//  - "original": short reading-inspired lines written for OpenShelf. They are
//    labelled as originals and are never attributed to anyone else.
//
// `bookTitle` is the exact title of a book in the OpenShelf catalogue. When the
// book exists the quote links to it (and offers borrowing); when it does not,
// the quote still shows its author and source but has no link or borrow button.

export interface CuratedQuote {
  text: string;
  author: string;
  sourceTitle: string;
  attribution: string;
  kind: QuoteKind;
  bookTitle?: string;
}

const lit = (
  text: string,
  author: string,
  sourceTitle: string,
  attribution: string,
  inCatalogue = false
): CuratedQuote => ({
  text,
  author,
  sourceTitle,
  attribution,
  kind: "literary",
  bookTitle: inCatalogue ? sourceTitle : undefined,
});

const original = (text: string): CuratedQuote => ({
  text,
  author: "OpenShelf",
  sourceTitle: "",
  attribution: "Original reading note",
  kind: "original",
});

// An original note about a book in the catalogue. It is written for OpenShelf,
// labelled as an original line, and never presented as a quotation from the
// book (the books it is about are still in copyright).
const note = (bookTitle: string, text: string): CuratedQuote => ({
  text,
  author: "OpenShelf",
  sourceTitle: bookTitle,
  attribution: "Original reading note",
  kind: "original",
  bookTitle,
});

// Ordered so that each page of the feed mixes literary and original lines.
const BASE_QUOTES: CuratedQuote[] = [
  lit("It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife.", "Jane Austen", "Pride and Prejudice", "Chapter 1", true),
  original("A borrowed book is a conversation that begins before you open it."),
  lit("I am no bird; and no net ensnares me: I am a free human being with an independent will.", "Charlotte Brontë", "Jane Eyre", "Chapter 23", true),
  lit("So we beat on, boats against the current, borne back ceaselessly into the past.", "F. Scott Fitzgerald", "The Great Gatsby", "Chapter 9", true),
  original("Every dog-eared page is a promise to come back."),
  lit("It was the best of times, it was the worst of times.", "Charles Dickens", "A Tale of Two Cities", "Book the First, Chapter 1"),
  lit("Listen to them—the children of the night. What music they make!", "Bram Stoker", "Dracula", "Chapter 2", true),
  original("Some books are read in an evening; the best ones are read for years."),
  lit("I could easily forgive his pride, if he had not mortified mine.", "Jane Austen", "Pride and Prejudice", "Chapter 5", true),
  lit("Reader, I married him.", "Charlotte Brontë", "Jane Eyre", "Chapter 38", true),
  original("A shelf is a map of the places a mind has been."),
  lit("Call me Ishmael.", "Herman Melville", "Moby-Dick", "Chapter 1"),
  lit("Her voice is full of money.", "F. Scott Fitzgerald", "The Great Gatsby", "Chapter 7", true),
  original("Return a book on time, and someone else's next chapter begins."),
  lit("My good opinion once lost, is lost forever.", "Jane Austen", "Pride and Prejudice", "Chapter 11", true),
  lit("The course of true love never did run smooth.", "William Shakespeare", "A Midsummer Night's Dream", "Act 1, Scene 1"),
  original("Reading slowly is not falling behind; it is staying longer."),
  lit("I would always rather be happy than dignified.", "Charlotte Brontë", "Jane Eyre", "Chapter 24", true),
  lit("Curiouser and curiouser!", "Lewis Carroll", "Alice's Adventures in Wonderland", "Chapter 2"),
  original("Every library card is a small passport."),
  lit("You must allow me to tell you how ardently I admire and love you.", "Jane Austen", "Pride and Prejudice", "Chapter 34", true),
  lit("Nelly, I am Heathcliff!", "Emily Brontë", "Wuthering Heights", "Chapter 9"),
  original("Underline what surprises you, then return to it when you have changed."),
  lit("I hope she'll be a fool—that's the best thing a girl can be in this world, a beautiful little fool.", "F. Scott Fitzgerald", "The Great Gatsby", "Chapter 1", true),
  lit("You see, but you do not observe.", "Arthur Conan Doyle", "The Adventures of Sherlock Holmes", "A Scandal in Bohemia"),
  original("The quiet hour with a good book is never wasted."),
  lit("You pierce my soul. I am half agony, half hope.", "Jane Austen", "Persuasion", "Chapter 23"),
];

// More public-domain lines, all from books that are in the catalogue.
const MORE_LITERARY: CuratedQuote[] = [
  lit("I declare after all there is no enjoyment like reading! How much sooner one tires of any thing than of a book!", "Jane Austen", "Pride and Prejudice", "Chapter 11", true),
  lit("Do you think, because I am poor, obscure, plain, and little, I am soulless and heartless?", "Charlotte Brontë", "Jane Eyre", "Chapter 23", true),
  lit("Gatsby believed in the green light, the orgastic future that year by year recedes before us.", "F. Scott Fitzgerald", "The Great Gatsby", "Chapter 9", true),
  lit("I am Dracula; and I bid you welcome, Mr. Harker, to my house.", "Bram Stoker", "Dracula", "Chapter 2", true),
  lit("Vanity and pride are different things, though the words are often used synonymously.", "Jane Austen", "Pride and Prejudice", "Chapter 5", true),
  lit("Life, believe me, is too short to be spent in nursing animosity or registering wrongs.", "Charlotte Brontë", "Jane Eyre", "Chapter 8", true),
  lit("I was within and without, simultaneously enchanted and repelled by the inexhaustible variety of life.", "F. Scott Fitzgerald", "The Great Gatsby", "Chapter 2", true),
  lit("Welcome to my house! Enter freely and of your own will!", "Bram Stoker", "Dracula", "Chapter 2", true),
  lit("Till this moment I never knew myself.", "Jane Austen", "Pride and Prejudice", "Chapter 36", true),
  lit("I have as much soul as you—and full as much heart!", "Charlotte Brontë", "Jane Eyre", "Chapter 23", true),
  lit("They were careless people, Tom and Daisy—they smashed up things and creatures and then retreated back into their money or their vast carelessness.", "F. Scott Fitzgerald", "The Great Gatsby", "Chapter 9", true),
];

// Original notes about popular books in the catalogue (themes, not quotations).
const BOOK_NOTES: CuratedQuote[] = [
  note("Atomic Habits", "Small habits do not shout. They compound quietly until the change is suddenly obvious."),
  note("Ikigai: The Japanese Secret to a Long and Happy Life", "A reason to get up in the morning is rarely found; it is usually built, one small purpose at a time."),
  note("The Alchemist", "A story about listening to your own direction while the world offers a hundred other maps."),
  note("Dune", "On a planet where water is wealth, every page teaches you to value what others waste."),
  note("Harry Potter and the Philosopher's Stone", "Every reader remembers the moment a letter changed everything for a boy under the stairs."),
  note("1984", "A book that makes you value plain words and private thoughts more than you did before."),
  note("The Hobbit", "Proof that the most unlikely traveller can be exactly the one the story needed."),
  note("Sapiens: A Brief History of Humankind", "History reads differently once you notice how much of it runs on shared stories."),
  note("Clean Code", "Code is read far more often than it is written, so write it for the next reader."),
  note("The Hunger Games", "A fast, tense read that asks what a society is willing to sit and watch."),
  note("The Kite Runner", "A story about guilt, loyalty and the long road back to doing the right thing."),
  note("Life of Pi", "Two tellings of one story, and the quiet question of which one you would rather believe."),
  note("To Kill a Mockingbird", "A small-town story that teaches empathy by asking you to stand in someone else's place."),
  note("The Power of Now", "A gentle reminder that the present moment is the only place a day can actually be lived."),
  note("Rich Dad Poor Dad", "A conversation starter about money habits most of us were never taught."),
  note("The Psychology of Money", "Behaviour, more than arithmetic, decides how money turns out."),
  note("Deep Work: Rules for Focused Success in a Distracted World", "Attention is the scarce resource; guard the hours when you do your best thinking."),
  note("Man's Search for Meaning", "A short, serious book about finding purpose in the hardest of circumstances."),
  note("The Lord of the Rings", "A very long road made bearable by good company."),
  note("Brave New World", "A comfortable future that deserves a second, slower look."),
  note("Fahrenheit 451", "A reminder of why a library card is worth protecting."),
  note("Wings of Fire: An Autobiography", "A life story that shows what patient curiosity can build."),
  note("The Midnight Library", "A gentle look at the lives we imagine and the one we are actually in."),
  note("The Book Thief", "A story about how words can keep a person going."),
  note("The Pragmatic Programmer", "Small, practical habits that make a developer better, one project at a time."),
  note("The Little Prince", "A small book that rewards a new reading at every age."),
];

// One public-domain line, then two book notes, so every page mixes both.
function interleave(literary: CuratedQuote[], notes: CuratedQuote[]): CuratedQuote[] {
  const out: CuratedQuote[] = [];
  let n = 0;
  for (const l of literary) {
    out.push(l);
    for (let k = 0; k < 2 && n < notes.length; k++) out.push(notes[n++]);
  }
  while (n < notes.length) out.push(notes[n++]);
  return out;
}

// OpenShelf's own "original" lines are no longer shown anywhere in the app, so
// only the public-domain literary lines are seeded.
export const CURATED_QUOTES: CuratedQuote[] = [
  ...BASE_QUOTES,
  ...interleave(MORE_LITERARY, BOOK_NOTES),
].filter((q) => q.kind !== "original");

// Adds any missing curated quote. Safe to run any number of times: quotes are
// matched on their normalised text, existing quotes (and their likes) are never
// replaced, and nothing is deleted.
export async function seedCuratedQuotes() {
  const titles = CURATED_QUOTES.map((q) => q.bookTitle).filter((t): t is string => Boolean(t));
  const bookIds = await findBookIdsByTitle(Array.from(new Set(titles)));

  const base = Date.now();
  const createdKeys = new Set<string>();

  for (let i = 0; i < CURATED_QUOTES.length; i++) {
    const q = CURATED_QUOTES[i];
    const key = normaliseQuoteText(q.text);
    const book = q.bookTitle ? bookIds.get(q.bookTitle) : undefined;

    const existing: any = await Quote.findOne({ textKey: key }).select(
      "book author sourceTitle attribution"
    );
    if (existing) {
      // Fill in missing attribution only; never overwrite anything.
      const set: Record<string, unknown> = {};
      if (!existing.book && book) set.book = book;
      if (!existing.author) set.author = q.author;
      if (!existing.sourceTitle && q.sourceTitle) set.sourceTitle = q.sourceTitle;
      if (!existing.attribution && q.attribution) set.attribution = q.attribution;
      if (Object.keys(set).length) await Quote.updateOne({ _id: existing._id }, { $set: set });
      continue;
    }

    try {
      await Quote.create({
        book: book || null,
        text: q.text,
        author: q.author,
        sourceTitle: q.sourceTitle,
        attribution: q.attribution,
        kind: q.kind,
        addedBy: null,
        addedByName: "OpenShelf",
        likes: [],
        likeCount: 0,
        // Staggered so "newest first" keeps the mixed order above.
        createdAt: new Date(base - i * 180_000),
      });
      createdKeys.add(key);
    } catch (err: any) {
      if (err?.code !== 11000) throw err; // lost a race with another run: fine
    }
  }

  return { created: createdKeys.size, createdKeys, total: CURATED_QUOTES.length };
}
