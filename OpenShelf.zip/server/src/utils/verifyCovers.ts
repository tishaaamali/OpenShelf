import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { Book } from "../models/Book";
import { findCover } from "./coverUtils";

dotenv.config();

// Usage:  npm run verify-covers            -> report books whose cover cannot be loaded
//         npm run verify-covers -- --remove -> also delete those (never borrowed ones)
async function verify() {
  const remove = process.argv.includes("--remove");
  await connectDB();
  const books = await Book.find({});
  let ok = 0;
  const broken: typeof books = [];
  for (const book of books) {
    const url = await findCover(book.isbn13, book.isbn10);
    if (url) {
      if (book.coverImage !== url) { book.coverImage = url; await book.save(); }
      ok++;
    } else broken.push(book);
    await new Promise((r) => setTimeout(r, 120));
  }
  console.log(`Covers OK: ${ok}   Missing/broken: ${broken.length}`);
  for (const b of broken) {
    const borrowed = b.copies.some((c) => c.status === "Borrowed");
    console.log(` - ${b.title} (${b.isbn13})${borrowed ? " [borrowed, kept]" : ""}`);
    if (remove && !borrowed) await Book.deleteOne({ _id: b._id });
  }
  process.exit(0);
}
verify().catch((e) => { console.error(e); process.exit(1); });
