import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { User } from "../models/User";

dotenv.config();

async function createAdmin() {
  await connectDB();

  const adminExists = await User.findOne({
    email: "admin@openshelf.com",
  });

  if (adminExists) {
    console.log("Admin already exists!");
    process.exit(0);
  }

  await User.create({
    name: "OpenShelf Admin",
    firstName: "OpenShelf",
    lastName: "Admin",
    email: "admin@openshelf.com",
    password: "Admin@123",
    role: "admin",
    readCount: 0,
  });

  console.log("✅ Admin created successfully!");
  console.log("Email: admin@openshelf.com");
  console.log("Password: Admin@123");

  process.exit(0);
}

createAdmin().catch((error) => {
  console.error("❌ Error:", error);
  process.exit(1);
});