import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { User } from "../models/User";
import { Book } from "../models/Book";
import { Discussion } from "../models/Discussion";
import { ReadingList } from "../models/ReadingList";
import { Notification } from "../models/Notification";
import { Quote } from "../models/Quote";
import { seedCommunity } from "./communitySample";
import mongoose from "mongoose";
import { extraBooks } from "./extraBooks";
import { curatedBooks } from "./curatedBooks";
import { isRealIsbn, coverUrlForIsbn } from "./coverUtils";

dotenv.config();

function daysAgo(n: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}

const baseBooks = [
  { title: "Harry Potter and the Philosopher's Stone", author: "J.K. Rowling", category: "Fantasy", language: "English", publisher: "Bloomsbury", edition: "1st Edition", year: 1997, isbn13: "9780747532699", isbn10: "0747532699", format: "Paperback", copies: 2, borrowCount: 34, desc: "An eleven-year-old orphan discovers he is a wizard and begins his first year at a school of magic." },
  { title: "Harry Potter and the Chamber of Secrets", author: "J.K. Rowling", category: "Fantasy", language: "English", publisher: "Bloomsbury", edition: "1st Edition", year: 1998, isbn13: "9780747538493", isbn10: "0747538492", format: "Paperback", copies: 1, borrowCount: 41, desc: "In his second year, the young wizard investigates a mysterious force that is petrifying students across the school." },
  { title: "Harry Potter and the Prisoner of Azkaban", author: "J.K. Rowling", category: "Fantasy", language: "English", publisher: "Bloomsbury", edition: "1st Edition", year: 1999, isbn13: "9780747542155", isbn10: "074754215X", format: "Paperback", copies: 2, borrowCount: 29, desc: "A dangerous convict has escaped, and his connection to the young wizard's past slowly comes to light." },
  { title: "Ikigai: The Japanese Secret to a Long and Happy Life", author: "Héctor García & Francesc Miralles", category: "Self-Help", language: "English", publisher: "Penguin", edition: "1st Edition", year: 2016, isbn13: "9780143130727", isbn10: "0143130722", format: "Paperback", copies: 3, borrowCount: 22, desc: "Drawing on the habits of the residents of Okinawa, this book explores finding a personal reason for being as a path to a longer, more fulfilling life." },
  { title: "The Alchemist", author: "Paulo Coelho", category: "Fiction", language: "English", publisher: "HarperCollins", edition: "2nd Edition", year: 2014, isbn13: "9780062315007", isbn10: "0062315005", format: "Paperback", copies: 3, borrowCount: 27, desc: "A shepherd boy named Santiago travels from Spain to Egypt in search of treasure, and finds himself along the way." },
  { title: "Atomic Habits", author: "James Clear", category: "Self-Help", language: "English", publisher: "Penguin", edition: "1st Edition", year: 2018, isbn13: "9780735211292", isbn10: "0735211299", format: "Hardcover", copies: 2, borrowCount: 31, desc: "A practical guide to building good habits and breaking bad ones, one tiny change at a time." },
  { title: "Dune", author: "Frank Herbert", category: "Fantasy", language: "English", publisher: "Ace Books", edition: "Anniversary Edition", year: 1965, isbn13: "9780441172719", isbn10: "0441172717", format: "Paperback", copies: 1, borrowCount: 15, desc: "On the desert planet Arrakis, a young man rises to lead a rebellion that will change the fate of the galaxy." },
  { title: "Sapiens: A Brief History of Humankind", author: "Yuval Noah Harari", category: "History", language: "English", publisher: "Harper", edition: "1st Edition", year: 2015, isbn13: "9780062316097", isbn10: "0062316095", format: "Hardcover", copies: 2, borrowCount: 24, desc: "A sweeping account of how Homo sapiens came to dominate the planet, from the cognitive revolution to the present." },
  { title: "Clean Code", author: "Robert C. Martin", category: "Technology", language: "English", publisher: "Prentice Hall", edition: "1st Edition", year: 2008, isbn13: "9780132350884", isbn10: "0132350882", format: "Paperback", copies: 1, borrowCount: 18, desc: "A handbook of agile software craftsmanship, covering principles and practices for writing clean, maintainable code." },
  { title: "Steve Jobs", author: "Walter Isaacson", category: "Biography", language: "English", publisher: "Simon & Schuster", edition: "1st Edition", year: 2011, isbn13: "9781451648539", isbn10: "1451648537", format: "Hardcover", copies: 2, borrowCount: 12, desc: "The exclusive biography of Apple co-founder Steve Jobs, based on more than forty interviews with Jobs himself." },
  { title: "1984", author: "George Orwell", category: "Fiction", language: "English", publisher: "Secker & Warburg", edition: "1st Edition", year: 1949, isbn13: "9780451524935", isbn10: "0451524934", format: "Paperback", copies: 2, borrowCount: 24, desc: "A dystopian vision of a totalitarian future where independent thought itself is treated as a crime." },
  { title: "To Kill a Mockingbird", author: "Harper Lee", category: "Fiction", language: "English", publisher: "J.B. Lippincott & Co.", edition: "1st Edition", year: 1960, isbn13: "9780061120084", isbn10: "0061120081", format: "Paperback", copies: 1, borrowCount: 9, desc: "A young girl in the American South comes of age while her father defends a Black man falsely accused of a crime." },
  { title: "The Hobbit", author: "J.R.R. Tolkien", category: "Fantasy", language: "English", publisher: "George Allen & Unwin", edition: "75th Anniversary Edition", year: 1937, isbn13: "9780547928227", isbn10: "0547928223", format: "Hardcover", copies: 2, borrowCount: 18, desc: "A reluctant homebody is swept into a quest with a band of dwarves to reclaim treasure guarded by a dragon." },
  { title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", category: "Self-Help", language: "English", publisher: "Plata Publishing", edition: "20th Anniversary Edition", year: 1997, isbn13: "9781612680194", isbn10: "1612680194", format: "Paperback", copies: 2, borrowCount: 20, desc: "A personal-finance classic contrasting two approaches to money, work and building lasting wealth." },
  { title: "The Power of Now", author: "Eckhart Tolle", category: "Self-Help", language: "English", publisher: "New World Library", edition: "1st Edition", year: 1997, isbn13: "9781577314806", isbn10: "1577314808", format: "Paperback", copies: 1, borrowCount: 7, desc: "A guide to spiritual awakening built around the practice of living fully in the present moment." },
  { title: "The Kite Runner", author: "Khaled Hosseini", category: "Fiction", language: "English", publisher: "Riverhead Books", edition: "1st Edition", year: 2003, isbn13: "9781594631931", isbn10: "1594631931", format: "Paperback", copies: 1, borrowCount: 11, desc: "A story of friendship and betrayal between two boys in Afghanistan, and the weight of a choice made in childhood." },
  { title: "Life of Pi", author: "Yann Martel", category: "Fiction", language: "English", publisher: "Knopf Canada", edition: "1st Edition", year: 2001, isbn13: "9780156027328", isbn10: "0156027321", format: "Paperback", copies: 2, borrowCount: 8, desc: "A shipwrecked boy survives 227 days at sea on a lifeboat sharing space with a Bengal tiger." },
  { title: "The Da Vinci Code", author: "Dan Brown", category: "Fiction", language: "English", publisher: "Doubleday", edition: "1st Edition", year: 2003, isbn13: "9780307474278", isbn10: "0307474275", format: "Hardcover", copies: 1, borrowCount: 14, desc: "A murder in the Louvre sends a symbologist chasing a trail of clues hidden in centuries-old art." },
  { title: "Percy Jackson & the Olympians: The Lightning Thief", author: "Rick Riordan", category: "Fantasy", language: "English", publisher: "Disney-Hyperion", edition: "1st Edition", year: 2005, isbn13: "9780786838653", isbn10: "0786838655", format: "Paperback", copies: 2, borrowCount: 19, desc: "A twelve-year-old discovers he is the son of a Greek god and is drawn into a quest across modern-day America." },
  { title: "The Hunger Games", author: "Suzanne Collins", category: "Fantasy", language: "English", publisher: "Scholastic", edition: "1st Edition", year: 2008, isbn13: "9780439023528", isbn10: "0439023521", format: "Paperback", copies: 1, borrowCount: 38, desc: "In a dark future, a girl volunteers to take her sister's place in a televised fight to the death." },
];

// 20 starter books + curated catalogue + 100 original demo entries spread
// evenly over the eight collection categories.
const booksData = [...baseBooks, ...extraBooks, ...curatedBooks];

async function seed() {
  await connectDB();

  console.log("Clearing existing data...");
  await Promise.all([
    User.deleteMany({}),
    mongoose.connection.collection("books").deleteMany({}),
    Discussion.deleteMany({}),
    ReadingList.deleteMany({}),
    Notification.deleteMany({}),
    Quote.deleteMany({}),
  ]);

  console.log("Creating admin user...");
  const admin = await User.create({
    name: "Library Admin",
    firstName: "Library",
    lastName: "Admin",
    email: "admin@openshelf.com",
    password: "admin123",
    role: "admin",
  });

  const member = await User.create({
    name: "Demo Member",
    firstName: "Demo",
    lastName: "Member",
    email: "member@openshelf.com",
    password: "member123",
    role: "member",
  });

  console.log("Creating books...");
  let barcodeSeq = 1;

  for (let i = 0; i < booksData.length; i++) {
    const b = booksData[i];
    const copies = Array.from({ length: b.copies }).map(() => ({
      barcode: `LIB-${String(barcodeSeq++).padStart(5, "0")}`,
      shelf: `${String.fromCharCode(65 + (i % 6))}-${(i % 20) + 1}`,
      condition: "Good" as const,
      status: "Available" as const,
    }));

    await Book.create({
      title: b.title,
      author: b.author,
      category: b.category,
      language: b.language,
      publisher: b.publisher,
      edition: b.edition,
      year: b.year,
      isbn13: b.isbn13,
      isbn10: b.isbn10,
      format: b.format,
      status: "Available",
      description: b.desc,
      coverImage: isRealIsbn(b.isbn13) ? coverUrlForIsbn(b.isbn13) : "",
      previewText: (b as any).previewText || b.desc,
      nextReaderNote: "Enjoy this book and pass it on to another reader.",
      borrowCount: b.borrowCount,
      addedDate: daysAgo((booksData.length - i) * 6),
      copies,
      waitlist: [],
    });
  }

  console.log("Creating community sample data...");
  await seedCommunity();

  console.log("✅ Seed complete!");
  console.log("   Admin  → admin@openshelf.com  / admin123");
  console.log("   Member → member@openshelf.com / member123");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
