import dotenv from "dotenv";
import { connectDB } from "../config/db";
import { Book } from "../models/Book";
import { findCover, isRealIsbn } from "./coverUtils";

dotenv.config();

// Usage:  npx ts-node src/utils/addCovers.ts
// Sets Book.coverImage to the original cover (Open Library, by ISBN) for every
// real book that doesn't have one yet. Safe to re-run. Pass --force to overwrite.
async function addCovers() {
  const force = process.argv.includes("--force");
  await connectDB();

  const books = await Book.find({});
  let updated = 0, skipped = 0;
  const missing: string[] = [];

  for (const book of books) {
    if (!force && book.coverImage) { skipped++; continue; }
    if (!isRealIsbn(book.isbn13)) { missing.push(`${book.title} (sample title, no real cover)`); continue; }

    const url = await findCover(book.isbn13, book.isbn10);
    if (url) {
      book.coverImage = url;
      await book.save();
      updated++;
      console.log(`✅ ${book.title}`);
    } else {
      missing.push(`${book.title} (not on Open Library)`);
    }
    await new Promise((r) => setTimeout(r, 150)); // be polite to the API
  }

  console.log(`\nUpdated: ${updated}   Already had cover: ${skipped}   No cover found: ${missing.length}`);
  missing.forEach((m) => console.log("  - " + m));
  process.exit(0);
}

addCovers().catch((e) => { console.error(e); process.exit(1); });
