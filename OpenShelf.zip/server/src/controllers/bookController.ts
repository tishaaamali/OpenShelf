import { Response } from "express";
import { Types } from "mongoose";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { logActivity } from "../models/ActivityLog";
import { notify } from "../models/Notification";
import { AuthedRequest } from "../types";
import { expireReservations } from "../utils/expireReservations";

export const LOAN_DAYS = Number(process.env.LOAN_DAYS || 5);
const FINE_PER_DAY = Number(process.env.FINE_PER_DAY || 50);

export function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

function overdueDays(dueDate?: Date | null): number {
  if (!dueDate) return 0;

  const diff = Math.floor(
    (Date.now() - new Date(dueDate).getTime()) / 86400000
  );

  return diff > 0 ? diff : 0;
}

function availableCopies(book: any): number {
  return book.copies.filter(
    (c: any) => c.status === "Available"
  ).length;
}

export function syncStatus(book: any) {
  if (book.copies.some((c: any) => c.status === "Available")) book.status = "Available";
  else if (book.copies.length && book.copies.every((c: any) => c.status === "Reserved")) book.status = "Unavailable";
  else book.status = "Borrowed";
}

// GET /api/books?q=&category=a,b&status=&page=1&limit=10&sort=recent|rating|popular
// - category accepts a comma separated list (multi-select filter)
// - when `page` or `limit` is sent the response is paginated:
//   { books, total, page, limit, hasMore, totalAll }
// - without them the old behaviour (plain array) is kept
export async function getBooks(
  req: AuthedRequest,
  res: Response
) {
  await expireReservations();
  const { q, category, status, sort } =
    req.query as Record<string, string>;

  const filter: any = {};

  // Safe search
  if (q) {
    const safe = q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    filter.$or = [
      { title: { $regex: safe, $options: "i" } },
      { author: { $regex: safe, $options: "i" } },
      { isbn13: { $regex: safe, $options: "i" } },
      { isbn10: { $regex: safe, $options: "i" } },
    ];
  }

  // Multi category: "Fantasy,Fiction"
  const categories = String(category || "")
    .split(",")
    .map((c) => c.trim())
    .filter(Boolean);

  if (categories.length === 1) {
    filter.category = categories[0];
  } else if (categories.length > 1) {
    filter.category = { $in: categories };
  }

  if (status) {
    filter.status = status;
  }

  // ids=a,b,c -> only those books (used for "Your Shelf")
  const ids = String(req.query.ids || "")
    .split(",")
    .map((id) => id.trim())
    .filter((id) => /^[a-f\d]{24}$/i.test(id));

  if (ids.length > 0) {
    filter._id = { $in: ids };
  }

  const sortBy: any =
    sort === "rating"
      ? { rating: -1, ratingCount: -1, _id: 1 }
      : sort === "popular"
        ? { borrowCount: -1, _id: 1 }
        : { addedDate: -1, _id: 1 }; // _id keeps the order stable between pages

  const paginated =
    req.query.page !== undefined || req.query.limit !== undefined;

  if (!paginated) {
    const books = await Book.find(filter).sort(sortBy);
    return res.json(books);
  }

  const limit = Math.min(
    50,
    Math.max(1, parseInt(String(req.query.limit), 10) || 10)
  );
  const page = Math.max(1, parseInt(String(req.query.page), 10) || 1);

  // coverFirst=1 -> books that have a cover image come first (same order inside each group)
  const coverFirst = String(req.query.coverFirst || "") === "1";

  const pageQuery = coverFirst
    ? Book.aggregate([
        {
          $match: {
            ...filter,
            ...(filter._id
              ? { _id: { $in: ids.map((id) => new Types.ObjectId(id)) } }
              : {}),
          },
        },
        {
          $addFields: {
            __hasCover: {
              $cond: [
                {
                  $gt: [
                    { $strLenCP: { $trim: { input: { $ifNull: ["$coverImage", ""] } } } },
                    0,
                  ],
                },
                1,
                0,
              ],
            },
          },
        },
        { $sort: { __hasCover: -1, ...sortBy } },
        { $skip: (page - 1) * limit },
        { $limit: limit },
        { $project: { __hasCover: 0 } },
      ])
    : Book.find(filter)
        .sort(sortBy)
        .skip((page - 1) * limit)
        .limit(limit);

  const [books, total, totalAll] = await Promise.all([
    pageQuery,
    Book.countDocuments(filter),
    Book.countDocuments({}),
  ]);

  res.json({
    books,
    total,
    totalAll,
    page,
    limit,
    hasMore: page * limit < total,
  });
}

// GET /api/books/:id
export async function getBookById(
  req: AuthedRequest,
  res: Response
) {
  await expireReservations({ book: req.params.id });
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({
      message: "Book not found",
    });
  }

  if (!book.nextReaderNote) book.nextReaderNote = "A little note from a reader will appear here after this book is returned.";
  res.json(book);
}

// POST /api/books (admin only)
export async function createBook(
  req: AuthedRequest,
  res: Response
) {
  try {
    const {
      title,
      author,
      category,
      language,
      publisher,
      edition,
      year,
      isbn13,
      isbn10,
      coverImage,
      format,
      status,
      description,
      numberOfCopies,
      shelf,
    } = req.body;

    if (
      !title ||
      !( /^\d{13}$/.test(String(isbn13 || "")) || /^\d{10}$/.test(String(isbn10 || "")) ) ||
      !author ||
      !category ||
      !language ||
      !format ||
      !shelf
    ) {
      return res.status(400).json({
        message: "Missing required fields",
      });
    }

    const copyCount = Math.max(
      1,
      Number(numberOfCopies) || 1
    );

    const timestamp = Date.now();

    const copies = Array.from({
      length: copyCount,
    }).map((_, i) => ({
      barcode: `LIB-${timestamp}-${i + 1}`,
      shelf,
      condition: "New" as const,
      status: "Available" as const,
    }));

    const book = await Book.create({
      title,
      author,
      category,
      language,
      publisher: publisher || "—",
      edition: edition || "—",
      year: year || undefined,
      isbn13,
      isbn10: isbn10 || "—",
      coverImage: coverImage || "",
      format,
      status: status || "Available",
      description:
        description || "No description provided.",
      copies,
      waitlist: [],
    });

    await logActivity(
      `New book added: ${book.title}`
    );

    res.status(201).json(book);
  } catch (err) {
    res.status(500).json({
      message: "Failed to add book",
      error: (err as Error).message,
    });
  }
}

// PATCH /api/books/:id (admin only)
export async function updateBook(req: AuthedRequest, res: Response) {
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  const editableFields = [
    "title", "author", "category", "language", "publisher", "edition",
    "year", "isbn13", "isbn10", "format", "description", "coverImage",
  ] as const;

  for (const field of editableFields) {
    if (Object.prototype.hasOwnProperty.call(req.body, field)) {
      (book as any)[field] = req.body[field];
    }
  }

  const isbn13 = String(book.isbn13 || "").trim();
  const isbn10 = String(book.isbn10 || "").trim();
  const validIsbn = /^\d{13}$/.test(isbn13) || /^\d{10}$/.test(isbn10);
  if (!book.title || !book.author || !book.category || !book.language || !book.format || !validIsbn) {
    return res.status(400).json({ message: "Title, author, category, language, format, and an ISBN are required" });
  }

  await book.save();
  await logActivity(`Book updated: ${book.title}`);
  res.json(book);
}

// DELETE /api/books/:id (admin only)
export async function deleteBook(req: AuthedRequest, res: Response) {
  const book = await Book.findByIdAndDelete(req.params.id);

  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  await logActivity(`Book deleted: ${book.title}`);
  res.json({ message: `Deleted "${book.title}"` });
}

// POST /api/books/:id/copies (admin only)
export async function addCopies(req: AuthedRequest, res: Response) {
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  const count = Number(req.body.numberOfCopies);
  const shelf = String(req.body.shelf || "").trim();

  if (!Number.isInteger(count) || count < 1 || count > 100 || !shelf) {
    return res.status(400).json({ message: "Enter a shelf and a copy count from 1 to 100" });
  }

  const timestamp = Date.now();
  for (let i = 0; i < count; i++) {
    book.copies.push({
      barcode: `LIB-${timestamp}-${book.copies.length + 1}`,
      shelf,
      condition: "New",
      status: "Available",
    });
  }

  syncStatus(book);
  await book.save();
  await logActivity(`${count} ${count === 1 ? "copy" : "copies"} added for ${book.title}`);
  res.status(201).json(book);
}

// POST /api/books/:id/copies/:copyId/issue
export async function issueCopy(
  req: AuthedRequest,
  res: Response
) {
  if (req.user?.role === "admin") {
    return res.status(403).json({ message: "Admins cannot borrow or issue books to themselves." });
  }
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({
      message: "Book not found",
    });
  }

  const copy = book.copies.id(req.params.copyId);

  if (!copy) {
    return res.status(404).json({
      message: "Copy not found",
    });
  }

  if (copy.status !== "Available") {
    return res.status(400).json({
      message: "This copy is not available to issue",
    });
  }

  const user = await User.findById(req.user!.id);

  if (!user) {
    return res.status(404).json({
      message: "User not found",
    });
  }

  copy.status = "Borrowed";
  copy.borrowedBy = user._id;
  copy.borrowerName = user.name;
  copy.borrowDate = new Date();

  copy.dueDate = addDays(
    new Date(),
    LOAN_DAYS
  );

  book.borrowCount += 1;

  syncStatus(book);

  await book.save();

  await logActivity(
    `${book.title} issued to ${user.name}`,
    user._id
  );

  res.json({
    message: `Issued — due back on ${copy.dueDate.toDateString()}`,
    book,
  });
}

// POST /api/books/:id/copies/:copyId/return
export async function returnCopy(
  req: AuthedRequest,
  res: Response
) {
  if (req.user?.role === "admin") {
    return res.status(403).json({ message: "Admins cannot borrow or return books." });
  }
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({
      message: "Book not found",
    });
  }

  const copy = book.copies.id(req.params.copyId);

  if (!copy) {
    return res.status(404).json({
      message: "Copy not found",
    });
  }

  if (copy.status !== "Borrowed") {
    return res.status(400).json({
      message:
        "This copy is not currently borrowed",
    });
  }

  if (
    copy.borrowedBy?.toString() !==
    req.user!.id
  ) {
    return res.status(403).json({
      message:
        "Only the borrower can return this copy",
    });
  }

  const readerNote = String(req.body?.note || "").trim().slice(0, 500);
  book.nextReaderNote = readerNote || "Enjoy this book and pass it on to another reader.";

  const late = overdueDays(copy.dueDate);
  const fine = late * FINE_PER_DAY;

  // Save the borrower BEFORE clearing borrowedBy.
  // This marks the book as read/returned by this user.
  if (copy.borrowedBy) {
    await User.findByIdAndUpdate(
      copy.borrowedBy,
      {
        $inc: {
          readCount: 1,
        },
        $addToSet: {
          readBooks: book._id,
        },
      }
    );
  }

  copy.status = "Available";
  copy.reservedBy = null;
  copy.reservedUntil = null;
  copy.borrowedBy = null;
  copy.borrowerName = null;
  copy.borrowDate = null;
  copy.dueDate = null;

  await logActivity(
    `${book.title} returned${
      late > 0
        ? ` — ₹${fine} late fee`
        : ""
    }`,
    req.user!.id
  );

  // Auto-assign to next person on the waitlist
  if (book.waitlist.length > 0) {
    const next = book.waitlist.shift()!;

    copy.status = "Borrowed";
    copy.borrowedBy = next.user;
    copy.borrowerName = next.name;
    copy.borrowDate = new Date();

    copy.dueDate = addDays(
      new Date(),
      LOAN_DAYS
    );

    await logActivity(
      `${book.title} auto-assigned to ${next.name} from the waitlist`,
      next.user
    );

    await notify(
      next.user,
      `Your waitlisted book "${book.title}" is ready — it has been issued to you`,
      `/books/${book._id}`
    );
  }

  syncStatus(book);

  await book.save();

  res.json({
    message:
      late > 0
        ? `Returned — ₹${fine} late fee applied (${late} day(s) overdue)`
        : "Returned on time — no fine",
    fine,
    book,
  });
}

// POST /api/books/:id/waitlist/join
export async function joinWaitlist(
  req: AuthedRequest,
  res: Response
) {
  if (req.user?.role === "admin") {
    return res.status(403).json({ message: "Admins cannot join a book waitlist." });
  }
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({
      message: "Book not found",
    });
  }

  if (availableCopies(book) > 0) {
    return res.status(400).json({
      message:
        "Copies are currently available — no need to join the waitlist",
    });
  }

  if (
    book.waitlist.some(
      (w) =>
        w.user.toString() ===
        req.user!.id
    )
  ) {
    return res.status(400).json({
      message:
        "You are already on the waitlist for this book",
    });
  }

  const user = await User.findById(
    req.user!.id
  );

  if (!user) {
    return res.status(404).json({
      message: "User not found",
    });
  }

  book.waitlist.push({
    user: user._id,
    name: user.name,
    email: user.email,
    joinedAt: new Date(),
  } as any);

  await book.save();

  await logActivity(
    `${user.name} joined the waitlist for ${book.title}`,
    user._id
  );

  res.json({
    message: "Added to waitlist",
    position: book.waitlist.length,
    book,
  });
}

// POST /api/books/:id/waitlist/leave
export async function leaveWaitlist(
  req: AuthedRequest,
  res: Response
) {
  if (req.user?.role === "admin") {
    return res.status(403).json({ message: "Admins cannot manage a book waitlist." });
  }
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({
      message: "Book not found",
    });
  }

  book.waitlist = book.waitlist.filter(
    (w) =>
      w.user.toString() !==
      req.user!.id
  ) as any;

  await book.save();

  res.json({
    message: "Removed from waitlist",
    book,
  });
}

// GET /api/books/stats/popular
export async function getPopularBooks(
  req: AuthedRequest,
  res: Response
) {
  const maxResults = 25;
  const offset = Math.max(0, parseInt(String(req.query.offset), 10) || 0);
  if (offset >= maxResults) return res.json([]);
  const limit = Math.min(
    maxResults - offset,
    Math.max(1, parseInt(String(req.query.limit), 10) || 6)
  );
  const books = await Book.find()
    .sort({
      borrowCount: -1,
      _id: 1,
    })
    .skip(offset)
    .limit(limit);

  res.json(books);
}

// GET /api/books/stats/top-rated?limit=5[&includeUnrated=true]
// By default only rated books are returned (dashboard panel). With
// includeUnrated=true, unrated books are appended after all rated ones so a
// full list can be shown.
export async function getTopRatedBooks(
  req: AuthedRequest,
  res: Response
) {
  const maxResults = 25;
  const offset = Math.max(0, parseInt(String(req.query.offset), 10) || 0);
  if (offset >= maxResults) return res.json([]);
  const limit = Math.min(
    maxResults - offset,
    Math.max(1, parseInt(String(req.query.limit), 10) || 5)
  );

  // Only rated books belong in the Top Rated list; unrated books are excluded.
  const books = await Book.find({ rating: { $gt: 0 } })
    .sort({ rating: -1, ratingCount: -1, _id: 1 })
    .skip(offset)
    .limit(limit);

  res.json(books);
}

// GET /api/books/stats/categories -> [{ category, count }] (titles per category)
export async function getCategoryCounts(
  _req: AuthedRequest,
  res: Response
) {
  const rows = await Book.aggregate([
    { $group: { _id: "$category", count: { $sum: 1 } } },
    { $sort: { _id: 1 } },
  ]);

  res.json(
    rows.map((row: any) => ({
      category: row._id,
      count: row.count,
    }))
  );
}

// GET /api/books/stats/arrivals (admin)
export async function getNewArrivals(
  req: AuthedRequest,
  res: Response
) {
  const books = await Book.find()
    .sort({
      addedDate: -1,
    })
    .limit(6);

  res.json(books);
}

// GET /api/books/stats/due-soon (admin)
// overdue or due within 3 days
export async function getDueSoon(
  req: AuthedRequest,
  res: Response
) {
  const books = await Book.find({
    "copies.status": "Borrowed",
  });

  const items: any[] = [];

  const soon = addDays(
    new Date(),
    3
  );

  books.forEach((book) => {
    book.copies.forEach((copy) => {
      if (
        copy.status === "Borrowed" &&
        copy.dueDate &&
        new Date(copy.dueDate) <= soon
      ) {
        const daysUntil = Math.ceil(
          (new Date(copy.dueDate).getTime() -
            Date.now()) /
            86400000
        );

        items.push({
          bookId: book._id,
          title: book.title,
          borrowerName:
            copy.borrowerName,
          dueDate: copy.dueDate,
          daysUntil,
        });
      }
    });
  });

  items.sort(
    (a, b) =>
      a.daysUntil - b.daysUntil
  );

  res.json(items.slice(0, 8));
}

// GET /api/books/stats/overview
// categories + formats + totals
export async function getOverviewStats(
  req: AuthedRequest,
  res: Response
) {
  const books = await Book.find();

  const totalTitles = books.length;

  const totalCopies = books.reduce(
    (s, b) =>
      s + b.copies.length,
    0
  );

  const available = books.reduce(
    (s, b) =>
      s + availableCopies(b),
    0
  );

  const borrowed =
    totalCopies - available;

  const byCategory: Record<
    string,
    number
  > = {};

  const byFormat: Record<
    string,
    number
  > = {};

  books.forEach((b) => {
    byCategory[b.category] =
      (byCategory[b.category] || 0) +
      b.copies.length;

    byFormat[b.format] =
      (byFormat[b.format] || 0) +
      b.copies.length;
  });

  res.json({
    totalTitles,
    totalCopies,
    available,
    borrowed,
    byCategory,
    byFormat,
  });
}
