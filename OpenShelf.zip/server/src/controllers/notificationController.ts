import { Response } from "express";
import { Types } from "mongoose";
import { Notification } from "../models/Notification";
import { AuthedRequest } from "../types";
import { sendDueRemindersThrottled } from "../utils/dueReminders";

// GET /api/notifications?limit=5&offset=0
// The bell menu asks for 5; the full Notifications page pages through all of
// them (20 at a time). Without a limit the latest 30 are returned, as before.
export async function getNotifications(req: AuthedRequest, res: Response) {
  const limit = Math.min(50, Math.max(1, parseInt(String(req.query.limit), 10) || 30));
  const rawOffset = parseInt(String(req.query.offset), 10);
  const skip = Number.isFinite(rawOffset) && rawOffset > 0 ? rawOffset : 0;
  const filter = { user: req.user!.id };

  // Opening the bell (first page) makes sure this member's due-date reminders exist.
  if (skip === 0) {
    try {
      await sendDueRemindersThrottled(req.user!.id);
    } catch (err) {
      console.error("Due reminder check failed:", err);
    }
  }

  const [items, unread, total] = await Promise.all([
    Notification.find(filter).sort({ createdAt: -1, _id: -1 }).skip(skip).limit(limit),
    Notification.countDocuments({ user: req.user!.id, read: false }),
    Notification.countDocuments(filter),
  ]);
  res.json({ unread, items, total, hasMore: skip + items.length < total });
}

// POST /api/notifications/read-all
export async function markAllRead(req: AuthedRequest, res: Response) {
  await Notification.updateMany({ user: req.user!.id, read: false }, { read: true });
  res.json({ unread: 0 });
}

// POST /api/notifications/:id/read
export async function markRead(req: AuthedRequest, res: Response) {
  if (!Types.ObjectId.isValid(req.params.id))
    return res.status(400).json({ message: "Invalid id" });
  await Notification.updateOne({ _id: req.params.id, user: req.user!.id }, { read: true });
  res.json({ ok: true });
}

// DELETE /api/notifications — clear everything
export async function clearAll(req: AuthedRequest, res: Response) {
  await Notification.deleteMany({ user: req.user!.id });
  res.json({ unread: 0 });
}
