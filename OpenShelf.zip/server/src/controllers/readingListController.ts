import { Response } from "express";
import { Types } from "mongoose";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { ReadingList } from "../models/ReadingList";
import { AuthedRequest } from "../types";

const isId = (id: string) => Types.ObjectId.isValid(id);
const clean = (v: unknown) => (typeof v === "string" ? v.trim() : "");
const MAX_LISTS = 20;
const MAX_BOOKS = 100;

function shapeList(l: any, userId: string, withBooks = false) {
  const books = Array.isArray(l.books) ? l.books : [];
  return {
    _id: l._id,
    name: l.name,
    description: l.description,
    isPublic: l.isPublic,
    ownerName: l.ownerName,
    mine: l.owner.toString() === userId,
    bookCount: books.length,
    followerCount: l.followers.length,
    following: l.followers.some((f: any) => f.toString() === userId),
    updatedAt: l.updatedAt,
    // For cards: first few covers/ids; for detail: full book summaries
    bookIds: books.map((b: any) => (b._id || b).toString()),
    ...(withBooks
      ? {
          books: books.map((b: any) => ({
            _id: b._id,
            title: b.title,
            author: b.author,
            category: b.category,
            coverImage: b.coverImage,
            isbn13: b.isbn13,
            isbn10: b.isbn10,
            rating: b.rating,
            status: b.status,
          })),
        }
      : {}),
  };
}

// GET /api/lists/mine
export async function getMyLists(req: AuthedRequest, res: Response) {
  const lists = await ReadingList.find({ owner: req.user!.id }).sort({ updatedAt: -1 });
  res.json(lists.map((l) => shapeList(l, req.user!.id)));
}

// GET /api/lists/discover — public lists from other members
export async function discoverLists(req: AuthedRequest, res: Response) {
  const lists = await ReadingList.find({
    isPublic: true,
    owner: { $ne: req.user!.id },
    "books.0": { $exists: true },
  })
    .sort({ updatedAt: -1 })
    .limit(40);
  res.json(lists.map((l) => shapeList(l, req.user!.id)));
}

// GET /api/lists/following
export async function getFollowedLists(req: AuthedRequest, res: Response) {
  const lists = await ReadingList.find({ followers: req.user!.id, isPublic: true }).sort({
    updatedAt: -1,
  });
  res.json(lists.map((l) => shapeList(l, req.user!.id)));
}

// GET /api/lists/containing/:bookId — which of MY lists hold this book
export async function listsContainingBook(req: AuthedRequest, res: Response) {
  if (!isId(req.params.bookId)) return res.status(400).json({ message: "Invalid book id" });
  const lists = await ReadingList.find({ owner: req.user!.id }).sort({ updatedAt: -1 });
  res.json(
    lists.map((l) => ({
      _id: l._id,
      name: l.name,
      isPublic: l.isPublic,
      bookCount: l.books.length,
      hasBook: l.books.some((b) => b.toString() === req.params.bookId),
    }))
  );
}

// GET /api/lists/:id
export async function getList(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid list id" });
  const list = await ReadingList.findById(req.params.id).populate(
    "books",
    "title author category coverImage isbn13 isbn10 rating status"
  );
  if (!list) return res.status(404).json({ message: "List not found" });
  const mine = list.owner.toString() === req.user!.id;
  if (!list.isPublic && !mine) return res.status(403).json({ message: "This list is private" });
  res.json(shapeList(list, req.user!.id, true));
}

// POST /api/lists
export async function createList(req: AuthedRequest, res: Response) {
  const name = clean(req.body.name);
  const description = clean(req.body.description);
  if (name.length < 2 || name.length > 60)
    return res.status(400).json({ message: "List name must be 2–60 characters" });
  if (description.length > 300)
    return res.status(400).json({ message: "Description can be at most 300 characters" });

  const user = await User.findById(req.user!.id).select("name");
  if (!user) return res.status(404).json({ message: "User not found" });

  const count = await ReadingList.countDocuments({ owner: user._id });
  if (count >= MAX_LISTS)
    return res.status(400).json({ message: `You can have at most ${MAX_LISTS} lists` });

  const list = await ReadingList.create({
    owner: user._id,
    ownerName: user.name,
    name,
    description,
    isPublic: Boolean(req.body.isPublic),
  });

  // Optionally add a first book right away
  if (isId(String(req.body.bookId || ""))) {
    const exists = await Book.exists({ _id: req.body.bookId });
    if (exists) {
      list.books.push(new Types.ObjectId(req.body.bookId));
      await list.save();
    }
  }
  res.status(201).json(shapeList(list, req.user!.id));
}

// PATCH /api/lists/:id
export async function updateList(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid list id" });
  const list = await ReadingList.findById(req.params.id);
  if (!list) return res.status(404).json({ message: "List not found" });
  if (list.owner.toString() !== req.user!.id)
    return res.status(403).json({ message: "Only the owner can edit this list" });

  if (req.body.name !== undefined) {
    const name = clean(req.body.name);
    if (name.length < 2 || name.length > 60)
      return res.status(400).json({ message: "List name must be 2–60 characters" });
    list.name = name;
  }
  if (req.body.description !== undefined) {
    const description = clean(req.body.description);
    if (description.length > 300)
      return res.status(400).json({ message: "Description can be at most 300 characters" });
    list.description = description;
  }
  if (typeof req.body.isPublic === "boolean") {
    list.isPublic = req.body.isPublic;
    // Going private removes everyone else's follow
    if (!list.isPublic) list.followers = [];
  }
  list.updatedAt = new Date();
  await list.save();
  res.json(shapeList(list, req.user!.id));
}

// DELETE /api/lists/:id
export async function deleteList(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid list id" });
  const list = await ReadingList.findById(req.params.id);
  if (!list) return res.status(404).json({ message: "List not found" });
  if (list.owner.toString() !== req.user!.id && req.user!.role !== "admin")
    return res.status(403).json({ message: "Only the owner can delete this list" });
  await list.deleteOne();
  res.json({ message: "List deleted" });
}

// POST /api/lists/:id/books  { bookId }
export async function addBookToList(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id) || !isId(String(req.body.bookId || "")))
    return res.status(400).json({ message: "Invalid id" });
  const list = await ReadingList.findById(req.params.id);
  if (!list) return res.status(404).json({ message: "List not found" });
  if (list.owner.toString() !== req.user!.id)
    return res.status(403).json({ message: "Only the owner can edit this list" });

  const book = await Book.findById(req.body.bookId).select("_id");
  if (!book) return res.status(404).json({ message: "Book not found" });
  if (list.books.some((b) => b.toString() === book._id.toString()))
    return res.status(400).json({ message: "Already on this list" });
  if (list.books.length >= MAX_BOOKS)
    return res.status(400).json({ message: `A list can hold at most ${MAX_BOOKS} books` });

  list.books.push(book._id);
  list.updatedAt = new Date();
  await list.save();
  res.json({ message: `Added to "${list.name}"`, bookCount: list.books.length });
}

// DELETE /api/lists/:id/books/:bookId
export async function removeBookFromList(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id) || !isId(req.params.bookId))
    return res.status(400).json({ message: "Invalid id" });
  const list = await ReadingList.findById(req.params.id);
  if (!list) return res.status(404).json({ message: "List not found" });
  if (list.owner.toString() !== req.user!.id)
    return res.status(403).json({ message: "Only the owner can edit this list" });

  list.books = list.books.filter((b) => b.toString() !== req.params.bookId);
  list.updatedAt = new Date();
  await list.save();
  res.json({ message: `Removed from "${list.name}"`, bookCount: list.books.length });
}

// POST /api/lists/:id/follow — toggle
export async function toggleFollowList(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid list id" });
  const list = await ReadingList.findById(req.params.id);
  if (!list) return res.status(404).json({ message: "List not found" });
  if (!list.isPublic) return res.status(403).json({ message: "This list is private" });
  if (list.owner.toString() === req.user!.id)
    return res.status(400).json({ message: "You can't follow your own list" });

  const already = list.followers.some((f) => f.toString() === req.user!.id);
  await ReadingList.updateOne(
    { _id: list._id },
    already
      ? { $pull: { followers: req.user!.id } }
      : { $addToSet: { followers: req.user!.id } }
  );
  res.json({
    following: !already,
    followerCount: list.followers.length + (already ? -1 : 1),
  });
}
