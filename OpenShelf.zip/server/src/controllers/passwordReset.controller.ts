
import type { Request, Response } from "express";
import crypto from "node:crypto";
import { User } from "../models/User";
import { sendPasswordResetEmail } from "../config/mailer";

export async function forgotPassword(req: Request, res: Response) {
  try {
    const email =
      typeof req.body?.email === "string"
        ? req.body.email.trim().toLowerCase()
        : "";

    if (!email) {
      return res.status(400).json({
        message: "Please enter your email address.",
      });
    }

    const clientUrl = process.env.CLIENT_URL;

    if (!clientUrl) {
      console.error("CLIENT_URL is missing from .env");
      return res.status(500).json({
        message: "Password reset is not configured.",
      });
    }

    const genericMessage =
      "If an account exists for that email, a reset link will be sent.";

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(200).json({ message: genericMessage });
    }

    // Generate a secure, random token.
    const token = crypto.randomBytes(32).toString("hex");

    // Store only the hash of the token in MongoDB.
    const tokenHash = crypto
      .createHash("sha256")
      .update(token)
      .digest("hex");

    user.set({
      resetPasswordTokenHash: tokenHash,
      resetPasswordExpires: new Date(Date.now() + 15 * 60 * 1000),
    });

    await user.save();

    const resetUrl =
      `${clientUrl.replace(/\/$/, "")}/reset-password/${token}`;

    try {
      await sendPasswordResetEmail(user.email, resetUrl);
    } catch (emailError) {
      // Invalidate the token if the email fails.
      user.set({
        resetPasswordTokenHash: undefined,
        resetPasswordExpires: undefined,
      });

      await user.save();

      console.error("Password reset email failed:", emailError);

      return res.status(502).json({
        message: "Unable to send the email. Please try again later.",
      });
    }

    return res.status(200).json({ message: genericMessage });
  } catch (error) {
    console.error("Forgot password error:", error);

    return res.status(500).json({
      message: "Something went wrong. Please try again.",
    });
  }
}

export async function resetPassword(req: Request, res: Response) {
  try {
    const token = req.params.token;
    const password = req.body?.password;

    if (
      typeof token !== "string" ||
      typeof password !== "string" ||
      password.length < 8 ||
      password.length > 72
    ) {
      return res.status(400).json({
        message: "Password must be between 8 and 72 characters.",
      });
    }

    const tokenHash = crypto
      .createHash("sha256")
      .update(token)
      .digest("hex");

    const user = await User.findOne({
      resetPasswordTokenHash: tokenHash,
      resetPasswordExpires: { $gt: new Date() },
    }).select("+resetPasswordTokenHash +resetPasswordExpires");

    if (!user) {
      return res.status(400).json({
        message: "The reset link is invalid or has expired.",
      });
    }

    // User.ts hashes modified passwords automatically in pre("save").
    user.password = password;

    // Prevent this token from being reused.
    user.set({
      resetPasswordTokenHash: undefined,
      resetPasswordExpires: undefined,
    });

    await user.save();

    return res.status(200).json({
      message: "Password reset successfully. You can now log in.",
    });
  } catch (error) {
    console.error("Reset password error:", error);

    return res.status(500).json({
      message: "Unable to reset your password right now.",
    });
  }
}
