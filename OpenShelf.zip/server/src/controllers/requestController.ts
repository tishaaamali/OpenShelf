import { Response } from "express";
import crypto from "crypto";
import { Types } from "mongoose";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { BookRequest } from "../models/BookRequest";
import { logActivity } from "../models/ActivityLog";
import { AuthedRequest } from "../types";
import { LOAN_DAYS, addDays, syncStatus } from "./bookController";
import { expireReservations } from "../utils/expireReservations";

const REQUEST_HOURS = 1;

// Accept either the bare token or the "OSREQ:<token>" string stored in the QR.
function cleanToken(raw: unknown): string {
  if (typeof raw !== "string") return "";
  return raw.trim().replace(/^OSREQ:/i, "");
}

// POST /api/requests  { bookId }
export async function createRequest(req: AuthedRequest, res: Response) {
  if (req.user?.role === "admin") {
    return res.status(403).json({ message: "Admins cannot request or borrow books." });
  }

  const { bookId } = req.body;
  if (!Types.ObjectId.isValid(String(bookId))) {
    return res.status(400).json({ message: "A valid book is required" });
  }

  const userId = req.user!.id;
  let book = await Book.findById(bookId);
  if (!book) return res.status(404).json({ message: "Book not found" });

  if (book.copies.some((c) => c.status === "Borrowed" && c.borrowedBy?.toString() === userId)) {
    return res.status(409).json({ message: "You already have a copy of this book" });
  }
  await expireReservations({ user: userId, book: book._id });
  await expireReservations({ book: book._id });
  book = (await Book.findById(book._id)) || book;

  const existing = await BookRequest.findOne({ user: userId, book: book._id, status: "Pending" });
  if (existing) {
    return res.json(toUserView(existing, book));
  }

  const requestedCopyId = req.body?.copyId;
  const copy = book.copies.find((c) => c.status === "Available" && (!requestedCopyId || c._id?.toString() === String(requestedCopyId)));
  if (!copy) {
    return res.status(409).json({
      message: "No copies are available right now — join the waitlist instead",
    });
  }

  const reservationUntil = new Date(Date.now() + REQUEST_HOURS * 3600 * 1000);
  // Atomically reserve this exact embedded copy so parallel requests cannot claim it.
  const reserved = await Book.findOneAndUpdate(
    { _id: book._id, copies: { $elemMatch: { _id: copy._id, status: "Available" } } },
    { $set: {
      "copies.$.status": "Reserved",
      "copies.$.reservedBy": new Types.ObjectId(userId),
      "copies.$.reservedUntil": reservationUntil,
    } },
    { new: true }
  );
  if (!reserved) return res.status(409).json({ message: "That copy was just reserved. Please try again." });
  syncStatus(reserved);
  await reserved.save();

  try {
    const created = await BookRequest.create({
      user: userId,
      book: book._id,
      copyId: copy._id,
      token: crypto.randomBytes(24).toString("hex"),
      expiresAt: reservationUntil,
    });
    await logActivity(`${book.title} requested — QR generated`, userId);
    return res.status(201).json(toUserView(created, book));
  } catch (err: any) {
    // Lost a race with a parallel request: return the winner.
    if (err?.code === 11000) {
      const freshBook = await Book.findById(book._id);
      const freshCopy = freshBook?.copies.id(copy._id);
      if (freshBook && freshCopy?.status === "Reserved" && freshCopy.reservedBy?.toString() === userId) {
        freshCopy.status = "Available";
        freshCopy.reservedBy = null;
        freshCopy.reservedUntil = null;
        syncStatus(freshBook);
        await freshBook.save();
      }
      const again = await BookRequest.findOne({ user: userId, book: book._id, status: "Pending" });
      if (again) return res.json(toUserView(again, book));
    }
    const freshBook = await Book.findById(book._id);
    const freshCopy = freshBook?.copies.id(copy._id);
    if (freshBook && freshCopy?.status === "Reserved" && freshCopy.reservedBy?.toString() === userId) {
      freshCopy.status = "Available";
      freshCopy.reservedBy = null;
      freshCopy.reservedUntil = null;
      syncStatus(freshBook);
      await freshBook.save();
    }
    throw err;
  }
}

function toUserView(r: any, book: any) {
  return {
    _id: r._id,
    bookId: book._id,
    title: book.title,
    author: book.author,
    status: r.status,
    requestedAt: r.requestedAt,
    expiresAt: r.expiresAt,
    issuedAt: r.issuedAt || null,
    // The token is only handed back while it can still be used.
    token: r.status === "Pending" ? r.token : null,
  };
}

// GET /api/requests/mine
export async function getMyRequests(req: AuthedRequest, res: Response) {
  await expireReservations({ user: req.user!.id });
  const items = await BookRequest.find({ user: req.user!.id })
    .sort({ requestedAt: -1 })
    .limit(20)
    .populate("book", "title author");
  res.json(items.filter((r: any) => r.book).map((r: any) => toUserView(r, r.book)));
}

// POST /api/requests/:id/cancel
export async function cancelRequest(req: AuthedRequest, res: Response) {
  if (!Types.ObjectId.isValid(req.params.id)) {
    return res.status(400).json({ message: "Invalid request id" });
  }
  const updated = await BookRequest.findOneAndUpdate(
    { _id: req.params.id, user: req.user!.id, status: "Pending" },
    { $set: { status: "Cancelled" } },
    { new: true }
  );
  if (!updated) {
    return res.status(409).json({ message: "Only your own pending requests can be cancelled" });
  }
  const book = await Book.findById(updated.book);
  const copy = updated.copyId ? book?.copies.id(updated.copyId) : null;
  if (book && copy?.status === "Reserved" && copy.reservedBy?.toString() === req.user!.id) {
    copy.status = "Available";
    copy.reservedBy = null;
    copy.reservedUntil = null;
    syncStatus(book);
    await book.save();
  }
  res.json({ message: "Request cancelled" });
}

function reasonFor(status: string): string {
  switch (status) {
    case "Issued":
      return "This request has already been issued";
    case "Cancelled":
      return "This request was cancelled by the member";
    case "Expired":
      return "This request has expired — ask the member to request again";
    default:
      return "";
  }
}

// GET /api/requests/lookup/:token  (admin) — details shown after a scan, before issuing
export async function lookupRequest(req: AuthedRequest, res: Response) {
  const token = cleanToken(req.params.token);
  if (!/^[a-f0-9]{48}$/i.test(token)) {
    return res.status(400).json({ message: "This is not a valid OpenShelf request code" });
  }
  await expireReservations({ token });

  const r: any = await BookRequest.findOne({ token })
    .populate("book", "title author copies")
    .populate("user", "name email");
  if (!r || !r.book || !r.user) {
    return res.status(404).json({ message: "No request matches this code" });
  }

  const available = r.book.copies.filter((c: any) => c.status === "Available").length;
  const reservedCopy = r.book.copies.find((c: any) => String(c._id) === String(r.copyId));
  let canIssue = r.status === "Pending" && reservedCopy?.status === "Reserved" && reservedCopy.reservedBy?.toString() === r.user._id.toString() && !!reservedCopy.reservedUntil && new Date(reservedCopy.reservedUntil).getTime() > Date.now();
  let reason = reasonFor(r.status);
  if (r.status === "Pending" && !canIssue) reason = "The reserved copy is no longer available. Ask the member to request again.";

  res.json({
    requestId: r._id,
    status: r.status,
    requestedAt: r.requestedAt,
    expiresAt: r.expiresAt,
    issuedAt: r.issuedAt || null,
    book: { id: r.book._id, title: r.book.title, author: r.book.author, availableCopies: available },
    member: { name: r.user.name, email: r.user.email },
    canIssue,
    reason,
  });
}

// POST /api/requests/issue  { token }  (admin)
export async function issueRequest(req: AuthedRequest, res: Response) {
  const token = cleanToken(req.body.token);
  if (!/^[a-f0-9]{48}$/i.test(token)) {
    return res.status(400).json({ message: "This is not a valid OpenShelf request code" });
  }
  await expireReservations({ token });

  // Atomic claim: only ONE concurrent scan can move Pending -> Issued.
  const claimed = await BookRequest.findOneAndUpdate(
    { token, status: "Pending", expiresAt: { $gt: new Date() } },
    { $set: { status: "Issued", issuedAt: new Date(), issuedBy: req.user!.id } },
    { new: true }
  );

  if (!claimed) {
    const existing = await BookRequest.findOne({ token });
    if (!existing) return res.status(404).json({ message: "No request matches this code" });
    return res.status(409).json({ message: reasonFor(existing.status) || "This request cannot be issued" });
  }

  const rollback = () =>
    BookRequest.updateOne(
      { _id: claimed._id },
      { $set: { status: "Pending", issuedAt: null, issuedBy: null } }
    );

  try {
    const member = await User.findById(claimed.user);
    let book = await Book.findById(claimed.book);
    if (!member || !book) {
      await rollback();
      return res.status(404).json({ message: "Member or book no longer exists" });
    }

    // Issue only the physical copy reserved by this QR request.
    let copyId: Types.ObjectId | null = null;
    const now = new Date();
    const due = addDays(now, LOAN_DAYS);
    const candidate = claimed.copyId ? book.copies.id(claimed.copyId) : null;
    if (candidate && candidate.status === "Reserved" && candidate.reservedBy?.toString() === member.id && candidate.reservedUntil && candidate.reservedUntil > now) {
      const hit = await Book.findOneAndUpdate(
        { _id: book._id, copies: { $elemMatch: { _id: candidate._id, status: "Reserved", reservedBy: member._id, reservedUntil: { $gt: now } } } },
        {
          $set: {
            "copies.$.status": "Borrowed",
            "copies.$.reservedBy": null,
            "copies.$.reservedUntil": null,
            "copies.$.borrowedBy": member._id,
            "copies.$.borrowerName": member.name,
            "copies.$.borrowDate": now,
            "copies.$.dueDate": due,
          },
          $inc: { borrowCount: 1 },
        }
      );
      if (hit) copyId = candidate._id as Types.ObjectId;
    }

    if (!copyId) {
      if (candidate?.status === "Reserved" && candidate.reservedBy?.toString() === member.id) {
        candidate.status = "Available";
        candidate.reservedBy = null;
        candidate.reservedUntil = null;
        await book.save();
      }
      await BookRequest.updateOne({ _id: claimed._id }, { $set: { status: "Expired", issuedAt: null, issuedBy: null } });
      return res.status(409).json({ message: "This request's reserved copy is no longer available. Please request again." });
    }

    const fresh = await Book.findById(book._id);
    if (fresh) {
      syncStatus(fresh);
      await fresh.save();
    }
    await BookRequest.updateOne({ _id: claimed._id }, { $set: { copyId } });
    await logActivity(`${book.title} issued to ${member.name} via QR request`, member._id);

    res.json({
      message: `Issued "${book.title}" to ${member.name} — due ${due.toDateString()}`,
      dueDate: due,
    });
  } catch (err) {
    await rollback();
    throw err;
  }
}
