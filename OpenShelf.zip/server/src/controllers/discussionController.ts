import { Response } from "express";
import { Types } from "mongoose";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { Discussion } from "../models/Discussion";
import { notify } from "../models/Notification";
import { AuthedRequest } from "../types";

const isId = (id: string) => Types.ObjectId.isValid(id);
const clean = (v: unknown) => (typeof v === "string" ? v.trim() : "");

function shapeThread(d: any, userId: string, full = false) {
  return {
    _id: d._id,
    bookId: d.book?._id || d.book,
    bookTitle: d.book?.title,
    bookAuthor: d.book?.author,
    userName: d.userName,
    mine: d.user.toString() === userId,
    title: d.title,
    body: full ? d.body : d.body.slice(0, 220),
    spoiler: d.spoiler,
    pinned: d.pinned,
    locked: d.locked,
    upvoteCount: d.upvotes.length,
    upvoted: d.upvotes.some((u: any) => u.toString() === userId),
    replyCount: d.replies.length,
    lastActivityAt: d.lastActivityAt,
    createdAt: d.createdAt,
    ...(full
      ? {
          replies: d.replies.map((r: any) => ({
            _id: r._id,
            userName: r.userName,
            mine: r.user.toString() === userId,
            body: r.body,
            spoiler: r.spoiler,
            createdAt: r.createdAt,
          })),
        }
      : {}),
  };
}

// GET /api/discussions — latest conversations across all books (hub page)
export async function getAllDiscussions(req: AuthedRequest, res: Response) {
  const sort = req.query.sort === "top" ? "top" : "recent";
  const limit = Math.min(50, Math.max(1, parseInt(String(req.query.limit), 10) || 10));
  const offset = Math.max(0, parseInt(String(req.query.offset), 10) || 0);
  const query = clean(req.query.q).toLowerCase();

  // Sort before slicing so each page follows the same global ordering.
  const threads = await Discussion.find({})
    .populate("book", "title author")
    .sort({ pinned: -1, lastActivityAt: -1 });

  let shaped = threads.map((t) => shapeThread(t, req.user!.id));
  if (sort === "top") {
    shaped = shaped.sort(
      (a, b) => b.upvoteCount + b.replyCount - (a.upvoteCount + a.replyCount)
    );
  }
  if (query) {
    shaped = shaped.filter((t) =>
      t.title.toLowerCase().includes(query) ||
      (t.bookTitle || "").toLowerCase().includes(query) ||
      (t.body || "").toLowerCase().includes(query)
    );
  }
  res.json(shaped.slice(offset, offset + limit));
}

// GET /api/books/:id/discussions
export async function getBookDiscussions(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid book id" });
  const threads = await Discussion.find({ book: req.params.id })
    .populate("book", "title author")
    .sort({ pinned: -1, lastActivityAt: -1 })
    .limit(100);
  res.json(threads.map((t) => shapeThread(t, req.user!.id)));
}

// POST /api/books/:id/discussions
export async function createDiscussion(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid book id" });
  const title = clean(req.body.title);
  const body = clean(req.body.body);
  if (title.length < 3 || title.length > 120)
    return res.status(400).json({ message: "Title must be 3–120 characters" });
  if (body.length < 3 || body.length > 2000)
    return res.status(400).json({ message: "Message must be 3–2000 characters" });

  const [book, user] = await Promise.all([
    Book.findById(req.params.id).select("_id title"),
    User.findById(req.user!.id).select("name isBlocked"),
  ]);
  if (!book) return res.status(404).json({ message: "Book not found" });
  if (!user) return res.status(404).json({ message: "User not found" });
  if (user.isBlocked) return res.status(403).json({ message: "Your account cannot post right now" });

  const thread = await Discussion.create({
    book: book._id,
    user: user._id,
    userName: user.name,
    title,
    body,
    spoiler: Boolean(req.body.spoiler),
  });
  res.status(201).json(shapeThread(thread, req.user!.id, true));
}

// GET /api/discussions/:id
export async function getDiscussion(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid id" });
  const thread = await Discussion.findById(req.params.id).populate("book", "title author");
  if (!thread) return res.status(404).json({ message: "Discussion not found" });
  res.json(shapeThread(thread, req.user!.id, true));
}

// POST /api/discussions/:id/replies
export async function addReply(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid id" });
  const body = clean(req.body.body);
  if (body.length < 1 || body.length > 1000)
    return res.status(400).json({ message: "Reply must be 1–1000 characters" });

  const [thread, user] = await Promise.all([
    Discussion.findById(req.params.id).populate("book", "title author"),
    User.findById(req.user!.id).select("name isBlocked"),
  ]);
  if (!thread) return res.status(404).json({ message: "Discussion not found" });
  if (!user) return res.status(404).json({ message: "User not found" });
  if (user.isBlocked) return res.status(403).json({ message: "Your account cannot post right now" });
  if (thread.locked) return res.status(403).json({ message: "This discussion is locked" });

  thread.replies.push({
    user: user._id,
    userName: user.name,
    body,
    spoiler: Boolean(req.body.spoiler),
  } as any);
  thread.lastActivityAt = new Date();
  await thread.save();

  // Tell the thread author (unless they replied to themselves)
  if (thread.user.toString() !== req.user!.id) {
    await notify(
      thread.user,
      `${user.name} replied to your discussion "${thread.title}"`,
      `/discussions/${thread._id}`
    );
  }

  // ...and everyone else who has already replied in this discussion, once each.
  const alreadyTold = new Set<string>([req.user!.id, thread.user.toString()]);
  for (const earlier of thread.replies.slice(0, -1)) {
    const id = earlier.user.toString();
    if (alreadyTold.has(id)) continue;
    alreadyTold.add(id);
    await notify(
      earlier.user,
      `${user.name} also replied in the discussion "${thread.title}"`,
      `/discussions/${thread._id}`
    );
  }

  res.status(201).json(shapeThread(thread, req.user!.id, true));
}

// POST /api/discussions/:id/upvote — toggle
export async function toggleUpvote(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid id" });
  const thread = await Discussion.findById(req.params.id).select("upvotes");
  if (!thread) return res.status(404).json({ message: "Discussion not found" });

  const already = thread.upvotes.some((u) => u.toString() === req.user!.id);
  await Discussion.updateOne(
    { _id: thread._id },
    already
      ? { $pull: { upvotes: req.user!.id } }
      : { $addToSet: { upvotes: req.user!.id } }
  );
  res.json({
    upvoted: !already,
    upvoteCount: thread.upvotes.length + (already ? -1 : 1),
  });
}

// PATCH /api/discussions/:id/moderate  (admin) — pin / lock
export async function moderateDiscussion(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid id" });
  const thread = await Discussion.findById(req.params.id).populate("book", "title author");
  if (!thread) return res.status(404).json({ message: "Discussion not found" });

  if (typeof req.body.pinned === "boolean") thread.pinned = req.body.pinned;
  if (typeof req.body.locked === "boolean") thread.locked = req.body.locked;
  await thread.save();
  res.json(shapeThread(thread, req.user!.id, true));
}

// DELETE /api/discussions/:id  (author or admin)
export async function deleteDiscussion(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid id" });
  const thread = await Discussion.findById(req.params.id);
  if (!thread) return res.status(404).json({ message: "Discussion not found" });
  if (thread.user.toString() !== req.user!.id && req.user!.role !== "admin")
    return res.status(403).json({ message: "You can only delete your own discussions" });

  await thread.deleteOne();
  res.json({ message: "Discussion deleted" });
}

// DELETE /api/discussions/:id/replies/:replyId  (author or admin)
export async function deleteReply(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id) || !isId(req.params.replyId))
    return res.status(400).json({ message: "Invalid id" });
  const thread = await Discussion.findById(req.params.id).populate("book", "title author");
  if (!thread) return res.status(404).json({ message: "Discussion not found" });

  const reply = thread.replies.id(req.params.replyId);
  if (!reply) return res.status(404).json({ message: "Reply not found" });
  if (reply.user.toString() !== req.user!.id && req.user!.role !== "admin")
    return res.status(403).json({ message: "You can only delete your own replies" });

  reply.deleteOne();
  await thread.save();
  res.json(shapeThread(thread, req.user!.id, true));
}
