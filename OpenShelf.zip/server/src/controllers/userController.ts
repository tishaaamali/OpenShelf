import { Response } from "express";
import { Types } from "mongoose";
import { User } from "../models/User";
import { AuthedRequest } from "../types";

// GET /api/users?page=1&search=...&status=active|blocked (admin only)
export async function getUsers(req: AuthedRequest, res: Response) {
  try {
    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = 10;
    const search = typeof req.query.search === "string" ? req.query.search.trim() : "";
    const skip = (page - 1) * limit;
    const safeSearch = search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const status = typeof req.query.status === "string" ? req.query.status.trim().toLowerCase() : "";
    const filter: Record<string, any> = search
      ? { $or: [
          { name: { $regex: safeSearch, $options: "i" } },
          { email: { $regex: safeSearch, $options: "i" } },
        ] }
      : {};
    // Active = not blocked; Blocked = blocked. Anything else means "all users".
    if (status === "active") filter.isBlocked = { $ne: true };
    else if (status === "blocked") filter.isBlocked = true;

    const [users, totalUsers] = await Promise.all([
      User.find(filter).select("-password -resetPasswordTokenHash -resetPasswordExpires")
        .sort({ _id: -1 }).skip(skip).limit(limit).lean(),
      User.countDocuments(filter),
    ]);

    res.json({ users, totalUsers, totalPages: Math.ceil(totalUsers / limit), currentPage: page, limit });
  } catch (error) {
    console.error("Failed to load users:", error);
    res.status(500).json({ message: "Failed to load users" });
  }
}

function validId(id: string) {
  return Types.ObjectId.isValid(id);
}

// PATCH /api/users/:id (admin only)
export async function updateUser(req: AuthedRequest, res: Response) {
  try {
    const { id } = req.params;
    if (!validId(id)) return res.status(400).json({ message: "Invalid user ID" });
    const target = await User.findById(id);
    if (!target) return res.status(404).json({ message: "User not found" });
    if (target.role === "admin") return res.status(403).json({ message: "Admin accounts are protected" });

    const name = typeof req.body.name === "string" ? req.body.name.trim() : target.name;
    const email = typeof req.body.email === "string" ? req.body.email.trim().toLowerCase() : target.email;
    const phone = typeof req.body.phone === "string" ? req.body.phone.trim() : target.phone;
    if (!name || !email) return res.status(400).json({ message: "Name and email are required" });

    const duplicate = await User.findOne({ email, _id: { $ne: target._id } }).select("_id").lean();
    if (duplicate) return res.status(409).json({ message: "Another account already uses this email" });

    target.name = name;
    target.email = email;
    target.phone = phone || undefined;
    await target.save();
    const safeUser = target.toObject() as unknown as Record<string, unknown>;
    delete safeUser.password;
    delete safeUser.resetPasswordTokenHash;
    delete safeUser.resetPasswordExpires;
    res.json({ message: "User updated successfully", user: safeUser });
  } catch (error: any) {
    if (error?.code === 11000) return res.status(409).json({ message: "Another account already uses this email" });
    console.error("Failed to update user:", error);
    res.status(500).json({ message: "Failed to update user" });
  }
}

// PATCH /api/users/:id/block (admin only)
export async function setUserBlocked(req: AuthedRequest, res: Response) {
  try {
    const { id } = req.params;
    if (!validId(id)) return res.status(400).json({ message: "Invalid user ID" });
    const isBlocked = req.body?.isBlocked;
    if (typeof isBlocked !== "boolean") return res.status(400).json({ message: "isBlocked must be true or false" });
    if (req.user?.id === id) return res.status(403).json({ message: "You cannot block your own account" });

    const target = await User.findById(id);
    if (!target) return res.status(404).json({ message: "User not found" });
    if (target.role === "admin") return res.status(403).json({ message: "Admin accounts are protected" });

    target.isBlocked = isBlocked;
    await target.save();
    res.json({ message: `User ${isBlocked ? "blocked" : "unblocked"} successfully`, user: { _id: target._id, name: target.name, email: target.email, isBlocked: target.isBlocked } });
  } catch (error) {
    console.error("Failed to update user block status:", error);
    res.status(500).json({ message: "Failed to update user status" });
  }
}

// DELETE /api/users/:id (admin only)
export async function deleteUser(req: AuthedRequest, res: Response) {
  try {
    const { id } = req.params;
    if (!validId(id)) return res.status(400).json({ message: "Invalid user ID" });
    if (req.user?.id === id) return res.status(403).json({ message: "You cannot delete your own account" });

    const target = await User.findById(id).select("_id role name");
    if (!target) return res.status(404).json({ message: "User not found" });
    if (target.role === "admin") return res.status(403).json({ message: "Admin accounts are protected" });

    await User.deleteOne({ _id: target._id });
    res.json({ message: "User deleted successfully", id: target._id });
  } catch (error) {
    console.error("Failed to delete user:", error);
    res.status(500).json({ message: "Failed to delete user" });
  }
}
