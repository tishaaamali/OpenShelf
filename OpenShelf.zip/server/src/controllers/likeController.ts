import { Response } from "express";
import { Types } from "mongoose";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { AuthedRequest } from "../types";

const MAX_SUGGESTIONS = 6;

async function buildSuggestions(bookId: Types.ObjectId, userId: string) {
  const [book, user] = await Promise.all([Book.findById(bookId), User.findById(userId)]);
  if (!book || !user) return [];

  // Categories / authors of everything the member liked (this book included).
  const liked = await Book.find({ _id: { $in: user.likedBooks } }).select("category author");
  const likedCategories = new Set(liked.map((b) => b.category));
  const likedAuthors = new Set(liked.map((b) => b.author));
  const skip = new Set<string>([book._id.toString(), ...user.likedBooks.map((id) => id.toString())]);

  const candidates = await Book.find({ _id: { $nin: Array.from(skip) } }).select(
    "title author category isbn13 isbn10 rating ratingCount status"
  );

  return candidates
    .map((c) => {
      let score = 0;
      if (c.author === book.author) score += 4;
      if (c.category === book.category) score += 3;
      if (likedAuthors.has(c.author)) score += 2;
      if (likedCategories.has(c.category)) score += 1;
      score += (c.rating || 0) / 5; // tie-breaker: better rated first
      return { c, score };
    })
    .filter((x) => x.score >= 1)
    .sort((a, b) => b.score - a.score)
    .slice(0, MAX_SUGGESTIONS)
    .map((x) => x.c);
}

// GET /api/books/:id/like
export async function getLikeStatus(req: AuthedRequest, res: Response) {
  if (!Types.ObjectId.isValid(req.params.id)) return res.status(400).json({ message: "Invalid book id" });
  const user = await User.findById(req.user!.id).select("likedBooks");
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json({ liked: user.likedBooks.some((id) => id.toString() === req.params.id) });
}

// POST /api/books/:id/like — toggles the like
export async function toggleLike(req: AuthedRequest, res: Response) {
  if (!Types.ObjectId.isValid(req.params.id)) return res.status(400).json({ message: "Invalid book id" });
  const book = await Book.findById(req.params.id).select("_id");
  if (!book) return res.status(404).json({ message: "Book not found" });

  const user = await User.findById(req.user!.id).select("likedBooks");
  if (!user) return res.status(404).json({ message: "User not found" });

  const already = user.likedBooks.some((id) => id.toString() === req.params.id);
  await User.updateOne(
    { _id: user._id },
    already ? { $pull: { likedBooks: book._id } } : { $addToSet: { likedBooks: book._id } }
  );
  res.json({ liked: !already });
}

// GET /api/books/:id/suggestions
export async function getSuggestions(req: AuthedRequest, res: Response) {
  if (!Types.ObjectId.isValid(req.params.id)) return res.status(400).json({ message: "Invalid book id" });
  const suggestions = await buildSuggestions(new Types.ObjectId(req.params.id), req.user!.id);
  res.json(suggestions);
}
