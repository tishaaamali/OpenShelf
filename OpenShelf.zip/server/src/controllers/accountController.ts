import { Response } from "express";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { Rating } from "../models/ratingModel";
import { AuthedRequest } from "../types";
import { isValidEmail, isValidPhone } from "../utils/validators";
import { splitName } from "../utils/userHelpers";

const FINE_PER_DAY = Number(process.env.FINE_PER_DAY || 50);

function overdueDays(dueDate?: Date | null): number {
  if (!dueDate) return 0;
  const diff = Math.floor((Date.now() - new Date(dueDate).getTime()) / 86400000);
  return diff > 0 ? diff : 0;
}

// GET /api/account/me — borrowed books, waitlist status, fees, books read
export async function getMyAccountSummary(req: AuthedRequest, res: Response) {
  const userId = req.user!.id;
  const user = await User.findById(userId).select("-password");
  if (!user) return res.status(404).json({ message: "User not found" });

  // Administrator accounts are for library management, not personal loans.
  // Do not return borrowing records, request-related summaries, or reviews to admins.
  const isAdmin = user.role === "admin";
  const books = isAdmin ? [] : await Book.find();

  const borrowed: any[] = [];
  const waitlisted: any[] = [];

  books.forEach((book) => {
    book.copies.forEach((copy) => {
      if (copy.status === "Borrowed" && copy.borrowedBy?.toString() === userId) {
        const late = overdueDays(copy.dueDate);
        borrowed.push({
          bookId: book._id,
          title: book.title,
          author: book.author,
          coverImage: (book as any).coverImage || "",
          isbn13: (book as any).isbn13 || "",
          isbn10: (book as any).isbn10 || "",
          dueDate: copy.dueDate,
          daysOverdue: late,
          fine: late * FINE_PER_DAY,
        });
      }
    });

    const idx = book.waitlist.findIndex((w) => w.user.toString() === userId);
    if (idx >= 0) {
      waitlisted.push({
        bookId: book._id,
        title: book.title,
        position: idx + 1,
        totalWaiting: book.waitlist.length,
      });
    }
  });

  const myRatings = isAdmin
    ? []
    : await Rating.find({ user: userId })
        .sort({ createdAt: -1 })
        .populate("book", "title author");
  const reviews = myRatings
    .filter((r: any) => r.book)
    .map((r: any) => ({
      bookId: r.book._id,
      title: r.book.title,
      author: r.book.author,
      rating: r.rating,
      review: r.review || "",
      createdAt: r.createdAt,
    }));

  const pendingFees = borrowed.reduce((sum, b) => sum + b.fine, 0);
  const { firstName, lastName } = splitName(user);

  res.json({
    profile: {
      name: user.name,
      firstName,
      lastName,
      email: user.email,
      phone: user.phone || "",
      role: user.role,
      since: user.createdAt,
    },
    booksRead: isAdmin ? 0 : user.readCount,
    borrowed,
    waitlisted,
    reviews,
    pendingFees,
  });
}

// PUT /api/account/me — update first name, last name, email, phone
export async function updateMyProfile(req: AuthedRequest, res: Response) {
  const { firstName, lastName, email, phone } = req.body;
  const user = await User.findById(req.user!.id);
  if (!user) return res.status(404).json({ message: "User not found" });

  const current = splitName(user);
  const first = firstName !== undefined ? String(firstName).trim() : current.firstName;
  const last = lastName !== undefined ? String(lastName).trim() : current.lastName;
  if (!first || !last) {
    return res.status(400).json({ message: "First name and last name are required" });
  }

  if (email !== undefined) {
    const mail = String(email).trim().toLowerCase();
    if (!isValidEmail(mail)) {
      return res.status(400).json({ message: "Enter a valid email address" });
    }
    if (mail !== user.email) {
      const taken = await User.findOne({ email: mail, _id: { $ne: user._id } });
      if (taken) return res.status(409).json({ message: "An account with that email already exists" });
      user.email = mail;
    }
  }

  if (phone !== undefined) {
    const phoneValue = String(phone).trim();
    if (phoneValue && !isValidPhone(phoneValue)) {
      return res.status(400).json({ message: "Enter a valid phone number, or leave it empty" });
    }
    user.phone = phoneValue || undefined;
  }

  user.firstName = first;
  user.lastName = last;
  user.name = `${first} ${last}`;
  await user.save();

  res.json({
    id: user._id,
    name: user.name,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    phone: user.phone || "",
    role: user.role,
  });
}
