import { Request, Response } from "express";
import { Types } from "mongoose";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { Quote, QuoteKind } from "../models/Quote";
import { AuthedRequest } from "../types";
import {
  QUOTE_BOOK_FIELDS,
  escapeRegex,
  hydrateQuotes,
  setQuoteLike,
  shapeQuote,
} from "../utils/quoteService";

const isId = (id: unknown): id is string => typeof id === "string" && Types.ObjectId.isValid(id);
const clean = (v: unknown) => (typeof v === "string" ? v.trim() : "");
// "original" (OpenShelf's own reading notes) is no longer shown anywhere, so it
// is neither a filter option nor included in any feed.
const KINDS: QuoteKind[] = ["literary", "member"];
const VISIBLE = { kind: { $ne: "original" } } as const;
// Feeds only show quotes whose book exists in the library and has a cover image,
// so every card has a cover. (A book's own page still lists all of its quotes.)
async function withCoverFilter(): Promise<Record<string, any>> {
  const ids = await Book.find({ coverImage: { $exists: true, $nin: ["", null] } }).distinct("_id");
  return { ...VISIBLE, book: { $in: ids } };
}
const MAX_QUOTES_PER_DAY = 10;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 30;
const MAX_PAGE = 1000;

// Same conventions as GET /api/books: ?page=1&limit=10, stable ordering with
// _id as tie-breaker, and a { total, page, limit, hasMore } envelope.
// An optional ?offset= replaces the page number: after the user removes rows the
// client asks for the exact next row, so no quote is ever skipped.
function parsePaging(req: Request, fallbackLimit = DEFAULT_LIMIT) {
  const limit = Math.min(MAX_LIMIT, Math.max(1, parseInt(String(req.query.limit), 10) || fallbackLimit));
  const page = Math.min(MAX_PAGE, Math.max(1, parseInt(String(req.query.page), 10) || 1));
  const rawOffset = req.query.offset === undefined ? NaN : parseInt(String(req.query.offset), 10);
  const skip =
    Number.isFinite(rawOffset) && rawOffset >= 0
      ? Math.min(rawOffset, MAX_PAGE * MAX_LIMIT)
      : (page - 1) * limit;
  return { page, limit, skip };
}

// GET /api/quotes?page=1&limit=10[&offset=]&sort=new|top&kind=literary|member&q=
export async function getQuotes(req: AuthedRequest, res: Response) {
  const { page, limit, skip } = parsePaging(req);
  const sort = req.query.sort === "top" ? "top" : "new";
  const kind = KINDS.find((k) => k === req.query.kind);
  const search = clean(req.query.q).slice(0, 80);

  const filter: Record<string, any> = await withCoverFilter();
  if (kind) filter.kind = kind;
  if (search) {
    const rx = new RegExp(escapeRegex(search), "i");
    filter.$or = [{ text: rx }, { author: rx }, { sourceTitle: rx }];
  }

  const order: Record<string, 1 | -1> =
    sort === "top"
      ? { likeCount: -1, createdAt: -1, _id: -1 }
      : { createdAt: -1, _id: -1 };

  const [docs, total] = await Promise.all([
    Quote.find(filter)
      .select("-likes -textKey")
      .sort(order)
      .skip(skip)
      .limit(limit)
      .populate("book", QUOTE_BOOK_FIELDS)
      .lean(),
    Quote.countDocuments(filter),
  ]);

  const quotes = await hydrateQuotes(docs as any[], req.user!.id);
  res.json({ quotes, total, page, limit, hasMore: skip + docs.length < total });
}

// GET /api/quotes/saved?page=1&limit=10 — the signed-in user's own collection
// ("Words Worth Keeping"). The user always comes from the auth token.
export async function getSavedQuotes(req: AuthedRequest, res: Response) {
  const { page, limit, skip } = parsePaging(req);
  const userId = new Types.ObjectId(req.user!.id);
  const filter = { likes: userId, ...VISIBLE };

  const [docs, total] = await Promise.all([
    Quote.find(filter)
      .select("-likes -textKey")
      .sort({ createdAt: -1, _id: -1 })
      .skip(skip)
      .limit(limit)
      .populate("book", QUOTE_BOOK_FIELDS)
      .lean(),
    Quote.countDocuments(filter),
  ]);

  const quotes = await hydrateQuotes(docs as any[], req.user!.id, true);
  res.json({ quotes, total, page, limit, hasMore: skip + docs.length < total });
}

// GET /api/quotes/daily — same quote for everyone all day
export async function getDailyQuote(req: AuthedRequest, res: Response) {
  const feedFilter = await withCoverFilter();
  const total = await Quote.countDocuments(feedFilter);
  if (total === 0) return res.json(null);

  const dayNumber = Math.floor(Date.now() / 86400000);
  const doc = await Quote.findOne(feedFilter)
    .select("-likes -textKey")
    .sort({ _id: 1 })
    .skip(dayNumber % total)
    .populate("book", QUOTE_BOOK_FIELDS)
    .lean();
  if (!doc) return res.json(null);
  const [quote] = await hydrateQuotes([doc], req.user!.id);
  res.json(quote);
}

// GET /api/quotes/featured?limit=5 — the Quote of the Day carousel. Today's
// quote comes first, followed by the next ones in the same fixed order, so the
// set is identical for everyone all day and changes at midnight.
export async function getFeaturedQuotes(req: AuthedRequest, res: Response) {
  const limit = Math.min(8, Math.max(1, parseInt(String(req.query.limit), 10) || 5));
  const feedFilter = await withCoverFilter();
  const total = await Quote.countDocuments(feedFilter);
  if (total === 0) return res.json([]);

  const count = Math.min(limit, total);
  const start = Math.floor(Date.now() / 86400000) % total;

  const select = "-likes -textKey";
  let docs: any[] = await Quote.find(feedFilter)
    .select(select)
    .sort({ _id: 1 })
    .skip(start)
    .limit(count)
    .populate("book", QUOTE_BOOK_FIELDS)
    .lean();
  if (docs.length < count) {
    // Wrap around to the beginning of the list.
    const rest: any[] = await Quote.find(feedFilter)
      .select(select)
      .sort({ _id: 1 })
      .limit(count - docs.length)
      .populate("book", QUOTE_BOOK_FIELDS)
      .lean();
    docs = docs.concat(rest);
  }
  res.json(await hydrateQuotes(docs, req.user!.id));
}

// GET /api/quotes/random?exclude=<id>
export async function getRandomQuote(req: AuthedRequest, res: Response) {
  const exclude = isId(req.query.exclude) ? [new Types.ObjectId(req.query.exclude)] : [];
  const feedFilter = await withCoverFilter();
  const [picked] = await Quote.aggregate([
    { $match: { ...feedFilter, _id: { $nin: exclude } } },
    { $sample: { size: 1 } },
    { $project: { _id: 1 } },
  ]);
  if (!picked) return res.json(null);

  const doc = await Quote.findById(picked._id)
    .select("-likes -textKey")
    .populate("book", QUOTE_BOOK_FIELDS)
    .lean();
  if (!doc) return res.json(null);
  const [quote] = await hydrateQuotes([doc], req.user!.id);
  res.json(quote);
}

// GET /api/books/:id/quotes?limit=2&offset=0 — one book's highlights, most
// liked first, in the same { quotes, total, hasMore } envelope as /api/quotes.
export async function getBookQuotes(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid book id" });
  const { page, limit, skip } = parsePaging(req);
  const filter = { book: req.params.id, ...VISIBLE };

  const [docs, total] = await Promise.all([
    Quote.find(filter)
      .select("-likes -textKey")
      .sort({ likeCount: -1, createdAt: -1, _id: -1 })
      .skip(skip)
      .limit(limit)
      .populate("book", QUOTE_BOOK_FIELDS)
      .lean(),
    Quote.countDocuments(filter),
  ]);
  const quotes = await hydrateQuotes(docs as any[], req.user!.id);
  res.json({ quotes, total, page, limit, hasMore: skip + docs.length < total });
}

// POST /api/books/:id/quotes  { text, page }
export async function addQuote(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid book id" });
  const text = clean(req.body.text).replace(/^["“”']+|["“”']+$/g, "").trim();
  const page = clean(req.body.page);

  if (text.length < 5 || text.length > 300)
    return res.status(400).json({ message: "A quote must be 5–300 characters. Keep it to a line or two." });
  if (page.length > 20) return res.status(400).json({ message: "Page reference is too long" });

  const [book, user] = await Promise.all([
    Book.findById(req.params.id).select("_id title author"),
    User.findById(req.user!.id).select("name isBlocked"),
  ]);
  if (!book) return res.status(404).json({ message: "Book not found" });
  if (!user) return res.status(404).json({ message: "User not found" });
  if (user.isBlocked) return res.status(403).json({ message: "Your account cannot post right now" });

  const since = new Date(Date.now() - 86400000);
  const todayCount = await Quote.countDocuments({ addedBy: user._id, createdAt: { $gte: since } });
  if (todayCount >= MAX_QUOTES_PER_DAY)
    return res.status(429).json({ message: `You can add up to ${MAX_QUOTES_PER_DAY} quotes a day` });

  let created;
  try {
    created = await Quote.create({
      book: book._id,
      text,
      author: book.author,
      sourceTitle: book.title,
      kind: "member",
      page,
      addedBy: user._id,
      addedByName: user.name,
      likes: [user._id],
      likeCount: 1,
    });
  } catch (err: any) {
    // The unique textKey index is the final guard against duplicates.
    if (err?.code === 11000)
      return res.status(409).json({ message: "This quote has already been added — go like it instead!" });
    throw err;
  }

  const doc = await Quote.findById(created._id)
    .select("-likes -textKey")
    .populate("book", QUOTE_BOOK_FIELDS)
    .lean();
  res.status(201).json(shapeQuote(doc, req.user!.id, true));
}

// POST /api/quotes/:id/like  { liked?: boolean }
// With `liked` the call is idempotent (safe to repeat); without it, it toggles.
export async function toggleQuoteLike(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid id" });

  let desired: boolean;
  if (typeof req.body?.liked === "boolean") {
    desired = req.body.liked;
  } else {
    const already = await Quote.exists({ _id: req.params.id, likes: new Types.ObjectId(req.user!.id) });
    desired = !already;
  }

  const result = await setQuoteLike(req.params.id, req.user!.id, desired);
  if (!result) return res.status(404).json({ message: "Quote not found" });
  res.json(result);
}

// DELETE /api/quotes/:id — author or admin (curated quotes: admin only)
export async function deleteQuote(req: AuthedRequest, res: Response) {
  if (!isId(req.params.id)) return res.status(400).json({ message: "Invalid id" });
  const quote = await Quote.findById(req.params.id).select("addedBy");
  if (!quote) return res.status(404).json({ message: "Quote not found" });

  const isOwner = Boolean(quote.addedBy) && quote.addedBy!.toString() === req.user!.id;
  if (!isOwner && req.user!.role !== "admin")
    return res.status(403).json({ message: "You can only delete your own quotes" });

  await quote.deleteOne();
  res.json({ message: "Quote removed" });
}
