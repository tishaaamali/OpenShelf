import { Request, Response } from "express";
import { User } from "../models/User";
import { generateToken } from "../utils/generateToken";
import { AuthedRequest } from "../types";
import { isValidEmail, isValidPhone } from "../utils/validators";
import { publicUser } from "../utils/userHelpers";

// POST /api/auth/register
// New sign-ups are always created as "member". Admin accounts are seeded
// separately (see src/utils/seed.ts) — a user can never grant themselves
// the admin role through registration.
export async function register(req: Request, res: Response) {
  try {
    const { firstName, lastName, email, phone, password } = req.body;

    const first = String(firstName || "").trim();
    const last = String(lastName || "").trim();
    const mail = String(email || "").trim().toLowerCase();
    const phoneValue = String(phone || "").trim(); // optional

    if (!first || !last || !mail || !password) {
      return res.status(400).json({ message: "First name, last name, email and password are required" });
    }
    if (!isValidEmail(mail)) {
      return res.status(400).json({ message: "Enter a valid email address" });
    }
    if (String(password).length < 6) {
      return res.status(400).json({ message: "Password must be at least 6 characters" });
    }
    if (phoneValue && !isValidPhone(phoneValue)) {
      return res.status(400).json({ message: "Enter a valid phone number, or leave it empty" });
    }

    const existing = await User.findOne({ email: mail });
    if (existing) {
      return res.status(409).json({ message: "An account with that email already exists" });
    }

    const user = await User.create({
      name: `${first} ${last}`,
      firstName: first,
      lastName: last,
      email: mail,
      phone: phoneValue || undefined,
      password,
      role: "member",
    });
    const token = generateToken(user._id.toString(), user.role);

    res.status(201).json({ token, user: publicUser(user) });
  } catch (err) {
    res.status(500).json({ message: "Registration failed", error: (err as Error).message });
  }
}

// POST /api/auth/login
export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ message: "Invalid email or password" });
    }
    if (user.isBlocked) {
      return res.status(403).json({ message: "Your account has been blocked. Please contact the library administrator." });
    }

    const token = generateToken(user._id.toString(), user.role);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    res.status(500).json({ message: "Login failed", error: (err as Error).message });
  }
}

// GET /api/auth/me
export async function getMe(req: AuthedRequest, res: Response) {
  const user = await User.findById(req.user!.id).select("-password");
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json(user);
}
