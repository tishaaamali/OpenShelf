import { Response } from "express";
import { Types } from "mongoose";
import { Book } from "../models/Book";
import { User } from "../models/User";
import { Rating } from "../models/ratingModel";
import { AuthedRequest } from "../types";

// GET /api/books/:id/rating
// Check whether the current user can rate this book
export async function getMyRating(
  req: AuthedRequest,
  res: Response
) {
  const book = await Book.findById(req.params.id);

  if (!book) {
    return res.status(404).json({
      message: "Book not found",
    });
  }

  const user = await User.findById(req.user!.id);

  if (!user) {
    return res.status(404).json({
      message: "User not found",
    });
  }

  // Has the user returned/read this book?
  const hasRead = user.readBooks?.some(
    (bookId) =>
      bookId.toString() === book._id.toString()
  );

  // Has the user already rated this book?
  const existingRating = await Rating.findOne({
    user: user._id,
    book: book._id,
  });

  res.json({
    canRate: Boolean(hasRead && !existingRating),
    rated: Boolean(existingRating),
    rating: existingRating?.rating || null,
    review: existingRating?.review || "",
  });
}

// POST /api/books/:id/rating
// Give a rating and optional review
export async function rateBook(
  req: AuthedRequest,
  res: Response
) {
  const numericRating = Number(
    req.body.rating
  );

  const review =
    typeof req.body.review === "string"
      ? req.body.review.trim()
      : "";

  // Rating must be 1 to 5
  if (
    !Number.isInteger(numericRating) ||
    numericRating < 1 ||
    numericRating > 5
  ) {
    return res.status(400).json({
      message: "Rating must be between 1 and 5",
    });
  }

  // Review maximum length
  if (review.length > 500) {
    return res.status(400).json({
      message:
        "Review cannot be more than 500 characters",
    });
  }

  const book = await Book.findById(
    req.params.id
  );

  if (!book) {
    return res.status(404).json({
      message: "Book not found",
    });
  }

  const user = await User.findById(
    req.user!.id
  );

  if (!user) {
    return res.status(404).json({
      message: "User not found",
    });
  }

  // User must have returned/read this book
  const hasRead = user.readBooks?.some(
    (bookId) =>
      bookId.toString() === book._id.toString()
  );

  if (!hasRead) {
    return res.status(403).json({
      message:
        "You can rate this book only after returning it.",
    });
  }

  // Check if user already rated this book
  const existingRating = await Rating.findOne({
    user: user._id,
    book: book._id,
  });

  if (existingRating) {
    return res.status(400).json({
      message:
        "You have already rated this book. You cannot rate it again.",
    });
  }

  // Create rating + review
  await Rating.create({
    user: user._id,
    book: book._id,
    rating: numericRating,
    review,
  });

  // Recalculate average rating
  const stats = await Rating.aggregate([
    {
      $match: {
        book: book._id,
      },
    },
    {
      $group: {
        _id: "$book",
        averageRating: {
          $avg: "$rating",
        },
        totalRatings: {
          $sum: 1,
        },
      },
    },
  ]);

  const averageRating =
    stats.length > 0
      ? Number(
          stats[0].averageRating.toFixed(1)
        )
      : 0;

  const totalRatings =
    stats.length > 0
      ? stats[0].totalRatings
      : 0;

  book.rating = averageRating;
  book.ratingCount = totalRatings;

  await book.save();

  res.json({
    message:
      "Rating and review submitted successfully",
    rating: numericRating,
    review,
    averageRating,
    ratingCount: totalRatings,
  });
}

// Recalculate the book's average rating after a rating changed or was removed.
async function recalcBookRating(book: any) {
  const stats = await Rating.aggregate([
    { $match: { book: book._id } },
    {
      $group: {
        _id: "$book",
        averageRating: { $avg: "$rating" },
        totalRatings: { $sum: 1 },
      },
    },
  ]);

  const averageRating =
    stats.length > 0 ? Number(stats[0].averageRating.toFixed(1)) : 0;
  const totalRatings = stats.length > 0 ? stats[0].totalRatings : 0;

  book.rating = averageRating;
  book.ratingCount = totalRatings;
  await book.save();

  return { averageRating, ratingCount: totalRatings };
}

// PUT /api/books/:id/rating
// Edit my own rating + review
export async function updateMyRating(
  req: AuthedRequest,
  res: Response
) {
  const numericRating = Number(req.body.rating);
  const review =
    typeof req.body.review === "string" ? req.body.review.trim() : "";

  if (
    !Number.isInteger(numericRating) ||
    numericRating < 1 ||
    numericRating > 5
  ) {
    return res
      .status(400)
      .json({ message: "Rating must be between 1 and 5" });
  }

  if (review.length > 500) {
    return res
      .status(400)
      .json({ message: "Review cannot be more than 500 characters" });
  }

  const book = await Book.findById(req.params.id);
  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  // Only the owner of the rating can edit it.
  const existing = await Rating.findOne({
    user: req.user!.id,
    book: book._id,
  });

  if (!existing) {
    return res
      .status(404)
      .json({ message: "You have not rated this book yet." });
  }

  existing.rating = numericRating;
  existing.review = review;
  await existing.save();

  const stats = await recalcBookRating(book);

  res.json({
    message: "Rating and review updated",
    rating: numericRating,
    review,
    ...stats,
  });
}

// DELETE /api/books/:id/rating
// Delete my own rating + review
export async function deleteMyRating(
  req: AuthedRequest,
  res: Response
) {
  const book = await Book.findById(req.params.id);
  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  const deleted = await Rating.findOneAndDelete({
    user: req.user!.id,
    book: book._id,
  });

  if (!deleted) {
    return res
      .status(404)
      .json({ message: "You have not rated this book yet." });
  }

  const stats = await recalcBookRating(book);

  res.json({ message: "Rating and review deleted", ...stats });
}


// GET /api/books/:id/reviews
// Everyone signed in can read a book's ratings and reviews.
// Only the reviewer's display name is exposed (never an email).
export async function getBookReviews(
  req: AuthedRequest,
  res: Response
) {
  if (!Types.ObjectId.isValid(req.params.id)) {
    return res.status(400).json({ message: "Invalid book id" });
  }

  const book = await Book.findById(req.params.id).select("_id");
  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  const ratings = await Rating.find({ book: book._id })
    .sort({ createdAt: -1 })
    .limit(100)
    .populate("user", "name");

  res.json(
    ratings.map((r: any) => ({
      _id: r._id,
      userName: r.user?.name || "Former member",
      mine: r.user?._id?.toString() === req.user!.id,
      rating: r.rating,
      review: r.review || "",
      createdAt: r.createdAt,
    }))
  );
}

// PUT /api/books/:id/ratings/:ratingId  (admin only)
// Edit any member's rating and review.
export async function adminUpdateRating(
  req: AuthedRequest,
  res: Response
) {
  if (
    !Types.ObjectId.isValid(req.params.id) ||
    !Types.ObjectId.isValid(req.params.ratingId)
  ) {
    return res.status(400).json({ message: "Invalid id" });
  }

  const numericRating = Number(req.body.rating);
  const review =
    typeof req.body.review === "string" ? req.body.review.trim() : "";

  if (
    !Number.isInteger(numericRating) ||
    numericRating < 1 ||
    numericRating > 5
  ) {
    return res
      .status(400)
      .json({ message: "Rating must be between 1 and 5" });
  }

  if (review.length > 500) {
    return res
      .status(400)
      .json({ message: "Review cannot be more than 500 characters" });
  }

  const book = await Book.findById(req.params.id);
  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  const existing = await Rating.findOne({
    _id: req.params.ratingId,
    book: book._id,
  });

  if (!existing) {
    return res.status(404).json({ message: "Rating not found" });
  }

  existing.rating = numericRating;
  existing.review = review;
  await existing.save();

  const stats = await recalcBookRating(book);

  res.json({
    message: "Rating and review updated",
    rating: numericRating,
    review,
    ...stats,
  });
}

// DELETE /api/books/:id/ratings/:ratingId  (admin only)
// Delete any member's rating and review.
export async function adminDeleteRating(
  req: AuthedRequest,
  res: Response
) {
  if (
    !Types.ObjectId.isValid(req.params.id) ||
    !Types.ObjectId.isValid(req.params.ratingId)
  ) {
    return res.status(400).json({ message: "Invalid id" });
  }

  const book = await Book.findById(req.params.id);
  if (!book) {
    return res.status(404).json({ message: "Book not found" });
  }

  const deleted = await Rating.findOneAndDelete({
    _id: req.params.ratingId,
    book: book._id,
  });

  if (!deleted) {
    return res.status(404).json({ message: "Rating not found" });
  }

  const stats = await recalcBookRating(book);

  res.json({ message: "Rating and review deleted", ...stats });
}
