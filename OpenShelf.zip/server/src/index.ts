
import "dotenv/config";
import "express-async-errors";
import express from "express";
import cors from "cors";
import { connectDB } from "./config/db";

import authRoutes from "./routes/authRoutes";
import bookRoutes from "./routes/bookRoutes";
import accountRoutes from "./routes/accountRoutes";
import activityRoutes from "./routes/activityRoutes";
import userRoutes from "./routes/userRoutes";
import requestRoutes from "./routes/requestRoutes";
import discussionRoutes from "./routes/discussionRoutes";
import readingListRoutes from "./routes/readingListRoutes";
import notificationRoutes from "./routes/notificationRoutes";
import quoteRoutes from "./routes/quoteRoutes";
import { expireReservations } from "./utils/expireReservations";
import { ensureQuoteData } from "./utils/quoteService";
import { sendDueReminders } from "./utils/dueReminders";
import { autoSeedSampleData } from "./utils/communitySample";

const app = express();

app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN || "http://localhost:5173",
  })
);

app.use(express.json({ limit: "8mb" }));

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.use("/api/auth", authRoutes);
app.use("/api/books", bookRoutes);
app.use("/api/account", accountRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/users", userRoutes);
app.use("/api/requests", requestRoutes);
app.use("/api/discussions", discussionRoutes);
app.use("/api/lists", readingListRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/quotes", quoteRoutes);

// Fallback error handler
app.use(
  (
    err: Error,
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    console.error(err);

    res.status(500).json({
      message: "Something went wrong",
      error: err.message,
    });
  }
);

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  void ensureQuoteData()
    .then(() => autoSeedSampleData())
    .catch((error) => console.error("Quote upgrade / sample data failed:", error));
  void expireReservations().catch((error) => console.error("Reservation cleanup failed:", error));
  // Due-date reminders: once at start, then every hour for every borrower.
  void sendDueReminders().catch((error) => console.error("Due reminders failed:", error));
  setInterval(() => {
    void sendDueReminders().catch((error) => console.error("Due reminders failed:", error));
  }, 60 * 60_000);
  setInterval(() => {
    void expireReservations().catch((error) => console.error("Reservation cleanup failed:", error));
  }, 60_000);
  app.listen(PORT, () =>
    console.log(
      `🚀 OpenShelf API running on http://localhost:${PORT}`
    )
  );
});
