import { Request } from "express";

export type UserRole = "member" | "admin";

export interface AuthPayload {
  id: string;
  role: UserRole;
}

export interface AuthedRequest extends Request {
  user?: AuthPayload;
}

export type CopyStatus = "Available" | "Borrowed" | "Damaged" | "Lost";
export type BookFormat = "Hardcover" | "Paperback" | "eBook" | "Audio Book";
