import { Router } from "express";
import { getMyAccountSummary, updateMyProfile } from "../controllers/accountController";
import { protect } from "../middleware/auth";
const router = Router();
router.use(protect);
router.get("/me", getMyAccountSummary);
router.patch("/me", updateMyProfile);
export default router;
