import { Router, Response } from "express";
import { protect, adminOnly } from "../middleware/auth";
import { ActivityLog, logActivity } from "../models/ActivityLog";
import { Book } from "../models/Book";
import { AuthedRequest } from "../types";

const router = Router();

// Admins see all activity. Members see only activity linked to their account.
router.get("/", protect, async (req: AuthedRequest, res: Response) => {
  const filter =
    req.user?.role === "admin" ? {} : { userId: req.user!.id };

  const items = await ActivityLog.find(filter)
    .sort({ createdAt: -1 })
    .limit(5);

  res.json(items);
});

// POST /api/activity/send-overdue-reminders (admin quick action)
router.post(
  "/send-overdue-reminders",
  protect,
  adminOnly,
  async (req: AuthedRequest, res: Response) => {
    const books = await Book.find({ "copies.status": "Borrowed" });
    let count = 0;
    const now = Date.now();

    books.forEach((book) => {
      book.copies.forEach((copy) => {
        if (
          copy.status === "Borrowed" &&
          copy.dueDate &&
          new Date(copy.dueDate).getTime() < now
        ) {
          count += 1;
        }
      });
    });

    if (count === 0) {
      return res.json({
        message: "No overdue books right now — nothing to send",
        count: 0,
      });
    }

    await logActivity(
      `Reminder sent to ${count} overdue borrower${count > 1 ? "s" : ""}`
    );

    res.json({
      message: `Reminders sent to ${count} borrower${count > 1 ? "s" : ""}`,
      count,
    });
  }
);

export default router;
