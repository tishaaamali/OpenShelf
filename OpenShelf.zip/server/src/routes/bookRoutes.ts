import { Router } from "express";
import {
  getBooks, getBookById, createBook, updateBook, deleteBook, addCopies,
  issueCopy, returnCopy, joinWaitlist, leaveWaitlist, getPopularBooks,
  getTopRatedBooks, getCategoryCounts, getNewArrivals, getDueSoon, getOverviewStats
} from "../controllers/bookController";
import { getLikeStatus, toggleLike, getSuggestions } from "../controllers/likeController";
import { getMyRating, rateBook, updateMyRating, deleteMyRating, getBookReviews, adminUpdateRating, adminDeleteRating } from "../controllers/ratingController";
import { getBookDiscussions, createDiscussion } from "../controllers/discussionController";
import { getBookQuotes, addQuote } from "../controllers/quoteController";
import { protect, adminOnly } from "../middleware/auth";
const router = Router();
router.use(protect);
router.get("/stats/popular", getPopularBooks);
router.get("/stats/top-rated", getTopRatedBooks);
router.get("/stats/categories", getCategoryCounts);
router.get("/stats/arrivals", adminOnly, getNewArrivals);
router.get("/stats/due-soon", adminOnly, getDueSoon);
router.get("/stats/overview", getOverviewStats);
router.get("/", getBooks);
router.post("/", adminOnly, createBook);
router.get("/:id", getBookById);
router.patch("/:id", adminOnly, updateBook);
router.delete("/:id", adminOnly, deleteBook);
router.post("/:id/copies", adminOnly, addCopies);
router.post("/:id/copies/:copyId/issue", issueCopy);
router.post("/:id/copies/:copyId/return", returnCopy);
router.post("/:id/waitlist/join", joinWaitlist);
router.post("/:id/waitlist/leave", leaveWaitlist);
router.get("/:id/like", getLikeStatus);
router.post("/:id/like", toggleLike);
router.get("/:id/suggestions", getSuggestions);
router.get("/:id/rating", getMyRating);
router.post("/:id/rating", rateBook);
router.patch("/:id/rating", updateMyRating);
router.delete("/:id/rating", deleteMyRating);
router.get("/:id/reviews", getBookReviews);
router.get("/:id/ratings", getBookReviews);
router.patch("/:id/reviews/:ratingId", adminOnly, adminUpdateRating);
router.patch("/:id/ratings/:ratingId", adminOnly, adminUpdateRating);
router.delete("/:id/reviews/:ratingId", adminOnly, adminDeleteRating);
router.delete("/:id/ratings/:ratingId", adminOnly, adminDeleteRating);
router.get("/:id/discussions", getBookDiscussions);
router.post("/:id/discussions", createDiscussion);
router.get("/:id/quotes", getBookQuotes);
router.post("/:id/quotes", addQuote);
export default router;
