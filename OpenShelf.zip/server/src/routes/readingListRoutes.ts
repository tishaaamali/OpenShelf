import { Router } from "express";
import {
  getMyLists, discoverLists, getFollowedLists, listsContainingBook, getList,
  createList, updateList, deleteList, addBookToList, removeBookFromList, toggleFollowList
} from "../controllers/readingListController";
import { protect } from "../middleware/auth";
const router = Router();
router.use(protect);
router.get("/mine", getMyLists);
router.get("/discover", discoverLists);
router.get("/following", getFollowedLists);
router.get("/containing/:bookId", listsContainingBook);
router.post("/", createList);
router.get("/:id", getList);
router.patch("/:id", updateList);
router.delete("/:id", deleteList);
router.post("/:id/books", addBookToList);
router.delete("/:id/books/:bookId", removeBookFromList);
router.post("/:id/follow", toggleFollowList);
export default router;
