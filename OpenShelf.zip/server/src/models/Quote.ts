import { Schema, model, Document, Types } from "mongoose";

// literary  = short public-domain excerpt, attributed to its author and work
// original  = short reading-inspired line written for OpenShelf
// member    = a line a reader added from a book's page
export type QuoteKind = "literary" | "original" | "member";

export interface IQuote extends Document {
  book?: Types.ObjectId | null; // catalogue book, when the source exists in OpenShelf
  text: string;
  textKey: string; // normalised text, used to prevent duplicates
  author: string;
  sourceTitle: string;
  attribution: string; // e.g. "Chapter 1"
  kind: QuoteKind;
  page: string;
  addedBy?: Types.ObjectId | null; // null for curated starter quotes
  addedByName: string;
  likes: Types.ObjectId[]; // users who liked / saved the quote
  likeCount: number; // kept equal to likes.length; lets MongoDB sort and page by it
  createdAt: Date;
}

export function normaliseQuoteText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

const quoteSchema = new Schema<IQuote>({
  book: { type: Schema.Types.ObjectId, ref: "Book", default: null, index: true },
  text: { type: String, required: true, trim: true, minlength: 5, maxlength: 300 },
  textKey: { type: String },
  author: { type: String, trim: true, maxlength: 120, default: "" },
  sourceTitle: { type: String, trim: true, maxlength: 160, default: "" },
  attribution: { type: String, trim: true, maxlength: 120, default: "" },
  kind: { type: String, enum: ["literary", "original", "member"], default: "member" },
  page: { type: String, trim: true, maxlength: 20, default: "" },
  addedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  addedByName: { type: String, default: "OpenShelf" },
  likes: [{ type: Schema.Types.ObjectId, ref: "User" }],
  likeCount: { type: Number, default: 0, min: 0 },
  createdAt: { type: Date, default: Date.now, index: true },
});

quoteSchema.pre("validate", function (next) {
  if (this.text) this.textKey = normaliseQuoteText(this.text);
  next();
});

// Indexes (existing single-field indexes on book and createdAt are kept).
// Feed pages: newest first / most liked first, with _id as a stable tie-breaker.
quoteSchema.index({ createdAt: -1, _id: -1 });
quoteSchema.index({ likeCount: -1, createdAt: -1, _id: -1 });
// "Words Worth Keeping": a user's liked quotes, newest first.
quoteSchema.index({ likes: 1, createdAt: -1, _id: -1 });
// A book's own quotes.
quoteSchema.index({ book: 1, likeCount: -1 });
// No two quotes may have the same text (older documents without textKey are ignored).
quoteSchema.index(
  { textKey: 1 },
  { unique: true, partialFilterExpression: { textKey: { $type: "string" } } }
);

export const Quote = model<IQuote>("Quote", quoteSchema);
