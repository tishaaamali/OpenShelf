import { Schema, model, Document, Types } from "mongoose";

export interface IReadingList extends Document {
  owner: Types.ObjectId;
  ownerName: string;
  name: string;
  description: string;
  isPublic: boolean;
  books: Types.ObjectId[];
  followers: Types.ObjectId[];
  createdAt: Date;
  updatedAt: Date;
}

const readingListSchema = new Schema<IReadingList>({
  owner: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
  ownerName: { type: String, required: true },
  name: { type: String, required: true, trim: true, maxlength: 60 },
  description: { type: String, trim: true, maxlength: 300, default: "" },
  isPublic: { type: Boolean, default: false },
  books: [{ type: Schema.Types.ObjectId, ref: "Book" }],
  followers: [{ type: Schema.Types.ObjectId, ref: "User" }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

export const ReadingList = model<IReadingList>("ReadingList", readingListSchema);
