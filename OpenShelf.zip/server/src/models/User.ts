
import { Schema, model, Document, Types } from "mongoose";
import bcrypt from "bcryptjs";

export interface IUser extends Document {
  _id: Types.ObjectId;
  name: string;
  firstName?: string;
  lastName?: string;
  email: string;
  phone?: string;
  password: string;
  role: "member" | "admin";
  isBlocked: boolean;
  readCount: number;
  readBooks: Types.ObjectId[];
  likedBooks: Types.ObjectId[];
  createdAt: Date;

  // Forgot Password fields
  resetPasswordTokenHash?: string;
  resetPasswordExpires?: Date;

  matchPassword(entered: string): Promise<boolean>;
}

const userSchema = new Schema<IUser>({
  name: {
    type: String,
    required: true,
    trim: true,
  },

  firstName: {
    type: String,
    trim: true,
  },

  lastName: {
    type: String,
    trim: true,
  },

  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },

  phone: {
    type: String,
    trim: true,
  },

  password: {
    type: String,
    required: true,
    minlength: 6,
  },

  // Forgot Password fields
  resetPasswordTokenHash: {
    type: String,
    default: undefined,
    select: false,
  },

  resetPasswordExpires: {
    type: Date,
    default: undefined,
    select: false,
  },

  role: {
    type: String,
    enum: ["member", "admin"],
    default: "member",
  },

  isBlocked: {
    type: Boolean,
    default: false,
  },

  readCount: {
    type: Number,
    default: 0,
  },

  readBooks: [
    {
      type: Schema.Types.ObjectId,
      ref: "Book",
    },
  ],

  likedBooks: [
    {
      type: Schema.Types.ObjectId,
      ref: "Book",
    },
  ],

  createdAt: {
    type: Date,
    default: Date.now,
  },
});

userSchema.pre("save", async function () {
  if (!this.isModified("password")) return;

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

userSchema.methods.matchPassword = async function (entered: string) {
  return bcrypt.compare(entered, this.password);
};

export const User = model<IUser>("User", userSchema);
