import { Schema, model, Document, Types } from "mongoose";

export interface ICopy {
  _id?: Types.ObjectId;
  barcode: string;
  shelf: string;
  condition: "New" | "Good" | "Fair" | "Damaged";
  status: "Available" | "Reserved" | "Borrowed" | "Damaged" | "Lost";
  reservedBy?: Types.ObjectId | null;
  reservedUntil?: Date | null;
  borrowedBy?: Types.ObjectId | null;
  borrowerName?: string | null;
  borrowDate?: Date | null;
  dueDate?: Date | null;
}

export interface IWaitlistEntry {
  _id?: Types.ObjectId;
  user: Types.ObjectId;
  name: string;
  email: string;
  joinedAt: Date;
}

export interface IBook extends Document {
  title: string;
  author: string;
  category: string;
  language: string;
  publisher: string;
  edition: string;
  year: number;
  isbn13: string;
  isbn10: string;
  format: "Hardcover" | "Paperback" | "eBook" | "Audio Book";
  status: "Available" | "Borrowed" | "Unavailable" | "Under Maintenance";
  description: string;
  nextReaderNote?: string;
  previewText?: string;

  // Book cover image path or URL
  coverImage?: string;

  rating: number;
  ratingCount: number;

  borrowCount: number;
  addedDate: Date;
  copies: Types.DocumentArray<ICopy>;
  waitlist: IWaitlistEntry[];

  syncStatus(): void;
}

const copySchema = new Schema<ICopy>(
  {
    barcode: {
      type: String,
      required: true,
    },

    shelf: {
      type: String,
      required: true,
    },

    condition: {
      type: String,
      enum: ["New", "Good", "Fair", "Damaged"],
      default: "New",
    },

    status: {
      type: String,
      enum: ["Available", "Reserved", "Borrowed", "Damaged", "Lost"],
      default: "Available",
    },

    reservedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    reservedUntil: { type: Date, default: null },

    borrowedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    borrowerName: {
      type: String,
      default: null,
    },

    borrowDate: {
      type: Date,
      default: null,
    },

    dueDate: {
      type: Date,
      default: null,
    },
  },
  { _id: true }
);

const waitlistSchema = new Schema<IWaitlistEntry>(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    name: {
      type: String,
      required: true,
    },

    email: {
      type: String,
      required: true,
    },

    joinedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: true }
);

const bookSchema = new Schema<IBook>({
  title: {
    type: String,
    required: true,
    trim: true,
  },

  author: {
    type: String,
    required: true,
  },

  category: {
    type: String,
    required: true,
  },

  language: {
    type: String,
    required: true,
  },

  publisher: {
    type: String,
    default: "—",
  },

  edition: {
    type: String,
    default: "—",
  },

  year: {
    type: Number,
  },

  isbn13: {
    type: String,
    default: "",
    trim: true,
  },

  isbn10: {
    type: String,
    default: "—",
    trim: true,
  },

  format: {
    type: String,
    enum: ["Hardcover", "Paperback", "eBook", "Audio Book"],
    required: true,
  },

  status: {
    type: String,
    enum: [
      "Available",
      "Unavailable",
      "Borrowed",
      "Under Maintenance",
    ],
    default: "Available",
  },

  description: {
    type: String,
    default: "No description provided.",
  },

  nextReaderNote: {
    type: String,
    default: "A little note from a reader will appear here after this book is returned.",
    maxlength: 500,
  },

  previewText: { type: String, default: "" },

  // Stores the uploaded cover's path or URL.
  // The actual upload must be handled by the backend route/controller.
  coverImage: {
    type: String,
    default: "",
  },

  rating: {
    type: Number,
    min: 0,
    max: 5,
    default: 0,
  },

  ratingCount: {
    type: Number,
    default: 0,
  },

  borrowCount: {
    type: Number,
    default: 0,
  },

  addedDate: {
    type: Date,
    default: Date.now,
  },

  copies: [copySchema],

  waitlist: [waitlistSchema],
});

// Keep book.status in sync with its copies.
bookSchema.methods.syncStatus = function (this: IBook) {
  if (this.copies.some((copy) => copy.status === "Available")) {
    this.status = "Available";
  } else if (this.copies.length > 0 && this.copies.every((copy) => copy.status === "Reserved")) {
    this.status = "Unavailable";
  } else if (this.copies.length > 0) {
    this.status = "Borrowed";
  }
};

export const Book = model<IBook>("Book", bookSchema);
