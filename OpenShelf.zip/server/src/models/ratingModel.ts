import { Schema, model, Document, Types } from "mongoose";

export interface IRating extends Document {
  user: Types.ObjectId;
  book: Types.ObjectId;
  rating: number;
  review?: string;
  createdAt: Date;
}

const ratingSchema = new Schema<IRating>(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    book: {
      type: Schema.Types.ObjectId,
      ref: "Book",
      required: true,
    },

    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5,
    },

    review: {
      type: String,
      trim: true,
      maxlength: 500,
      default: "",
    },

    createdAt: {
      type: Date,
      default: Date.now,
    },
  }
);

// One user can rate one particular book only once.
ratingSchema.index(
  {
    user: 1,
    book: 1,
  },
  {
    unique: true,
  }
);

export const Rating = model<IRating>(
  "Rating",
  ratingSchema
);