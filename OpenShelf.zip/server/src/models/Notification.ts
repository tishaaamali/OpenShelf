import { Schema, model, Document, Types } from "mongoose";

export interface INotification extends Document {
  user: Types.ObjectId;
  message: string;
  link: string;
  read: boolean;
  // Optional de-duplication key (used by due-date reminders so each one is sent once).
  key?: string;
  createdAt: Date;
}

const notificationSchema = new Schema<INotification>({
  user: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
  message: { type: String, required: true, maxlength: 240 },
  link: { type: String, default: "" },
  read: { type: Boolean, default: false },
  key: { type: String, default: undefined },
  createdAt: { type: Date, default: Date.now, index: true },
});

// One notification per (user, key); documents without a key are not constrained.
notificationSchema.index(
  { user: 1, key: 1 },
  { unique: true, partialFilterExpression: { key: { $type: "string" } } }
);

export const Notification = model<INotification>("Notification", notificationSchema);

export async function notify(
  user: Types.ObjectId | string,
  message: string,
  link = ""
) {
  try {
    await Notification.create({ user, message, link });
  } catch (err) {
    console.error("Notification failed:", err);
  }
}
