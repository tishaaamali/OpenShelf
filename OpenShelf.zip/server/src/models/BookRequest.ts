import { Schema, model, Document, Types } from "mongoose";

export type RequestStatus = "Pending" | "Issued" | "Cancelled" | "Expired";

export interface IBookRequest extends Document {
  user: Types.ObjectId;
  book: Types.ObjectId;
  token: string; // random, unguessable — the ONLY thing encoded in the QR
  status: RequestStatus;
  requestedAt: Date;
  expiresAt: Date;
  issuedAt?: Date | null;
  issuedBy?: Types.ObjectId | null;
  copyId?: Types.ObjectId | null;
}

const bookRequestSchema = new Schema<IBookRequest>({
  user: { type: Schema.Types.ObjectId, ref: "User", required: true },
  book: { type: Schema.Types.ObjectId, ref: "Book", required: true },
  token: { type: String, required: true, unique: true },
  status: {
    type: String,
    enum: ["Pending", "Issued", "Cancelled", "Expired"],
    default: "Pending",
  },
  requestedAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
  issuedAt: { type: Date, default: null },
  issuedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  copyId: { type: Schema.Types.ObjectId, default: null },
});

// A user can have only ONE pending request per book (race-safe, enforced by MongoDB).
bookRequestSchema.index(
  { user: 1, book: 1 },
  { unique: true, partialFilterExpression: { status: "Pending" } }
);

export const BookRequest = model<IBookRequest>("BookRequest", bookRequestSchema);
