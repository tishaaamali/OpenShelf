import { Schema, model, Document, Types } from "mongoose";

export interface IActivityLog extends Document {
  message: string;
  createdAt: Date;
  userId?: Types.ObjectId;
}

const activityLogSchema = new Schema<IActivityLog>({
  message: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  userId: { type: Schema.Types.ObjectId, ref: "User", index: true },
});

export const ActivityLog = model<IActivityLog>(
  "ActivityLog",
  activityLogSchema
);

export async function logActivity(
  message: string,
  userId?: Types.ObjectId | string
) {
  await ActivityLog.create({ message, ...(userId ? { userId } : {}) });
}