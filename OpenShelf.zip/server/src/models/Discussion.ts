import { Schema, model, Document, Types } from "mongoose";

export interface IReply {
  _id: Types.ObjectId;
  user: Types.ObjectId;
  userName: string;
  body: string;
  spoiler: boolean;
  createdAt: Date;
}

export interface IDiscussion extends Document {
  book: Types.ObjectId;
  user: Types.ObjectId;
  userName: string;
  title: string;
  body: string;
  spoiler: boolean;
  pinned: boolean;
  locked: boolean;
  upvotes: Types.ObjectId[];
  replies: Types.DocumentArray<IReply>;
  lastActivityAt: Date;
  createdAt: Date;
}

const replySchema = new Schema<IReply>(
  {
    user: { type: Schema.Types.ObjectId, ref: "User", required: true },
    userName: { type: String, required: true },
    body: { type: String, required: true, trim: true, maxlength: 1000 },
    spoiler: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now },
  },
  { _id: true }
);

const discussionSchema = new Schema<IDiscussion>({
  book: { type: Schema.Types.ObjectId, ref: "Book", required: true, index: true },
  user: { type: Schema.Types.ObjectId, ref: "User", required: true },
  userName: { type: String, required: true },
  title: { type: String, required: true, trim: true, maxlength: 120 },
  body: { type: String, required: true, trim: true, maxlength: 2000 },
  spoiler: { type: Boolean, default: false },
  pinned: { type: Boolean, default: false },
  locked: { type: Boolean, default: false },
  upvotes: [{ type: Schema.Types.ObjectId, ref: "User" }],
  replies: [replySchema],
  lastActivityAt: { type: Date, default: Date.now, index: true },
  createdAt: { type: Date, default: Date.now },
});

export const Discussion = model<IDiscussion>("Discussion", discussionSchema);
