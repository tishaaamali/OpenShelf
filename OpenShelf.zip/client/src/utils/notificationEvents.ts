// Tiny pub/sub so the bell menu and the full Notifications page stay in step
// when notifications are read or cleared, without waiting for the next poll.
const EVENT = "openshelf:notifications-changed";

export function emitNotificationsChanged() {
  window.dispatchEvent(new Event(EVENT));
}

export function onNotificationsChanged(handler: () => void) {
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}
