// Tiny pub/sub so every mounted piece of UI that shows quotes (Book Highlights,
// the Words Worth Keeping preview and its full page) stays in step when a quote
// is liked or removed, without a page reload.
const EVENT = "openshelf:quote-like";

export interface QuoteLikeDetail {
  quoteId: string;
  liked: boolean;
  likeCount: number;
}

export function emitQuoteLike(detail: QuoteLikeDetail) {
  window.dispatchEvent(new CustomEvent<QuoteLikeDetail>(EVENT, { detail }));
}

export function onQuoteLike(handler: (detail: QuoteLikeDetail) => void) {
  const listener = (event: Event) => handler((event as CustomEvent<QuoteLikeDetail>).detail);
  window.addEventListener(EVENT, listener);
  return () => window.removeEventListener(EVENT, listener);
}
