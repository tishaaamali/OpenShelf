
import { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import api from "../api/axios";
import { RequestLookup } from "../types";
import { RequestDetailsSkeleton } from "./BookSkeletons";

export default function ScanIssuePanel() {
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [issuing, setIssuing] = useState(false);
  const [result, setResult] = useState<RequestLookup | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [camera, setCamera] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const [uploading, setUploading] = useState(false);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const mountedRef = useRef(true);
  const handledRef = useRef(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    mountedRef.current = true;

    return () => {
      mountedRef.current = false;
      const scanner = scannerRef.current;
      scannerRef.current = null;

      if (scanner) {
        void scanner.stop().catch(() => {}).finally(() => {
          void scanner.clear();
        });
      }
    };
  }, []);

  function normalizeCode(raw: string) {
    return raw.trim().replace(/^OSREQ:/i, "");
  }

  async function lookup(raw: string) {
    const value = normalizeCode(raw);
    if (!value) {
      setError("Please scan or enter a request code.");
      return;
    }

    setLoading(true);
    setError("");
    setSuccess("");
    setResult(null);
    setCode(value);

    try {
      const { data } = await api.get(
        `/requests/lookup/${encodeURIComponent(value)}`
      );

      if (!mountedRef.current) return;

      setResult(data);

      // Issue automatically only after the backend confirms
      // that this is a valid, issuable pending request.
      if (data.canIssue) {
        await issueRequest(value);
      } else {
        setError(
          data.reason ||
            "This request cannot be issued. Check its status and availability."
        );
      }
    } catch (err: any) {
      if (!mountedRef.current) return;

      setError(
        err?.response?.data?.message ||
          "Could not look up this QR code. Check the code and try again."
      );
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }

  async function issueRequest(token: string) {
    if (issuing) return;

    setIssuing(true);
    setError("");

    try {
      const { data } = await api.post("/requests/issue", {
        token: normalizeCode(token),
      });

      if (!mountedRef.current) return;

      setSuccess(data.message || "Book issued successfully!");
      setResult(null);
      setCode("");
    } catch (err: any) {
      if (!mountedRef.current) return;

      setError(
        err?.response?.data?.message ||
          "Could not issue this book."
      );

      // Refresh request status after a failed issue attempt.
      try {
        const { data } = await api.get(
          `/requests/lookup/${encodeURIComponent(normalizeCode(token))}`
        );

        if (mountedRef.current) setResult(data);
      } catch {
        // Keep the original issue error visible.
      }
    } finally {
      if (mountedRef.current) setIssuing(false);
    }
  }

  async function stopCamera() {
    const scanner = scannerRef.current;
    scannerRef.current = null;
    setCamera(false);

    if (scanner) {
      try {
        await scanner.stop();
      } catch {
        // The scanner may already have stopped.
      }

      try {
        scanner.clear();
      } catch {
        // Nothing else to clean up.
      }
    }
  }

  async function startCamera() {
    setError("");
    setSuccess("");
    setCameraError("");
    handledRef.current = false;

    try {
      const scanner = new Html5Qrcode("request-qr-reader");
      scannerRef.current = scanner;

      setCamera(true);

      await scanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 230, height: 230 } },
        async (decodedText) => {
          if (handledRef.current) return;
          handledRef.current = true;

          const activeScanner = scannerRef.current;
          scannerRef.current = null;

          if (activeScanner) {
            try {
              await activeScanner.stop();
            } catch {
              // Continue processing the detected QR.
            }

            try {
              activeScanner.clear();
            } catch {
              // Ignore cleanup errors.
            }
          }

          if (mountedRef.current) setCamera(false);

          await lookup(decodedText);
        },
        () => {
          // Ignore frames that do not contain a QR code.
        }
      );
    } catch {
      scannerRef.current = null;
      setCamera(false);
      setCameraError(
        "Could not open the camera. Allow camera access or upload a QR image instead."
      );
    }
  }

  async function handleImageUpload(
    event: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setError("Please select an image containing a QR code.");
      return;
    }

    setUploading(true);
    setError("");
    setSuccess("");
    setCameraError("");

    let imageScanner: Html5Qrcode | null = null;

    try {
      imageScanner = new Html5Qrcode("request-qr-image-reader");

      const decodedText = await imageScanner.scanFile(file, true);

      if (!decodedText) {
        throw new Error("No QR code was found in this image.");
      }

      await lookup(decodedText);
    } catch (err: any) {
      setError(
        err?.message ||
          "Could not read a QR code from this image. Try a clearer image."
      );
    } finally {
      if (imageScanner) {
        try {
          imageScanner.clear();
        } catch {
          // Ignore scanner cleanup errors.
        }
      }

      setUploading(false);
    }
  }

  return (
    <div>
      <p className="text-[13px] text-ink-600 mb-3">
        Scan a member's request QR with your camera, upload a QR image,
        or enter the request code manually. Valid pending requests are
        issued automatically.
      </p>

      <div className="flex gap-2 flex-wrap mb-3">
        <button
          type="button"
          onClick={camera ? stopCamera : startCamera}
          disabled={loading || issuing || uploading}
          className="bg-primary text-white rounded-lg px-4 py-2.5 font-bold text-sm disabled:opacity-60"
        >
          {camera ? "Stop camera" : "Scan with camera"}
        </button>

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={loading || issuing || uploading}
          className="border border-line rounded-lg px-4 py-2.5 font-semibold text-sm disabled:opacity-60"
        >
          {uploading ? "Reading image…" : "Upload QR image"}
        </button>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleImageUpload}
        />
      </div>

      {/* Camera scanner */}
      <div
        id="request-qr-reader"
        className={camera ? "mt-3 w-full max-w-[360px]" : "hidden"}
      />

      {/* Hidden reader used to decode uploaded images */}
      <div id="request-qr-image-reader" className="hidden" />

      {cameraError && (
        <p className="text-danger text-[13px] mt-2" role="alert">
          {cameraError}
        </p>
      )}

      {/* Manual code entry */}
      <form
        onSubmit={(event) => {
          event.preventDefault();
          void lookup(code);
        }}
        className="flex gap-2 flex-wrap"
      >
        <input
          value={code}
          onChange={(event) => setCode(event.target.value)}
          placeholder="Scan or paste request code"
          aria-label="Request code"
          className="flex-1 min-w-[180px] px-3 py-2.5 rounded-lg border border-line bg-field text-[13.5px] outline-none focus:border-blue-500"
        />

        <button
          type="submit"
          disabled={loading || issuing || !code.trim()}
          className="bg-primary text-white rounded-lg px-4 py-2.5 font-bold text-sm disabled:opacity-60"
        >
          {loading ? "Checking…" : "Look up"}
        </button>
      </form>

      {loading && <RequestDetailsSkeleton />}

      {issuing && (
        <p className="text-ink-600 text-[13px] mt-3" role="status">
          Issuing book…
        </p>
      )}

      {error && (
        <p className="text-danger text-[13px] mt-3" role="alert">
          {error}
        </p>
      )}

      {success && (
        <p className="text-[13.5px] font-semibold mt-3" role="status">
          ✓ {success}
        </p>
      )}

      {/* Request details */}
      {result && (
        <div className="mt-4 border border-line rounded-xl p-4 text-[13.5px]">
          <div className="font-heading font-bold text-[15px]">
            {result.book.title}
          </div>

          <div className="text-ink-600 mb-2">
            by {result.book.author}
          </div>

          <div>
            Member: <b>{result.member.name}</b>{" "}
            <span className="text-ink-600">
              ({result.member.email})
            </span>
          </div>

          <div className="text-ink-600">
            Requested {new Date(result.requestedAt).toLocaleString()}
            {" · "}
            expires {new Date(result.expiresAt).toLocaleString()}
          </div>

          <div className="mt-2">
            Status:{" "}
            <span
              className={`badge ${
                result.status === "Pending"
                  ? "badge-available"
                  : "badge-damaged"
              }`}
            >
              {result.status}
            </span>

            <span className="text-ink-600 ml-2">
              {result.book.availableCopies} cop
              {result.book.availableCopies === 1 ? "y" : "ies"} available
            </span>
          </div>

          {result.reason && (
            <p className="text-danger mt-2">{result.reason}</p>
          )}

          {!result.canIssue && (
            <p className="text-ink-600 mt-2">
              This request cannot currently be issued.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
