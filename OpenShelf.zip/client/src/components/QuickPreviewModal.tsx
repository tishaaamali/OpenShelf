import { useNavigate } from "react-router-dom";
import { Book } from "../types";
import BookCover from "./BookCover";

interface Props {
  book: Book | null;
  index: number;
  onClose: () => void;
}

export default function QuickPreviewModal({
  book,
  index,
  onClose,
}: Props) {
  const navigate = useNavigate();

  if (!book) return null;

  return (
    <div
      className="fixed inset-0 bg-navy-950/55 z-[100] flex items-center justify-center p-5 overflow-y-auto"
      style={{ backgroundColor: "rgba(2, 8, 23, .88)" }}
      onClick={onClose}
    >
      <div
        className="modal-panel rounded-2xl w-full max-w-[570px] p-7"
        style={{ backgroundColor: "rgb(var(--card))" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* HEADER */}
        <div className="flex items-start justify-between gap-4 mb-5">
          <h2 className="font-heading font-bold text-xl leading-tight m-0">
            {book.title}
          </h2>

          <button
            onClick={onClose}
            className="text-ink-600 text-xl leading-none hover:text-ink-900 flex-shrink-0"
            aria-label="Close preview"
          >
            ✕
          </button>
        </div>

        {/* BOOK INFO */}
        <div className="flex gap-5 items-center mb-5">
          <BookCover book={book} index={index} className="h-[145px] w-[110px] flex-shrink-0 rounded-xl text-2xl" />

          {/* BASIC DETAILS */}
          <div>
            <p className="text-[14px] text-ink-600 m-0 mb-2">
              by {book.author}
            </p>

            <p className="text-[13px] text-ink-600 m-0">
              {book.category} · {book.format} · {book.year}
            </p>
          </div>
        </div>

        {/* DESCRIPTION */}
        <div className="mb-6">
          <h3 className="font-heading font-bold text-[15px] mb-2">
            Short preview
          </h3>

          <p className="text-[15px] leading-7 text-ink-900 m-0">
            {book.previewText || book.description}
          </p>
        </div>

        {/* BUTTONS */}
        <div className="flex justify-end gap-2.5">
          <button
            onClick={onClose}
            className="border border-line rounded-full px-5 py-2.5 font-semibold text-sm hover:border-blue-500"
          >
            Close
          </button>

          <button
            onClick={() => {
              onClose();
              navigate(`/books/${book._id}`);
            }}
            className="bg-gold-500 hover:bg-gold-600 rounded-full px-6 py-2.5 font-bold text-sm text-[#2A1B00]"
          >
            View Full Details
          </button>
        </div>
      </div>
    </div>
  );
}
