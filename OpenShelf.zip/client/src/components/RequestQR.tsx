import { useEffect, useState } from "react";
import QRCode from "qrcode";

// The QR holds ONLY "OSREQ:<random token>" — no names, emails or passwords.
export default function RequestQR({ token, size = 224 }: { token: string; size?: number }) {
  const [src, setSrc] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setSrc("");
    setError("");
    QRCode.toDataURL(`OSREQ:${token}`, { width: size, margin: 2, errorCorrectionLevel: "M" })
      .then((url) => !cancelled && setSrc(url))
      .catch(() => !cancelled && setError("Could not draw the QR code. Please try again."));
    return () => {
      cancelled = true;
    };
  }, [token, size]);

  if (error) return <p className="text-danger text-[13px]" role="alert">{error}</p>;
  if (!src) {
    return (
      <div className="dashboard-skeleton" style={{ width: size, height: size, padding: 0 }} aria-busy="true" aria-label="Generating QR" />
    );
  }
  return <img src={src} width={size} height={size} alt="QR code for your book request" className="rounded-lg bg-white" />;
}
