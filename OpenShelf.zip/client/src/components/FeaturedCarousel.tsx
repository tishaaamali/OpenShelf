import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Carousel from "bootstrap/js/dist/carousel";

import { Book } from "../types";
import BookCover from "./BookCover";

interface Props {
  books: Book[];
}

// "Featured for you" slider built on the Bootstrap carousel (JS plugin).
export default function FeaturedCarousel({ books }: Props) {
  const navigate = useNavigate();
  const rootRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const element = rootRef.current;
    if (!element || books.length === 0) return;

    const instance = Carousel.getOrCreateInstance(element, {
      interval: 5000,
      ride: "carousel",
      pause: "hover",
      touch: true,
      wrap: true,
      keyboard: true,
    });

    return () => {
      instance.dispose();
    };
  }, [books.length]);

  if (books.length === 0) return null;

  return (
    <div
      ref={rootRef}
      className="carousel slide home-spotlight featured-carousel mb-8 rounded-[24px] border border-line bg-card"
      aria-roledescription="carousel"
      aria-label="Featured books"
    >
      <div className="carousel-inner">
        {books.map((book, index) => (
          <div
            key={book._id}
            className={`carousel-item${index === 0 ? " active" : ""}`}
          >
            <div className="flex flex-wrap items-center gap-7 p-6 sm:p-8 max-md:flex-col max-md:items-start">
              <BookCover
                book={book}
                index={index}
                className="home-feature-cover h-[184px] w-[132px] flex-shrink-0 rounded-xl text-2xl"
              />

              <div className="min-w-0 flex-1">
                <div className="home-eyebrow mb-2 text-[11.5px] font-bold tracking-[.18em]">
                  <span>✦</span> FEATURED FOR YOU
                </div>

                <h3 className="m-0 mb-1 font-heading text-[19px] font-bold">
                  {book.title}
                </h3>

                <p className="mb-2.5 text-[13.5px] text-ink-600">
                  by {book.author} · {book.category}
                </p>

                <p className="mb-4 line-clamp-3 max-w-[540px] text-[13.5px] leading-relaxed">
                  {book.description}
                </p>

                <button
                  type="button"
                  onClick={() => navigate(`/books/${book._id}`)}
                  className="home-cta rounded-full px-5 py-2.5 text-[13.5px] font-bold"
                >
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
