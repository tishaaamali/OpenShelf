import { FormEvent, useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useConfirm } from "../context/ConfirmContext";
import api from "../api/axios";
import { QuoteItem, QuotePage } from "../types";
import QuoteCard from "./QuoteCard";
import { QuoteCardSkeletons } from "./BookSkeletons";

// Only a couple of highlights are shown here; the rest are on their own page.
const PREVIEW = 2;

// "Highlights from this Book" section on a book's page: readers add and like short quotes.
export default function BookQuotes({
  bookId,
  isAdmin,
}: {
  bookId: string;
  isAdmin: boolean;
}) {
  const confirm = useConfirm();
  const [quotes, setQuotes] = useState<QuoteItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");

  const [adding, setAdding] = useState(false);
  const [text, setText] = useState("");
  const [page, setPage] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const { data } = await api.get<QuotePage>(`/books/${bookId}/quotes`, {
        params: { limit: PREVIEW },
      });
      setQuotes(data.quotes.slice(0, PREVIEW));
      setTotal(data.total);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not load quotes.");
    } finally {
      setLoading(false);
    }
  }, [bookId]);

  useEffect(() => {
    void load();
  }, [load]);

  function showToast(message: string) {
    setToast(message);
    setTimeout(() => setToast(""), 3000);
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setFormError("");
    if (text.trim().length < 5) return setFormError("Type the line you loved (at least 5 characters).");
    try {
      setSaving(true);
      await api.post(`/books/${bookId}/quotes`, { text, page });
      setText("");
      setPage("");
      setAdding(false);
      showToast("Your line was added");
      await load();
    } catch (err: any) {
      setFormError(err?.response?.data?.message || "Could not add the quote.");
    } finally {
      setSaving(false);
    }
  }

  async function remove(quote: QuoteItem) {
    if (
      !(await confirm({
        title: "Delete this quote?",
        message: "This removes it for everyone and cannot be undone.",
        confirmLabel: "Delete",
      }))
    )
      return;
    try {
      await api.delete(`/quotes/${quote._id}`);
      // Reload so the next highlight moves up into the freed spot.
      await load();
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not delete the quote");
    }
  }

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="m-0 text-[13px] text-ink-600">
          Short lines readers loved from this book. Like the ones that stay with you.
        </p>
        {!adding && (
          <button
            type="button"
            onClick={() => setAdding(true)}
            className="rounded-full bg-primary px-4 py-2 text-[13px] font-bold text-white"
          >
            + Add a line
          </button>
        )}
      </div>

      {adding && (
        <form onSubmit={submit} className="mb-4 rounded-2xl border border-line bg-card p-4">
          <label htmlFor="quote-text" className="mb-1 block text-[13px] font-semibold">
            The line
          </label>
          <textarea
            id="quote-text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            maxLength={300}
            rows={3}
            placeholder="Type a short line you loved — one or two sentences is plenty."
            className="w-full resize-none rounded-xl border border-line-strong bg-field px-4 py-3 text-[14px] outline-none focus:border-blue-500"
          />
          <div className="mb-3 mt-1 text-right text-[11px] text-ink-600">{text.length}/300</div>

          <label htmlFor="quote-page" className="mb-1 block text-[13px] font-semibold">
            Page <span className="font-normal text-ink-600">(optional)</span>
          </label>
          <input
            id="quote-page"
            value={page}
            onChange={(e) => setPage(e.target.value)}
            maxLength={20}
            className="w-32 rounded-xl border border-line-strong bg-field px-3 py-2 text-[14px] outline-none focus:border-blue-500"
          />

          {formError && <p className="mt-2 text-[13px] text-danger" role="alert">{formError}</p>}

          <div className="mt-4 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => {
                setAdding(false);
                setFormError("");
              }}
              className="rounded-full border border-line px-4 py-2 text-[13px] font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-full bg-primary px-5 py-2 text-[13px] font-bold text-white disabled:opacity-50"
            >
              {saving ? "Adding…" : "Add quote"}
            </button>
          </div>
        </form>
      )}

      {error ? (
        <p className="text-[13.5px] text-danger" role="alert">{error}</p>
      ) : loading ? (
        <div className="space-y-3" aria-busy="true" aria-label="Loading highlights">
          <QuoteCardSkeletons count={PREVIEW} noCover />
        </div>
      ) : quotes.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line-strong p-6 text-center text-[14px] text-ink-600">
          No lines yet. Add the first one!
        </div>
      ) : (
        <div className="space-y-3">
          {quotes.map((q) => (
            <QuoteCard
              key={q._id}
              quote={q}
              isAdmin={isAdmin}
              hideBook
              onChange={(updated) =>
                setQuotes((all) => all.map((x) => (x._id === updated._id ? updated : x)))
              }
              onDelete={remove}
              onMessage={showToast}
            />
          ))}

          {total > quotes.length && (
            <div className="pt-1 text-center">
              <Link
                to={`/books/${bookId}/highlights`}
                className="inline-block rounded-full border border-line px-5 py-2 text-[13.5px] font-semibold text-blue-500 hover:border-blue-500"
              >
                View more ({total - quotes.length} more)
              </Link>
            </div>
          )}
        </div>
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[100] max-w-[90vw] -translate-x-1/2 rounded-full bg-primary px-6 py-3 text-center text-sm font-semibold text-white shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
