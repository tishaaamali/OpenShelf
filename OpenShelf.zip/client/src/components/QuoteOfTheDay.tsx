import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import Carousel from "bootstrap/js/dist/carousel";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { QuoteItem } from "../types";
import { QuoteOfTheDaySkeleton } from "./BookSkeletons";
import QuoteCard from "./QuoteCard";

const SLIDES = 5;
// How long each quote stays before the carousel moves on by itself.
const AUTO_SLIDE_MS = 3500;

// Home-page "Quote of the Day": a carousel of a few lines (today's first), with
// the same like / borrow actions as Book Highlights. It slides on its own
// (one quote every 3.5 seconds), pauses while hovered, and can be moved with the arrows, dots or keyboard.
export default function QuoteOfTheDay() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [quotes, setQuotes] = useState<QuoteItem[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const [active, setActive] = useState(0);
  const [toast, setToast] = useState("");
  const [modalOpen, setModalOpen] = useState(false);

  const rootRef = useRef<HTMLDivElement | null>(null);
  const carouselRef = useRef<Carousel | null>(null);

  useEffect(() => {
    let cancelled = false;
    api
      .get<QuoteItem[]>("/quotes/featured", { params: { limit: SLIDES } })
      .then(({ data }) => !cancelled && setQuotes(Array.isArray(data) ? data : []))
      .catch(() => !cancelled && setFailed(true))
      .finally(() => !cancelled && setLoaded(true));
    return () => {
      cancelled = true;
    };
  }, []);

  // Start the Bootstrap carousel once the slides are in the DOM.
  useEffect(() => {
    // The carousel markup only exists once loading has finished, so this must
    // re-run when `loaded` flips, not just when the quotes arrive.
    const element = rootRef.current;
    if (!loaded || !element || quotes.length < 2) return;

    const instance = Carousel.getOrCreateInstance(element, {
      interval: AUTO_SLIDE_MS,
      ride: "carousel",
      pause: "hover",
      touch: true,
      wrap: true,
      keyboard: true,
    });
    carouselRef.current = instance;

    const onSlide = (event: Event) => {
      const to = (event as unknown as { to: number }).to;
      if (typeof to === "number") setActive(to);
    };
    element.addEventListener("slide.bs.carousel", onSlide);

    return () => {
      element.removeEventListener("slide.bs.carousel", onSlide);
      instance.dispose();
      carouselRef.current = null;
    };
  }, [loaded, quotes.length]);

  // Never slide away from a quote while its QR dialog is open.
  useEffect(() => {
    const instance = carouselRef.current;
    if (!instance) return;
    if (modalOpen) instance.pause();
    else instance.cycle();
  }, [modalOpen]);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  }

  function handleChange(updated: QuoteItem) {
    setQuotes((all) =>
      all.map((q) =>
        q._id === updated._id
          ? updated
          : q.book && updated.book && q.book._id === updated.book._id
            ? { ...q, book: updated.book }
            : q
      )
    );
  }

  // Nothing to show once we know there are no quotes at all.
  if (loaded && (failed || quotes.length === 0)) return null;

  return (
    <section className="mb-8" aria-labelledby="qotd-heading">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 id="qotd-heading" className="m-0 font-heading text-[19px] font-bold">
          Quote of the Day
        </h2>
        <Link to="/highlights" className="text-[13px] font-semibold text-blue-500">
          Book Highlights
        </Link>
      </div>

      {!loaded ? (
        <QuoteOfTheDaySkeleton />
      ) : (
        <div
          ref={rootRef}
          className="carousel slide qotd-carousel"
          aria-roledescription="carousel"
          aria-label="Quote of the day"
        >
          <div className="carousel-inner">
            {quotes.map((quote, index) => (
              <div
                key={quote._id}
                className={`carousel-item${index === 0 ? " active" : ""}`}
                role="group"
                aria-roledescription="slide"
                aria-label={`Quote ${index + 1} of ${quotes.length}`}
              >
                <QuoteCard
                  quote={quote}
                  isAdmin={isAdmin}
                  onChange={handleChange}
                  onMessage={showToast}
                  onModalChange={index === active ? setModalOpen : undefined}
                  large
                />
              </div>
            ))}
          </div>

          {quotes.length > 1 && (
            <div className="qotd-controls">
              <button
                type="button"
                className="qotd-arrow"
                aria-label="Previous quote"
                onClick={() => carouselRef.current?.prev()}
              >
                ‹
              </button>

              <div className="qotd-dots" role="group" aria-label="Choose a quote">
                {quotes.map((quote, index) => (
                  <button
                    key={quote._id}
                    type="button"
                    aria-label={`Show quote ${index + 1}`}
                    aria-current={index === active}
                    className={`qotd-dot${index === active ? " qotd-dot-active" : ""}`}
                    onClick={() => carouselRef.current?.to(index)}
                  />
                ))}
              </div>

              <button
                type="button"
                className="qotd-arrow"
                aria-label="Next quote"
                onClick={() => carouselRef.current?.next()}
              >
                ›
              </button>
            </div>
          )}
        </div>
      )}

      {toast && (
        <div
          role="status"
          className="fixed bottom-6 left-1/2 z-[100] max-w-[90vw] -translate-x-1/2 rounded-full bg-primary px-6 py-3 text-center text-sm font-semibold text-white shadow-xl"
        >
          {toast}
        </div>
      )}
    </section>
  );
}
