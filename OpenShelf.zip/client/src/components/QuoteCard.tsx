import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import api from "../api/axios";
import { BookRequest, QuoteItem } from "../types";
import { emitQuoteLike } from "../utils/quoteEvents";
import BookCover from "./BookCover";
import RequestQR from "./RequestQR";
import { HeartIcon } from "./icons";

interface Props {
  quote: QuoteItem;
  isAdmin: boolean;
  // Called whenever the quote changes (like state, availability).
  onChange: (quote: QuoteItem) => void;
  onDelete?: (quote: QuoteItem) => void;
  onMessage: (message: string) => void;
  // "saved" = Words Worth Keeping: shows Remove instead of the like button.
  variant?: "default" | "saved";
  // Hide the book cover + source (used on the book's own page).
  hideBook?: boolean;
  large?: boolean;
  // Lets a parent (the Quote of the Day carousel) know when the QR dialog is open.
  onModalChange?: (open: boolean) => void;
}

const kindLabel = (quote: QuoteItem) =>
  quote.kind === "literary"
    ? "Public domain"
    : `Shared by ${quote.mine ? "you" : quote.addedByName}`;

// Stable pick of one of four subtle card tints, so the grid has variety that
// does not change as more cards load.
function toneFor(id: string) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) >>> 0;
  return `tone-${hash % 4}`;
}

export default function QuoteCard({
  quote,
  isAdmin,
  onChange,
  onDelete,
  onMessage,
  variant = "default",
  hideBook = false,
  large = false,
  onModalChange,
}: Props) {
  const [busy, setBusy] = useState(false);
  const [likeBusy, setLikeBusy] = useState(false);
  const [qrRequest, setQrRequest] = useState<BookRequest | null>(null);
  const { book } = quote;
  const location = useLocation();
  // Lets the book page offer a "Back to ..." link that returns to this page.
  const fromState = { from: location.pathname + location.search };
  const saved = variant === "saved";

  useEffect(() => {
    onModalChange?.(Boolean(qrRequest));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qrRequest]);

  async function setLiked(next: boolean) {
    if (likeBusy) return; // ignore repeated clicks while a request is running
    try {
      setLikeBusy(true);
      // Explicit desired state: repeating the call can never flip it back.
      const { data } = await api.post(`/quotes/${quote._id}/like`, { liked: next });
      const updated = { ...quote, liked: data.liked, likeCount: data.likeCount };
      onChange(updated);
      emitQuoteLike({ quoteId: quote._id, liked: data.liked, likeCount: data.likeCount });
      onMessage(data.liked ? "Added to Words Worth Keeping" : "Removed from Words Worth Keeping");
    } catch (err: any) {
      onMessage(err?.response?.data?.message || "Could not update this quote. Please try again.");
    } finally {
      setLikeBusy(false);
    }
  }

  async function borrow() {
    if (!book || busy) return;
    try {
      setBusy(true);
      // The existing OpenShelf request flow: the librarian scans the QR to issue.
      const { data } = await api.post<BookRequest>("/requests", {
        bookId: book._id,
        copyId: book.availableCopyId || undefined,
      });
      if (!data?.token) {
        onMessage("Could not create your request. Please try again.");
        return;
      }
      setQrRequest(data);
      onChange({
        ...quote,
        book: { ...book, availableCount: Math.max(0, book.availableCount - 1), availableCopyId: null },
      });
    } catch (err: any) {
      onMessage(err?.response?.data?.message || "Could not create your request");
    } finally {
      setBusy(false);
    }
  }

  async function joinWaitlist() {
    if (!book || busy) return;
    try {
      setBusy(true);
      const { data } = await api.post(`/books/${book._id}/waitlist/join`);
      onMessage(data.message || "Added to the waitlist");
      onChange({ ...quote, book: { ...book, onWaitlist: true, waitlistCount: book.waitlistCount + 1 } });
    } catch (err: any) {
      onMessage(err?.response?.data?.message || "Could not join the waitlist");
    } finally {
      setBusy(false);
    }
  }

  async function cancelRequest() {
    if (!qrRequest || !book) return;
    try {
      await api.post(`/requests/${qrRequest._id}/cancel`);
      setQrRequest(null);
      onMessage("Request cancelled");
      onChange({ ...quote, book: { ...book, availableCount: book.availableCount + 1 } });
    } catch (err: any) {
      onMessage(err?.response?.data?.message || "Could not cancel this request");
    }
  }

  const source = quote.sourceTitle || book?.title || "";
  const author = quote.author || book?.author || "";

  return (
    <>
      <figure className={`highlight-card ${toneFor(quote._id)} ${large ? "highlight-card-large" : ""}`}>
        <div className="highlight-top">
          <span className="highlight-kind">{kindLabel(quote)}</span>
          {onDelete && (quote.mine || isAdmin) && (
            <button type="button" onClick={() => onDelete(quote)} className="highlight-delete">
              Delete
            </button>
          )}
        </div>

        <blockquote className={`highlight-quote font-heading`}>
          <span className="highlight-mark" aria-hidden="true">“</span>
          {quote.text}
        </blockquote>

        <figcaption className="highlight-caption">
          {!hideBook && book && (
            <Link to={`/books/${book._id}`} state={fromState} className="highlight-cover" aria-label={`Open ${book.title}`}>
              <BookCover book={book} className="h-[68px] w-[46px] rounded-md text-xs" />
            </Link>
          )}
          <div className="min-w-0">
            {author && <div className="highlight-author">{author}</div>}
            {!hideBook && source && (
              <div className="highlight-source">
                {book ? (
                  <Link to={`/books/${book._id}`} state={fromState}>{source}</Link>
                ) : (
                  <span>{source}</span>
                )}
                {quote.attribution && quote.kind === "literary" ? ` · ${quote.attribution}` : ""}
              </div>
            )}
            {!hideBook && !source && quote.attribution && (
              <div className="highlight-source">{quote.attribution}</div>
            )}
            {hideBook && (quote.page || quote.addedByName) && (
              <div className="highlight-source">
                {quote.page ? `Page ${quote.page} · ` : ""}
                {quote.kind === "member" ? `added by ${quote.mine ? "you" : quote.addedByName}` : kindLabel(quote)}
              </div>
            )}
          </div>
        </figcaption>

        <div className="highlight-actions">
          {saved ? (
            <button
              type="button"
              onClick={() => void setLiked(false)}
              disabled={likeBusy}
              className="highlight-btn"
              aria-label="Remove this quote from Words Worth Keeping"
            >
              {likeBusy ? "Removing…" : "Remove"}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => void setLiked(!quote.liked)}
              disabled={likeBusy}
              aria-pressed={quote.liked}
              aria-label={quote.liked ? "Remove like" : "Like this quote"}
              className={`highlight-btn ${quote.liked ? "highlight-btn-on" : ""}`}
            >
              <HeartIcon filled={quote.liked} />
              <span>{quote.likeCount}</span>
            </button>
          )}

          {!hideBook && book && (
            <>
              <Link to={`/books/${book._id}`} state={fromState} className="highlight-btn">
                View book
              </Link>

              {!isAdmin &&
                (book.haveIt ? (
                  <span className="highlight-status highlight-status-ok">You are reading this</span>
                ) : book.availableCount > 0 ? (
                  <button
                    type="button"
                    onClick={() => void borrow()}
                    disabled={busy}
                    className="highlight-btn highlight-btn-primary"
                  >
                    {busy ? "Reserving…" : "Borrow this book"}
                  </button>
                ) : book.onWaitlist ? (
                  <span className="highlight-status">On the waitlist</span>
                ) : (
                  <button
                    type="button"
                    onClick={() => void joinWaitlist()}
                    disabled={busy}
                    className="highlight-btn highlight-btn-primary"
                  >
                    Join waitlist ({book.waitlistCount})
                  </button>
                ))}
            </>
          )}
        </div>

        {!hideBook && (
          <div className="highlight-availability">
            {book
              ? book.availableCount > 0
                ? `${book.availableCount} ${book.availableCount === 1 ? "copy" : "copies"} available`
                : "All copies are borrowed"
              : "\u00a0"}
          </div>
        )}
      </figure>

      {qrRequest && book && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-5">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby={`qr-title-${quote._id}`}
            className="modal-panel w-full max-w-[360px] rounded-2xl p-7 text-center shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <h2 id={`qr-title-${quote._id}`} className="mb-1 font-heading text-xl font-bold">
              Your request is ready
            </h2>
            <p className="mb-4 text-[13.5px] text-ink-600">
              Show this QR to the librarian to collect <b className="text-ink-900">{book.title}</b>.
              {qrRequest.expiresAt && ` Valid until ${new Date(qrRequest.expiresAt).toLocaleString()}.`}
            </p>

            <div className="mb-4 flex justify-center">
              {qrRequest.token ? (
                <RequestQR token={qrRequest.token} />
              ) : (
                <p className="text-sm text-danger">QR token is missing.</p>
              )}
            </div>

            <div className="flex justify-center gap-2">
              <button
                type="button"
                onClick={() => void cancelRequest()}
                className="rounded-full border border-line px-5 py-2 text-sm font-semibold text-danger"
              >
                Cancel request
              </button>
              <button
                type="button"
                onClick={() => setQrRequest(null)}
                className="rounded-full bg-gold-500 px-5 py-2 text-sm font-bold text-[#2A1B00]"
              >
                Done
              </button>
            </div>

            <p className="mb-0 mt-3 text-[12px] text-ink-600">You can find this QR again under My Account.</p>
          </div>
        </div>
      )}
    </>
  );
}
