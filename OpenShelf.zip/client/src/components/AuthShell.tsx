import { ReactNode } from "react";
import { Link } from "react-router-dom";
import ThemeToggle from "./ThemeToggle";

interface Props {
  mode: "login" | "register";
  children: ReactNode;
}

export default function AuthShell({ mode, children }: Props) {
  const isLogin = mode === "login";

  return (
    <main className="auth-scene flex h-dvh w-full items-center justify-center overflow-hidden p-3 sm:p-4">
      <div className="auth-panel mx-auto grid h-full max-h-[792px] min-h-0 w-full max-w-[1356px] overflow-hidden rounded-[30px] lg:grid-cols-[1.04fr_.96fr]">
        <section className="auth-art relative hidden min-h-0 flex-col justify-between overflow-hidden p-8 text-white lg:flex xl:p-10">
          <div className="auth-orb" aria-hidden="true">
            <span />
            <i />
            <b />
          </div>

          <div className="relative z-10 flex items-center gap-3">
            <span className="brand-mark">
              <BookMark />
            </span>
            <span className="font-heading text-xl font-bold tracking-tight">
              openshelf
            </span>
          </div>

          <div className="relative z-10 max-w-xl py-5">
            <p className="mb-4 text-xs font-bold uppercase tracking-[.24em] text-sky-100/75">
              A quieter kind of discovery
            </p>

            <h1 className="font-heading text-5xl font-semibold leading-[1.08] tracking-[-.04em] xl:text-6xl">
              {isLogin ? (
                <>
                  Your next
                  <br />
                  great read
                  <br />
                  <span className="text-sky-200">is waiting.</span>
                </>
              ) : (
                <>
                  Make room
                  <br />
                  for a new
                  <br />
                  <span className="text-sky-200">chapter.</span>
                </>
              )}
            </h1>

            <p className="mt-5 max-w-sm text-base leading-7 text-blue-50/75">
              {isLogin
                ? "Pick up where you left off. Your library, your reading list, all in one place."
                : "Join a community that makes finding, borrowing, and sharing good books easy."}
            </p>
          </div>

          <div className="relative z-10 text-xs text-blue-50/65">
            <span>Find a book. Find your place.</span>
          </div>

          <div className="auth-grid-glow" aria-hidden="true" />
        </section>

        <section className="relative flex min-h-0 items-center justify-center overflow-y-auto bg-white px-5 py-5 sm:px-8 lg:px-10 xl:px-14">
          <ThemeToggle className="!absolute right-4 top-4 !bg-blue-50 !text-blue-950 hover:!bg-sky-100 sm:right-5 sm:top-5" />

          <div className="my-auto w-full max-w-[420px] py-10 sm:py-8">
            <Link
              to="/"
              className="mb-5 inline-flex items-center gap-2.5 text-blue-950 lg:hidden"
            >
              <span className="brand-mark brand-mark-small">
                <BookMark />
              </span>
              <span className="font-heading text-lg font-bold">
                openshelf
              </span>
            </Link>

            <p className="mb-2 text-xs font-bold uppercase tracking-[.2em] text-blue-500">
              {isLogin ? "Welcome back" : "Get started"}
            </p>

            <h2 className="font-heading text-3xl font-semibold tracking-[-.035em] text-slate-950 sm:text-[2.15rem]">
              {isLogin ? "Sign in to Openshelf" : "Create your account"}
            </h2>

            <p className="mb-5 mt-2 text-sm leading-6 text-slate-500">
              {isLogin
                ? "Your reading life is right where you left it."
                : "A good story starts with a library card."}
            </p>

            {children}

            <p className="mt-5 text-center text-sm text-slate-500">
              {isLogin
                ? "New to Openshelf? "
                : "Already have an account? "}
              <Link
                to={isLogin ? "/register" : "/login"}
                className="font-semibold text-blue-700 hover:text-sky-600"
              >
                {isLogin ? "Create an account" : "Sign in"}
              </Link>
            </p>

            <p className="mt-6 text-center text-xs text-slate-400">
              A welcoming place for every kind of reader.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}

function BookMark() {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M4.5 5.5c3.1-.8 5.6-.3 7.5 1.4v13c-1.9-1.7-4.4-2.2-7.5-1.4v-13Zm15 0c-3.1-.8-5.6-.3-7.5 1.4v13c1.9-1.7 4.4-2.2 7.5-1.4v-13Z"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinejoin="round"
      />
      <path
        d="M12 7v12.9"
        stroke="currentColor"
        strokeWidth="1.5"
      />
    </svg>
  );
}