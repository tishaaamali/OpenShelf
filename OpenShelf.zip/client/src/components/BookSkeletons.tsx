import type { CSSProperties, ReactNode } from "react";

// Skeleton placeholders - the ONLY loading indicator used across the site.
// Every skeleton below mirrors the real layout it stands in for (same card
// sizes, headings, rows and thumbnails) so nothing jumps when data arrives.

// One shimmering block. Everything layout-matched below is built from these.
export function Sk({
  w = "100%",
  h = 12,
  r = 999,
  className = "",
  style,
}: {
  w?: number | string;
  h?: number | string;
  r?: number | string;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <span
      aria-hidden="true"
      className={`sk-block ${className}`}
      style={{ width: w, height: h, borderRadius: r, ...style }}
    />
  );
}

// Card shell used by the layout-matched skeletons.
function SkPanel({
  children,
  className = "",
  style,
}: {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <div className={`sk-panel ${className}`} style={style} aria-hidden="true">
      {children}
    </div>
  );
}

export function BookCardSkeletons({ count = 10 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }, (_, index) => (
        <div key={index} className="book-skeleton" aria-hidden="true">
          <span />
          <i />
          <i />
        </div>
      ))}
    </>
  );
}

export function BookRowSkeletons({ count = 5 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }, (_, index) => (
        <div key={index} className="book-row-skeleton" aria-hidden="true">
          <span />
          <div>
            <i />
            <i />
            <i />
          </div>
        </div>
      ))}
    </>
  );
}

// Skeleton for a Book Highlights card. Heights mirror the real card (quote
// text, cover thumbnail + attribution, action row) so nothing jumps when the
// real content arrives. `compact` matches the Words Worth Keeping preview card.
export function QuoteCardSkeletons({
  count = 6,
  compact = false,
  noCover = false,
}: {
  count?: number;
  compact?: boolean;
  // Cards on a book's own page have no cover thumbnail or book actions.
  noCover?: boolean;
}) {
  return (
    <>
      {Array.from({ length: count }, (_, index) => (
        <div
          key={index}
          className={`highlight-skeleton ${compact ? "highlight-skeleton-compact" : ""} ${noCover ? "highlight-skeleton-book" : ""}`}
          aria-hidden="true"
        >
          <Sk w="26%" h={10} />
          <Sk w="100%" h={17} />
          <Sk w="100%" h={17} />
          <Sk w="62%" h={17} />
          <div className="sk-footer">
            {!noCover && <Sk w={46} h={68} r={6} />}
            <div className="sk-meta">
              <Sk w="70%" h={11} />
              <Sk w="46%" h={9} />
            </div>
          </div>
          {!compact && (
            <div className="sk-actions">
              <Sk w={64} h={30} />
              {!noCover && <Sk w={120} h={30} />}
            </div>
          )}
        </div>
      ))}
    </>
  );
}

// ---- Generic skeletons for community / list pages -------------------------

// Grid of cards matching the Reading Lists cards.
export function ListCardSkeletons({ count = 6 }: { count?: number }) {
  return (
    <div
      className="grid grid-cols-[repeat(auto-fill,minmax(260px,1fr))] gap-4"
      aria-busy="true"
      aria-label="Loading"
    >
      {Array.from({ length: count }, (_, i) => (
        <SkPanel key={i} className="sk-panel-sm">
          <div className="mb-3 flex items-center gap-2">
            <Sk w="52%" h={16} />
            <Sk w={44} h={16} />
          </div>
          <Sk h={12} className="mb-2" />
          <Sk w="72%" h={12} className="mb-4" />
          <Sk w="80%" h={10} />
        </SkPanel>
      ))}
    </div>
  );
}

// Stacked rows matching discussion / review / comment rows.
export function RowSkeletons({ count = 4 }: { count?: number }) {
  return (
    <div className="flex flex-col gap-3" aria-busy="true" aria-label="Loading">
      {Array.from({ length: count }, (_, i) => (
        <SkPanel key={i} className="sk-panel-sm">
          <Sk w="54%" h={15} className="mb-2.5" />
          <Sk w="34%" h={12} className="mb-3" />
          <Sk w="66%" h={10} />
        </SkPanel>
      ))}
    </div>
  );
}

// Full-page placeholder used by detail pages while their data loads.
//  - "thread": a discussion (back link, post card, replies)
//  - "list":   a reading list (back link, header card, book grid)
//  - default:  a header card followed by rows
export function PageSkeleton({ variant = "default" }: { variant?: "default" | "thread" | "list" }) {
  if (variant === "thread") {
    return (
      <div className="library-page mx-auto max-w-3xl" aria-busy="true" aria-label="Loading discussion">
        <Sk w={150} h={14} className="mb-5" />
        <SkPanel>
          <Sk w={64} h={18} className="mb-3" />
          <Sk w="62%" h={24} r={8} className="mb-3" />
          <Sk w="46%" h={12} className="mb-5" />
          <Sk h={13} className="mb-2.5" />
          <Sk h={13} className="mb-2.5" />
          <Sk w="74%" h={13} className="mb-5" />
          <div className="flex gap-2">
            <Sk w={104} h={32} />
            <Sk w={64} h={32} />
          </div>
        </SkPanel>
        <Sk w={90} h={16} className="mb-3 mt-7" />
        <div className="flex flex-col gap-3">
          {[0, 1, 2].map((i) => (
            <SkPanel key={i} className="sk-panel-sm">
              <div className="mb-3 flex items-center gap-2.5">
                <Sk w={30} h={30} />
                <Sk w={120} h={12} />
                <Sk w={60} h={10} />
              </div>
              <Sk h={12} className="mb-2" />
              <Sk w="68%" h={12} />
            </SkPanel>
          ))}
        </div>
      </div>
    );
  }

  if (variant === "list") {
    return (
      <div className="library-page" aria-busy="true" aria-label="Loading reading list">
        <Sk w={90} h={14} className="mb-5" />
        <SkPanel className="mb-6">
          <div className="mb-3 flex items-center gap-2.5">
            <Sk w={230} h={24} r={8} />
            <Sk w={54} h={18} />
          </div>
          <Sk w="70%" h={13} className="mb-2.5" />
          <Sk w="38%" h={12} className="mb-4" />
          <div className="flex gap-2">
            <Sk w={64} h={30} />
            <Sk w={84} h={30} />
          </div>
        </SkPanel>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(230px,1fr))] gap-5">
          <BookCardSkeletons count={5} />
        </div>
      </div>
    );
  }

  return (
    <div className="library-page" aria-busy="true" aria-label="Loading">
      <SkPanel className="mb-4" style={{ minHeight: 120 }}>
        <Sk w="45%" h={20} r={8} className="mb-4" />
        <Sk h={12} className="mb-2.5" />
        <Sk w="60%" h={12} />
      </SkPanel>
      <RowSkeletons count={3} />
    </div>
  );
}

// ---- Layout-matched skeletons ---------------------------------------------

// My Account: heading, 4 stat cards, borrowed / waitlist panels, QR requests,
// ratings & reviews, then the profile form.
export function StatCardSkeleton() {
  return (
    <SkPanel className="sk-panel-sm">
      <Sk w={46} h={28} r={8} className="mb-2.5" />
      <Sk w="62%" h={12} />
    </SkPanel>
  );
}

// A book row with a thumbnail, as used in Currently Borrowed / Waitlist.
export function BookThumbRowSkeletons({ count = 2, large = false }: { count?: number; large?: boolean }) {
  return (
    <div aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="sk-thumb-row">
          <Sk w={large ? 66 : 58} h={large ? 96 : 84} r={8} />
          <div className="min-w-0 flex-1">
            <Sk w="58%" h={14} className="mb-2.5" />
            <Sk w="40%" h={11} className="mb-3" />
            <Sk w={72} h={20} />
          </div>
        </div>
      ))}
    </div>
  );
}

// Rows for "My Book Requests (QR)" (thumbnail, title, dates, status + actions).
export function RequestRowSkeletons({ count = 2 }: { count?: number }) {
  return (
    <div aria-busy="true" aria-label="Loading your requests">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="sk-thumb-row">
          <Sk w={66} h={96} r={8} />
          <div className="min-w-0 flex-1">
            <Sk w="46%" h={14} className="mb-2.5" />
            <Sk w="30%" h={11} />
          </div>
          <div className="flex items-center gap-2">
            <Sk w={72} h={22} />
            <Sk w={74} h={28} />
          </div>
        </div>
      ))}
    </div>
  );
}

// Rows for "My Ratings & Reviews" (title + stars, review line, date).
export function ReviewRowSkeletons({ count = 2 }: { count?: number }) {
  return (
    <div aria-busy="true" aria-label="Loading reviews">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="sk-review-row">
          <div className="mb-2.5 flex items-center justify-between gap-3">
            <Sk w="38%" h={14} />
            <Sk w={84} h={14} />
          </div>
          <Sk w="86%" h={12} className="mb-2" />
          <Sk w={70} h={10} />
        </div>
      ))}
    </div>
  );
}

// A panel with a heading and whatever skeleton rows are passed in.
export function PanelSkeleton({
  children,
  titleWidth = 150,
  className = "",
}: {
  children: ReactNode;
  titleWidth?: number;
  className?: string;
}) {
  return (
    <SkPanel className={className}>
      <Sk w={titleWidth} h={16} r={8} className="mb-5" />
      {children}
    </SkPanel>
  );
}

function ProfileFormSkeleton() {
  return (
    <SkPanel className="mt-6 max-w-[480px]">
      <Sk w={70} h={16} r={8} className="mb-5" />
      <div className="mb-3.5 grid grid-cols-2 gap-3 max-sm:grid-cols-1">
        <div><Sk w={70} h={11} className="mb-2" /><Sk h={42} r={8} /></div>
        <div><Sk w={70} h={11} className="mb-2" /><Sk h={42} r={8} /></div>
      </div>
      {[0, 1, 2].map((i) => (
        <div key={i} className="mb-3.5">
          <Sk w={110} h={11} className="mb-2" />
          <Sk h={42} r={8} />
        </div>
      ))}
      <Sk w={128} h={40} />
    </SkPanel>
  );
}

export function AccountSkeleton({ isAdmin = false }: { isAdmin?: boolean }) {
  return (
    <div className="library-page account-page" aria-busy="true" aria-label="Loading your account">
      <div className="mb-6">
        <div className="mb-2.5 flex items-center gap-3">
          <Sk w={170} h={28} r={8} />
          <Sk w={72} h={22} />
        </div>
        <Sk w={250} h={14} />
      </div>

      {!isAdmin && (
        <>
          <div className="mb-6 grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-4">
            {[0, 1, 2, 3].map((i) => (
              <StatCardSkeleton key={i} />
            ))}
          </div>

          <div className="grid grid-cols-2 gap-6 max-md:grid-cols-1">
            <PanelSkeleton titleWidth={150}>
              <BookThumbRowSkeletons count={1} />
            </PanelSkeleton>
            <PanelSkeleton titleWidth={130}>
              <BookThumbRowSkeletons count={1} />
            </PanelSkeleton>
          </div>

          <div className="mt-6">
            <PanelSkeleton titleWidth={190}>
              <RequestRowSkeletons count={1} />
            </PanelSkeleton>
          </div>

          <div className="mt-6">
            <PanelSkeleton titleWidth={170}>
              <ReviewRowSkeletons count={2} />
            </PanelSkeleton>
          </div>
        </>
      )}

      <ProfileFormSkeleton />
    </div>
  );
}

// Book detail page: back link, cover + title block, description, copies table.
export function BookDetailSkeleton() {
  return (
    <div className="library-page book-detail-page" aria-busy="true" aria-label="Loading book">
      <Sk w={130} h={14} className="mb-5" />
      <div className="grid grid-cols-[220px_1fr] gap-9 max-md:grid-cols-1">
        <Sk w="100%" h={290} r={16} />
        <div>
          <Sk w="62%" h={28} r={8} className="mb-3" />
          <Sk w="38%" h={14} className="mb-5" />
          <div className="mb-5 flex gap-2">
            <Sk w={86} h={22} />
            <Sk w={110} h={22} />
          </div>
          <Sk h={12} className="mb-2.5" />
          <Sk h={12} className="mb-2.5" />
          <Sk w="80%" h={12} className="mb-6" />
          <div className="flex gap-3">
            <Sk w={132} h={40} />
            <Sk w={100} h={40} />
          </div>
        </div>
      </div>

      <div className="mt-9">
        <Sk w={80} h={18} r={8} className="mb-4" />
        {[0, 1, 2].map((i) => (
          <div key={i} className="mb-3 flex items-center gap-6">
            <Sk w={90} h={12} />
            <Sk w={40} h={12} />
            <Sk w={60} h={12} />
            <Sk w={72} h={20} />
            <Sk w={110} h={30} className="ml-auto" />
          </div>
        ))}
      </div>
    </div>
  );
}

// Home page: featured carousel card, quote of the day, category chips, shelves.
export function HomeSkeleton({ pageSize = 10 }: { pageSize?: number }) {
  return (
    <div className="home-content" aria-busy="true" aria-label="Loading home">
      <SkPanel className="mb-8 flex flex-wrap items-center gap-7" style={{ padding: 32 }}>
        <Sk w={132} h={184} r={12} />
        <div className="min-w-0 flex-1">
          <Sk w={120} h={11} className="mb-3" />
          <Sk w="40%" h={22} r={8} className="mb-3" />
          <Sk w="30%" h={13} className="mb-4" />
          <Sk w="70%" h={12} className="mb-2" />
          <Sk w="52%" h={12} className="mb-5" />
          <Sk w={128} h={40} />
        </div>
      </SkPanel>

      <div className="mb-8">
        <div className="mb-3 flex items-center justify-between">
          <Sk w={150} h={19} r={8} />
          <Sk w={170} h={13} />
        </div>
        <QuoteOfTheDaySkeleton />
      </div>

      <div className="mb-8 flex flex-wrap gap-2.5">
        {[96, 84, 90, 100, 120, 92, 104, 110].map((w, i) => (
          <Sk key={i} w={w} h={36} />
        ))}
      </div>

      <div className="mb-4 flex items-center justify-between">
        <Sk w={130} h={17} r={8} />
        <Sk w={110} h={13} />
      </div>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(230px,1fr))] gap-5">
        <BookCardSkeletons count={pageSize} />
      </div>
    </div>
  );
}

// Full-width Quote of the Day card (matches the large quote card).
export function QuoteOfTheDaySkeleton() {
  return (
    <div aria-busy="true" aria-label="Loading quote of the day">
      <div className="highlight-skeleton highlight-skeleton-large" aria-hidden="true">
        <Sk w={110} h={10} />
        <div className="flex flex-col gap-2.5">
          <Sk w="84%" h={26} r={8} />
          <Sk w="52%" h={26} r={8} />
        </div>
        <div className="sk-footer">
          <Sk w={46} h={68} r={6} />
          <div className="sk-meta">
            <Sk w={150} h={12} />
            <Sk w={110} h={10} />
          </div>
        </div>
        <div className="sk-actions">
          <Sk w={64} h={30} />
          <Sk w={96} h={30} />
          <Sk w={140} h={30} />
        </div>
      </div>
      <div className="mt-3 flex justify-center gap-2" aria-hidden="true">
        {[0, 1, 2, 3, 4].map((i) => (
          <Sk key={i} w={i === 0 ? 24 : 8} h={8} />
        ))}
      </div>
    </div>
  );
}

// Notification rows (bell menu and the full Notifications page).
export function NotificationRowSkeletons({ count = 5, framed = false }: { count?: number; framed?: boolean }) {
  return (
    <div
      className={framed ? "sk-notification-list" : ""}
      aria-busy="true"
      aria-label="Loading notifications"
    >
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="sk-notification-row" aria-hidden="true">
          <Sk w={8} h={8} className="mt-1.5" />
          <div className="min-w-0 flex-1">
            <Sk w={i % 2 ? "74%" : "90%"} h={12} className="mb-2" />
            <Sk w={64} h={10} />
          </div>
        </div>
      ))}
    </div>
  );
}

// Result card of Scan & Issue while a request is being looked up or issued.
export function RequestDetailsSkeleton() {
  return (
    <div
      className="mt-4 rounded-xl border border-line p-4"
      aria-busy="true"
      aria-label="Loading request"
    >
      <Sk w="48%" h={16} className="mb-2.5" />
      <Sk w="30%" h={12} className="mb-4" />
      <Sk w="62%" h={12} className="mb-2.5" />
      <Sk w="80%" h={12} className="mb-4" />
      <div className="flex items-center gap-2">
        <Sk w={64} h={22} />
        <Sk w={110} h={12} />
      </div>
    </div>
  );
}

// Table rows for the admin Members list.
export function TableRowSkeletons({ count = 6 }: { count?: number }) {
  return (
    <div aria-busy="true" aria-label="Loading members">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="sk-table-row" aria-hidden="true">
          <Sk w="22%" h={13} />
          <Sk w="30%" h={12} />
          <Sk w={64} h={22} />
          <div className="ml-auto flex gap-2">
            <Sk w={36} h={36} r={8} />
            <Sk w={36} h={36} r={8} />
          </div>
        </div>
      ))}
    </div>
  );
}

// Cards for "My Ratings & Reviews" page.
export function ReviewCardSkeletons({ count = 4 }: { count?: number }) {
  return (
    <div className="space-y-4" aria-busy="true" aria-label="Loading reviews">
      {Array.from({ length: count }, (_, i) => (
        <SkPanel key={i} className="sk-panel-sm">
          <div className="mb-3 flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <Sk w="34%" h={15} className="mb-2" />
              <Sk w="22%" h={11} />
            </div>
            <Sk w={88} h={14} />
          </div>
          <Sk h={12} className="mb-2" />
          <Sk w="64%" h={12} />
        </SkPanel>
      ))}
    </div>
  );
}

// Dashboard: stat row, wide panel, then two-column rows of list panels.
export function DashboardLayoutSkeleton({ isAdmin = false }: { isAdmin?: boolean }) {
  const listRows = (count: number) =>
    Array.from({ length: count }, (_, i) => (
      <div key={i} className="sk-list-row">
        <Sk w={36} h={52} r={6} />
        <div className="min-w-0 flex-1">
          <Sk w="62%" h={13} className="mb-2" />
          <Sk w="38%" h={10} />
        </div>
        <Sk w={44} h={14} />
      </div>
    ));

  return (
    <div className="library-page dashboard-page" aria-busy="true" aria-label="Loading dashboard">
      <div className="mb-6">
        <div className="library-eyebrow">LIBRARY INSIGHTS</div>
        <h1 className="m-0 mb-1.5 font-heading text-2xl font-bold">Dashboard</h1>
        <p className="m-0 text-[14.5px] text-ink-600">Library overview at a glance</p>
      </div>

      <div className="mt-6">
        <PanelSkeleton titleWidth={170}>{listRows(3)}</PanelSkeleton>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-6 max-md:grid-cols-1">
        <PanelSkeleton titleWidth={150}>{listRows(3)}</PanelSkeleton>
        <PanelSkeleton titleWidth={130}>{listRows(3)}</PanelSkeleton>
      </div>

      {isAdmin && (
        <div className="mt-6 grid grid-cols-2 gap-6 max-md:grid-cols-1">
          <PanelSkeleton titleWidth={120}>{listRows(2)}</PanelSkeleton>
          <PanelSkeleton titleWidth={160}>{listRows(2)}</PanelSkeleton>
        </div>
      )}

      <div className={`mt-6 grid gap-6 max-md:grid-cols-1 ${isAdmin ? "grid-cols-2" : "grid-cols-1"}`}>
        <PanelSkeleton titleWidth={130}>{listRows(3)}</PanelSkeleton>
        {isAdmin && <PanelSkeleton titleWidth={120}>{listRows(3)}</PanelSkeleton>}
      </div>
    </div>
  );
}

// Small inline placeholder for single-line text (counts, short labels).
export function InlineSkeleton({ width = 80 }: { width?: number }) {
  return <span className="sk-bar sk-inline" style={{ width }} aria-hidden="true" />;
}
