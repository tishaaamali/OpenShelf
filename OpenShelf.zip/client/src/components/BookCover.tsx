import { CSSProperties } from "react";
import { Book } from "../types";

const COVER_GRADIENTS = [
  "linear-gradient(135deg,#2454D6,#16215C)",
  "linear-gradient(135deg,#F5A623,#DE8E0E)",
  "linear-gradient(135deg,#2FA86A,#16215C)",
  "linear-gradient(135deg,#E5484D,#16215C)",
  "linear-gradient(135deg,#3B6FE0,#0B1230)",
  "linear-gradient(135deg,#DE8E0E,#2454D6)",
];

function initialsFor(title: string) {
  return title.split(" ").slice(0, 2).map((word) => word[0]).join("").toUpperCase();
}

interface Props {
  book: Pick<Book, "title" | "isbn13" | "isbn10"> & Partial<Pick<Book, "coverImage">>;
  index?: number;
  className?: string;
  style?: CSSProperties;
  label?: boolean;
}

export default function BookCover({ book, index = 0, className = "", style, label = false }: Props) {
  const isbn = book.isbn13 || book.isbn10;
  const coverUrl = isbn
    ? `https://covers.openlibrary.org/b/isbn/${encodeURIComponent(isbn)}-M.jpg?default=false`
    : "";

  return (
    <div
      className={`book-cover-art relative flex items-center justify-center overflow-hidden text-center text-white ${className}`}
      style={{ background: COVER_GRADIENTS[index % COVER_GRADIENTS.length], ...style }}
    >
      <span className="book-cover-fallback font-heading font-bold" aria-hidden="true">{initialsFor(book.title)}</span>
      {(book.coverImage || coverUrl) && (
        <img
          src={book.coverImage || coverUrl}
          alt={label ? `Cover of ${book.title}` : ""}
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
          onError={(event) => { event.currentTarget.style.display = "none"; }}
        />
      )}
      {label && <span className="sr-only">{book.title} book cover</span>}
      <span className="book-cover-sheen pointer-events-none absolute inset-0" aria-hidden="true" />
    </div>
  );
}
