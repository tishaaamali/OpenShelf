import { useState } from "react";
import type { FormEvent } from "react";
import api from "../api/axios";
import { useConfirm } from "../context/ConfirmContext";
import { Book } from "../types";

type EditableBook = Pick<
  Book,
  | "title"
  | "author"
  | "category"
  | "language"
  | "publisher"
  | "edition"
  | "year"
  | "isbn13"
  | "isbn10"
  | "format"
  | "description"
>;

interface Props {
  book: Book;
  onUpdated: (book: Book) => void;
  onDeleted: () => void;
  onMessage: (message: string) => void;
}

const inputClass =
  "w-full rounded-lg border border-line bg-field px-3 py-2.5 text-sm text-ink-900 outline-none focus:border-primary";
const labelClass = "mb-1 block text-xs font-semibold text-ink-600";

export default function AdminBookActions({
  book,
  onUpdated,
  onDeleted,
  onMessage,
}: Props) {
  const confirm = useConfirm();
  const [editing, setEditing] = useState(false);
  const [addingCopies, setAddingCopies] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [numberOfCopies, setNumberOfCopies] = useState("1");
  const [shelf, setShelf] = useState(book.copies[0]?.shelf || "");
  const [form, setForm] = useState<EditableBook>(() => toEditableBook(book));

  function toEditableBook(value: Book): EditableBook {
    return {
      title: value.title || "",
      author: value.author || "",
      category: value.category || "",
      language: value.language || "",
      publisher: value.publisher || "",
      edition: value.edition || "",
      year: value.year || 0,
      isbn13: value.isbn13 === "—" ? "" : value.isbn13 || "",
      isbn10: value.isbn10 === "—" ? "" : value.isbn10 || "",
      format: value.format,
      description: value.description || "",
    };
  }

  function openEditor() {
    setForm(toEditableBook(book));
    setError("");
    setEditing(true);
  }

  async function saveBook(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");

    const validIsbn13 = /^\d{13}$/.test(form.isbn13);
    const validIsbn10 = /^\d{10}$/.test(form.isbn10);
    if (!validIsbn13 && !validIsbn10) {
      setError("Enter exactly 10 or 13 ISBN digits.");
      return;
    }

    try {
      setSaving(true);
      const { data } = await api.patch<Book>(`/books/${book._id}`, {
        ...form,
        year: form.year || undefined,
        isbn10: form.isbn10 || "—",
      });
      onUpdated(data);
      setEditing(false);
      onMessage("Book details updated.");
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not update the book.");
    } finally {
      setSaving(false);
    }
  }

  async function removeBook() {
    if (
      !(await confirm({
        title: `Delete “${book.title}”?`,
        message: "All of its copies will be removed too. This cannot be undone.",
        confirmLabel: "Delete book",
      }))
    )
      return;

    try {
      setSaving(true);
      await api.delete(`/books/${book._id}`);
      onDeleted();
    } catch (err: any) {
      onMessage(err?.response?.data?.message || "Could not delete the book.");
      setSaving(false);
    }
  }

  async function saveCopies(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");

    const count = Number(numberOfCopies);
    if (!Number.isInteger(count) || count < 1 || count > 100) {
      setError("Enter a whole number from 1 to 100.");
      return;
    }

    try {
      setSaving(true);
      const { data } = await api.post<Book>(`/books/${book._id}/copies`, {
        numberOfCopies: count,
        shelf: shelf.trim(),
      });
      onUpdated(data);
      setAddingCopies(false);
      onMessage(`${count} ${count === 1 ? "copy" : "copies"} added.`);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not add copies.");
    } finally {
      setSaving(false);
    }
  }

  const closeModals = () => {
    if (saving) return;
    setEditing(false);
    setAddingCopies(false);
    setError("");
  };

  return (
    <>
      <div className="mb-6 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={openEditor}
          className="rounded-lg border border-line px-4 py-2 text-sm font-semibold text-ink-900 hover:border-primary"
        >
          Edit Book Details
        </button>
        <button
          type="button"
          onClick={() => {
            setShelf(book.copies[0]?.shelf || "");
            setError("");
            setAddingCopies(true);
          }}
          className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-primary-hover"
        >
          Add Copies
        </button>
        <button
          type="button"
          onClick={() => void removeBook()}
          disabled={saving}
          className="rounded-lg border border-danger px-4 py-2 text-sm font-semibold text-danger hover:bg-danger-bg disabled:opacity-50"
        >
          Delete Book
        </button>
      </div>

      {(editing || addingCopies) && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-black/60 p-4"
          style={{ backgroundColor: "rgba(2, 8, 23, .88)" }}
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) closeModals();
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby={editing ? "edit-book-title" : "add-copies-title"}
            className="modal-panel my-auto max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-line p-6 shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <div className="mb-5 flex items-start justify-between">
              <div>
                <p className="library-eyebrow">BOOK MANAGEMENT</p>
                <h2 id={editing ? "edit-book-title" : "add-copies-title"} className="font-heading text-xl font-bold">
                  {editing ? "Edit Book Details" : "Add Copies"}
                </h2>
              </div>
              <button type="button" onClick={closeModals} disabled={saving} aria-label="Close" className="text-2xl text-ink-600 disabled:opacity-50">
                ×
              </button>
            </div>

            {error && <p role="alert" className="mb-4 rounded-lg border border-danger bg-danger-bg p-3 text-sm text-danger">{error}</p>}

            {editing ? (
              <form onSubmit={saveBook} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Title" className="sm:col-span-2">
                  <input required value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} className={inputClass} />
                </Field>
                <Field label="Author">
                  <input required value={form.author} onChange={(event) => setForm({ ...form, author: event.target.value })} className={inputClass} />
                </Field>
                <Field label="Category">
                  <input required value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })} className={inputClass} />
                </Field>
                <Field label="Language">
                  <input required value={form.language} onChange={(event) => setForm({ ...form, language: event.target.value })} className={inputClass} />
                </Field>
                <Field label="Format">
                  <select value={form.format} onChange={(event) => setForm({ ...form, format: event.target.value as Book["format"] })} className={inputClass}>
                    <option>Hardcover</option>
                    <option>Paperback</option>
                    <option>eBook</option>
                    <option>Audio Book</option>
                  </select>
                </Field>
                <Field label="ISBN-13">
                  <input inputMode="numeric" maxLength={13} value={form.isbn13} onChange={(event) => setForm({ ...form, isbn13: event.target.value.replace(/\D/g, "").slice(0, 13) })} className={inputClass} />
                </Field>
                <Field label="ISBN-10">
                  <input inputMode="numeric" maxLength={10} value={form.isbn10} onChange={(event) => setForm({ ...form, isbn10: event.target.value.replace(/\D/g, "").slice(0, 10) })} className={inputClass} />
                </Field>
                <Field label="Publisher">
                  <input value={form.publisher} onChange={(event) => setForm({ ...form, publisher: event.target.value })} className={inputClass} />
                </Field>
                <Field label="Edition">
                  <input value={form.edition} onChange={(event) => setForm({ ...form, edition: event.target.value })} className={inputClass} />
                </Field>
                <Field label="Publication year">
                  <input type="number" min="1" max="9999" value={form.year || ""} onChange={(event) => setForm({ ...form, year: Number(event.target.value) })} className={inputClass} />
                </Field>
                <Field label="Description" className="sm:col-span-2">
                  <textarea rows={4} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} className={`${inputClass} resize-y`} />
                </Field>
                <div className="sm:col-span-2 flex justify-end gap-3 pt-2">
                  <button type="button" onClick={closeModals} disabled={saving} className="rounded-lg border border-line px-4 py-2 text-sm font-semibold">Cancel</button>
                  <button type="submit" disabled={saving} className="rounded-lg bg-primary px-5 py-2 text-sm font-bold text-white disabled:opacity-50">{saving ? "Saving…" : "Save Changes"}</button>
                </div>
              </form>
            ) : (
              <form onSubmit={saveCopies} className="space-y-4">
                <Field label="Number of copies">
                  <input type="number" required min="1" max="100" step="1" value={numberOfCopies} onChange={(event) => setNumberOfCopies(event.target.value)} className={inputClass} />
                </Field>
                <Field label="Shelf / rack">
                  <input required value={shelf} onChange={(event) => setShelf(event.target.value)} placeholder="e.g. A-12" className={inputClass} />
                </Field>
                <div className="flex justify-end gap-3 pt-2">
                  <button type="button" onClick={closeModals} disabled={saving} className="rounded-lg border border-line px-4 py-2 text-sm font-semibold">Cancel</button>
                  <button type="submit" disabled={saving} className="rounded-lg bg-primary px-5 py-2 text-sm font-bold text-white disabled:opacity-50">{saving ? "Adding…" : "Add Copies"}</button>
                </div>
              </form>
            )}
          </section>
        </div>
      )}
    </>
  );
}

function Field({
  label,
  className = "",
  children,
}: {
  label: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <label className={className}>
      <span className={labelClass}>{label}</span>
      {children}
    </label>
  );
}
