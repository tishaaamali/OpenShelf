import { useState } from "react";
import {
  Link,
  useNavigate,
  useLocation,
} from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useConfirm } from "../context/ConfirmContext";
import ThemeToggle from "./ThemeToggle";
import SearchIcon from "./SearchIcon";
import NotificationBell from "./NotificationBell";
import { BookIcon } from "./icons";

export default function Navbar() {
  const { user, logout } = useAuth();
  const confirm = useConfirm();

  const [menuOpen, setMenuOpen] = useState(false);
  const [communityOpen, setCommunityOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [search, setSearch] = useState("");

  const navigate = useNavigate();
  const location = useLocation();

  const isAdmin = user?.role === "admin";

  const communityLinks = [
    { to: "/highlights", label: "Book Highlights" },
    { to: "/discussions", label: "Discussions" },
    ...(!isAdmin ? [{ to: "/lists", label: "Reading Lists" }] : []),
  ];
  const communityActive = communityLinks.some((l) =>
    location.pathname.startsWith(l.to)
  );

  const isActive = (path: string) =>
    location.pathname === path ||
    (path === "/books" && location.pathname.startsWith("/books/"));

  function handleSearch() {
    setMobileMenuOpen(false);
    navigate(`/books?q=${encodeURIComponent(search.trim())}`);
  }

  const activeLinkClass =
    "text-white font-bold border-cyan-400";

  const inactiveLinkClass =
    "text-white/80 font-medium border-transparent hover:text-white";

  // Every top-level item (links and the Community button) shares one box model,
  // so text and underline line up exactly on the same baseline.
  const navItemBase =
    "block text-[15px] leading-6 pb-1.5 border-b-2 transition-colors";

  const linkClass = (path: string) =>
    `${navItemBase} ${isActive(path) ? activeLinkClass : inactiveLinkClass}`;

  const closeMobileMenu = () => setMobileMenuOpen(false);

  return (
    <nav className="app-navbar relative sticky top-0 z-40 flex h-[66px] items-center justify-between bg-gradient-to-r from-navy-800 to-blue-600 px-4 sm:px-7">
      {/* LEFT SIDE */}
      <div className="flex items-center gap-5 lg:gap-9">
        {/* LOGO */}
        <Link
          to={isAdmin ? "/dashboard" : "/"}
          className="flex items-center gap-2 font-heading text-xl font-extrabold text-white"
        >
          <BookIcon size={22} />
          Openshelf
        </Link>

        {/* DESKTOP NAVIGATION */}
        <ul className="hidden items-center gap-5 lg:flex xl:gap-7">
          {!isAdmin && (
            <li>
              <Link to="/" className={linkClass("/")}>
                Home
              </Link>
            </li>
          )}

          {isAdmin ? (
            <>
              <li>
                <Link to="/dashboard" className={linkClass("/dashboard")}>
                  Dashboard
                </Link>
              </li>

              <li>
                <Link to="/users" className={linkClass("/users")}>
                  Users
                </Link>
              </li>

              <li>
                <Link to="/books" className={linkClass("/books")}>
                  Books
                </Link>
              </li>
            </>
          ) : (
            <>
              <li>
                <Link to="/books" className={linkClass("/books")}>
                  Books
                </Link>
              </li>

              <li>
                <Link to="/dashboard" className={linkClass("/dashboard")}>
                  Dashboard
                </Link>
              </li>
            </>
          )}

          <li
            className="relative"
            onMouseLeave={() => setCommunityOpen(false)}
          >
            <button
              type="button"
              aria-haspopup="menu"
              aria-expanded={communityOpen}
              onClick={() => setCommunityOpen((open) => !open)}
              className={`${navItemBase} flex items-center gap-1.5 bg-transparent ${
                communityActive ? activeLinkClass : inactiveLinkClass
              }`}
            >
              Community
              <svg
                width="10"
                height="10"
                viewBox="0 0 10 10"
                aria-hidden="true"
                className={`transition-transform ${communityOpen ? "rotate-180" : ""}`}
              >
                <path d="M1.5 3.5 5 7l3.5-3.5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>

            {communityOpen && (
              // The outer wrapper's top padding keeps the pointer inside the <li>
              // while it moves from the button to the menu, so the menu stays open.
              <div className="absolute left-0 top-full z-50 pt-2">
                <div
                  role="menu"
                  className="min-w-[190px] rounded-xl border border-line bg-card p-1.5 shadow-xl"
                >
                  {communityLinks.map((l) => (
                    <Link
                      key={l.to}
                      to={l.to}
                      role="menuitem"
                      onClick={() => setCommunityOpen(false)}
                      className="block rounded-lg px-3 py-2.5 text-[13.5px] font-semibold text-ink-900 hover:bg-surface"
                    >
                      {l.label}
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </li>
        </ul>
      </div>

      {/* RIGHT SIDE */}
      <div className="flex items-center gap-2 sm:gap-3.5">
        {/* MOBILE MENU BUTTON */}
        <button
          type="button"
          className="mobile-nav-toggle flex rounded-xl border px-3 py-2 text-sm font-bold lg:hidden"
          aria-expanded={mobileMenuOpen}
          aria-label={mobileMenuOpen ? "Close navigation" : "Open navigation"}
          onClick={() => setMobileMenuOpen((open) => !open)}
        >
          {mobileMenuOpen ? "✕" : "☰"}
        </button>

        {/* SEARCH */}
        <div className="hidden w-44 items-center rounded-full bg-card py-1 pl-4 pr-1 sm:flex xl:w-56">
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") handleSearch();
            }}
            type="text"
            placeholder="Search books..."
            aria-label="Search books"
            className="min-w-0 flex-1 border-none bg-transparent text-sm outline-none"
          />

          <button
            type="button"
            onClick={handleSearch}
            aria-label="Search"
            className="nav-search-btn flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 transition-all hover:from-cyan-300 hover:to-blue-400 active:scale-95"
          >
            <SearchIcon size={17} />
          </button>
        </div>

        {/* THEME TOGGLE */}
        <ThemeToggle />

        {/* NOTIFICATIONS */}
        <NotificationBell />

        {/* PROFILE MENU */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Open profile menu"
            aria-expanded={menuOpen}
            className="flex h-[38px] w-[38px] items-center justify-center rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 text-[15px] font-extrabold text-white transition-all hover:from-cyan-300 hover:to-blue-400"
          >
            {user?.name?.[0]?.toUpperCase() || "?"}
          </button>

          {menuOpen && (
            <div
              role="menu"
              className="absolute right-0 top-12 z-50 min-w-[150px] rounded-xl border border-line bg-card p-1.5 shadow-xl"
              onMouseLeave={() => setMenuOpen(false)}
            >
              <Link
                to="/account"
                role="menuitem"
                onClick={() => setMenuOpen(false)}
                className="block w-full rounded-lg px-3 py-2.5 text-left text-[13.5px] font-semibold text-ink-900 hover:bg-surface"
              >
                My Account
              </Link>

              <button
                type="button"
                onClick={async () => {
                  setMenuOpen(false);
                  const ok = await confirm({
                    title: "Log out?",
                    message: "You will need to sign in again to continue.",
                    confirmLabel: "Logout",
                    cancelLabel: "Stay signed in",
                  });
                  if (!ok) return;
                  logout();
                  navigate("/login");
                }}
                className="block w-full rounded-lg px-3 py-2.5 text-left text-[13.5px] font-semibold text-danger hover:bg-surface"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </div>

      {/* MOBILE NAVIGATION */}
      {mobileMenuOpen && (
        <div className="mobile-nav-menu absolute left-0 right-0 top-full z-50 lg:hidden">
          {/* MOBILE SEARCH */}
          <div className="mobile-search flex items-center gap-2">
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") handleSearch();
              }}
              placeholder="Search books..."
              aria-label="Search books"
            />

            <button
              type="button"
              onClick={handleSearch}
              aria-label="Submit search"
              className="nav-search-btn flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950"
            >
              <SearchIcon size={18} />
            </button>
          </div>

          {!isAdmin && (
            <Link
              to="/"
              onClick={closeMobileMenu}
              className={isActive("/") ? "active" : ""}
            >
              Home
            </Link>
          )}

          {isAdmin ? (
            <>
              <Link
                to="/dashboard"
                onClick={closeMobileMenu}
                className={isActive("/dashboard") ? "active" : ""}
              >
                Dashboard
              </Link>

              <Link
                to="/users"
                onClick={closeMobileMenu}
                className={isActive("/users") ? "active" : ""}
              >
                Users
              </Link>

              <Link
                to="/books"
                onClick={closeMobileMenu}
                className={isActive("/books") ? "active" : ""}
              >
                Books
              </Link>
            </>
          ) : (
            <>
              <Link
                to="/books"
                onClick={closeMobileMenu}
                className={isActive("/books") ? "active" : ""}
              >
                Books
              </Link>

              <Link
                to="/dashboard"
                onClick={closeMobileMenu}
                className={isActive("/dashboard") ? "active" : ""}
              >
                Dashboard
              </Link>
            </>
          )}

          {communityLinks.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              onClick={closeMobileMenu}
              className={location.pathname.startsWith(l.to) ? "active" : ""}
            >
              {l.label}
            </Link>
          ))}

          <Link
            to="/account"
            onClick={closeMobileMenu}
            className={isActive("/account") ? "active" : ""}
          >
            My Account
          </Link>
        </div>
      )}
    </nav>
  );
}
