import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { NotificationItem } from "../types";
import { timeAgo } from "../utils/timeAgo";
import { emitNotificationsChanged, onNotificationsChanged } from "../utils/notificationEvents";
import { NotificationRowSkeletons } from "./BookSkeletons";
import { BellIcon } from "./icons";

const POLL_MS = 60_000;
// The menu shows only the latest few; the rest live on the Notifications page.
const MENU_LIMIT = 5;

export default function NotificationBell() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unread, setUnread] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get<{
        unread: number;
        items: NotificationItem[];
        hasMore: boolean;
      }>("/notifications", { params: { limit: MENU_LIMIT } });
      setItems(data.items.slice(0, MENU_LIMIT));
      setUnread(data.unread);
      setHasMore(Boolean(data.hasMore));
    } catch {
      /* silent: the bell simply keeps its last state */
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") void load();
    }, POLL_MS);
    return () => window.clearInterval(timer);
  }, [load]);

  // The Notifications page changed something (read / cleared): refresh the bell.
  useEffect(() => onNotificationsChanged(() => void load()), [load]);

  // Close when clicking outside
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  async function toggle() {
    const next = !open;
    setOpen(next);
    if (next) await load();
  }

  async function markAll() {
    await api.post("/notifications/read-all");
    setItems((all) => all.map((n) => ({ ...n, read: true })));
    setUnread(0);
    emitNotificationsChanged();
  }

  async function clearAll() {
    await api.delete("/notifications");
    setItems([]);
    setUnread(0);
    setHasMore(false);
    emitNotificationsChanged();
  }

  async function openItem(n: NotificationItem) {
    setOpen(false);
    if (!n.read) {
      setItems((all) => all.map((x) => (x._id === n._id ? { ...x, read: true } : x)));
      setUnread((u) => Math.max(0, u - 1));
      void api
        .post(`/notifications/${n._id}/read`)
        .then(() => emitNotificationsChanged())
        .catch(() => undefined);
    }
    if (n.link) navigate(n.link);
  }

  return (
    <div className="relative" ref={wrapRef}>
      <button
        type="button"
        onClick={() => void toggle()}
        aria-label={unread ? `Notifications, ${unread} unread` : "Notifications"}
        aria-expanded={open}
        className="relative flex h-[38px] w-[38px] items-center justify-center rounded-full border border-white/20 text-[17px] text-white hover:bg-white/10"
      >
        <BellIcon />
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-danger px-1 text-[10.5px] font-bold text-white">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-12 z-50 w-[320px] max-w-[88vw] rounded-xl border border-line bg-card shadow-xl">
          <div className="flex items-center justify-between border-b border-line px-4 py-2.5">
            <span className="font-heading text-[14px] font-bold text-ink-900">Notifications</span>
            <div className="flex gap-3 text-[12px] font-semibold">
              {unread > 0 && (
                <button type="button" onClick={() => void markAll()} className="text-blue-500">
                  Mark all read
                </button>
              )}
              {items.length > 0 && (
                <button type="button" onClick={() => void clearAll()} className="text-ink-600">
                  Clear
                </button>
              )}
            </div>
          </div>

          {!loaded ? (
            <NotificationRowSkeletons count={MENU_LIMIT} />
          ) : items.length === 0 ? (
            <p className="m-0 px-4 py-6 text-center text-[13px] text-ink-600">
              You&apos;re all caught up.
            </p>
          ) : (
            <ul className="m-0 list-none p-0">
              {items.map((n) => (
                <li key={n._id}>
                  <button
                    type="button"
                    onClick={() => void openItem(n)}
                    className={`block w-full border-b border-line px-4 py-3 text-left last:border-b-0 hover:bg-surface ${
                      n.read ? "" : "bg-primary/5"
                    }`}
                  >
                    <span className="block text-[13px] leading-snug text-ink-900">
                      {!n.read && (
                        <span className="mr-1.5 inline-block h-2 w-2 rounded-full bg-cyan-400" aria-hidden="true" />
                      )}
                      {n.message}
                    </span>
                    <span className="mt-1 block text-[11.5px] text-ink-600">{timeAgo(n.createdAt)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}

          {loaded && items.length > 0 && (
            <div className="border-t border-line px-4 py-2.5 text-center">
              <Link
                to="/notifications"
                onClick={() => setOpen(false)}
                className="text-[13px] font-semibold text-blue-500"
              >
                {hasMore ? "View more" : "Open notifications page"}
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
