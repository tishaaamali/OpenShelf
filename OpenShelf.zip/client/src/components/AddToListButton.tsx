import { FormEvent, useState } from "react";
import api from "../api/axios";
import { ListMembership } from "../types";
import { RowSkeletons } from "./BookSkeletons";

// "Add to list" button on a book page. Opens a small dialog listing the
// member's reading lists with checkboxes, plus a quick "create new list" form.
export default function AddToListButton({
  bookId,
  onMessage,
}: {
  bookId: string;
  onMessage: (message: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [lists, setLists] = useState<ListMembership[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [newName, setNewName] = useState("");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");

  async function openDialog() {
    setOpen(true);
    setError("");
    setLoading(true);
    try {
      const { data } = await api.get<ListMembership[]>(`/lists/containing/${bookId}`);
      setLists(data);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not load your lists.");
    } finally {
      setLoading(false);
    }
  }

  async function toggle(list: ListMembership) {
    try {
      setBusyId(list._id);
      if (list.hasBook) {
        await api.delete(`/lists/${list._id}/books/${bookId}`);
      } else {
        await api.post(`/lists/${list._id}/books`, { bookId });
      }
      setLists((all) =>
        all.map((l) => (l._id === list._id ? { ...l, hasBook: !l.hasBook } : l))
      );
      onMessage(list.hasBook ? `Removed from "${list.name}"` : `Added to "${list.name}"`);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not update the list.");
    } finally {
      setBusyId(null);
    }
  }

  async function createList(event: FormEvent) {
    event.preventDefault();
    if (newName.trim().length < 2) return setError("List name needs at least 2 characters.");
    try {
      setCreating(true);
      setError("");
      const { data } = await api.post("/lists", { name: newName, bookId });
      setLists((all) => [
        { _id: data._id, name: data.name, isPublic: data.isPublic, bookCount: data.bookCount, hasBook: true },
        ...all,
      ]);
      setNewName("");
      onMessage(`Added to "${data.name}"`);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not create the list.");
    } finally {
      setCreating(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => void openDialog()}
        className="rounded-full border border-line px-3.5 py-1 text-[13px] font-semibold text-ink-600 hover:border-line-strong"
      >
        Add to list
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-5"
          onClick={() => setOpen(false)}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="add-list-title"
            onClick={(e) => e.stopPropagation()}
            className="modal-panel w-full max-w-[400px] rounded-2xl border border-line p-6 shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <h2 id="add-list-title" className="mb-3 font-heading text-lg font-bold">
              Add to a reading list
            </h2>

            {loading ? (
              <RowSkeletons count={2} />
            ) : lists.length === 0 ? (
              <p className="mb-3 text-sm text-ink-600">
                You don&apos;t have any lists yet — create your first one below.
              </p>
            ) : (
              <ul className="m-0 mb-3 max-h-[220px] list-none space-y-1 overflow-y-auto p-0">
                {lists.map((l) => (
                  <li key={l._id}>
                    <label className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2 hover:bg-surface">
                      <input
                        type="checkbox"
                        checked={l.hasBook}
                        disabled={busyId === l._id}
                        onChange={() => void toggle(l)}
                      />
                      <span className="flex-1 text-[14px] font-semibold">{l.name}</span>
                      <span className="text-[11.5px] text-ink-600">
                        {l.isPublic ? "Public" : "Private"} · {l.bookCount}
                      </span>
                    </label>
                  </li>
                ))}
              </ul>
            )}

            <form onSubmit={createList} className="flex gap-2">
              <input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                maxLength={60}
                placeholder="New list name…"
                aria-label="New list name"
                className="min-w-0 flex-1 rounded-xl border border-line-strong bg-field px-3 py-2 text-[14px] outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                disabled={creating}
                className="rounded-xl bg-primary px-4 py-2 text-[13px] font-bold text-white disabled:opacity-50"
              >
                Create
              </button>
            </form>

            {error && (
              <p className="mt-2 text-[13px] text-danger" role="alert">
                {error}
              </p>
            )}

            <div className="mt-4 flex justify-end">
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-full border border-line px-5 py-2 text-sm font-semibold"
              >
                Done
              </button>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
