import { ReactNode, useState } from "react";
import { Link } from "react-router-dom";

import api from "../api/axios";
import { Book } from "../types";
import BookCover from "./BookCover";
import { BookRowSkeletons } from "./BookSkeletons";
import { useInfiniteList } from "../hooks/useInfiniteList";

// Shared, progressively loaded layout for the Most Borrowed / Top Rated pages.
const BATCH = 10;
const MAX_BOOKS = 25;

interface Props {
  endpoint: string;
  // Extra query params sent with each paginated request
  params?: Record<string, string | number | boolean>;
  eyebrow: string;
  title: string;
  subtitle: string;
  emptyTitle: string;
  emptyText: string;
  errorTitle: string;
  // Optional client-side filter (e.g. hide books nobody has borrowed yet)
  keep?: (book: Book) => boolean;
  // The right-hand stat shown on every row
  renderStat: (book: Book) => ReactNode;
  // Optional expandable area under each row (e.g. reviews). `patch` lets it
  // update the row's book after a change (e.g. a new average rating).
  renderDetails?: (
    book: Book,
    patch: (changes: Partial<Book>) => void
  ) => ReactNode;
  detailsLabel?: string;
}

export default function RankedBooksPage({
  endpoint,
  params,
  eyebrow,
  title,
  subtitle,
  emptyTitle,
  emptyText,
  errorTitle,
  keep,
  renderStat,
  renderDetails,
  detailsLabel = "details",
}: Props) {
  const [openIds, setOpenIds] = useState<string[]>([]);
  const resetKey = JSON.stringify([endpoint, params || {}]);
  const list = useInfiniteList<Book>(async (page) => {
    const offset = (page - 1) * BATCH;
    const limit = Math.min(BATCH, MAX_BOOKS - offset);
    if (limit <= 0) return { items: [], hasMore: false };

    const { data } = await api.get<Book[]>(endpoint, {
      params: { ...params, limit, offset },
    });
    const rows = Array.isArray(data) ? data.slice(0, limit) : [];
    return {
      items: keep ? rows.filter(keep) : rows,
      // Never fetch or display more than the first 25 ranked books.
      hasMore: rows.length === limit && offset + rows.length < MAX_BOOKS,
    };
  }, resetKey);
  const books = list.items;
  const loading = list.initialLoading;
  const error = list.error?.message || "";

  function load() {
    list.retry();
  }

  function patchBook(id: string, changes: Partial<Book>) {
    list.mapItems((book) => (book._id === id ? { ...book, ...changes } : book));
  }

  function toggleOpen(id: string) {
    setOpenIds((current) =>
      current.includes(id)
        ? current.filter((x) => x !== id)
        : [...current, id]
    );
  }

  return (
    <div className="library-page ranked-books-page">
      <nav
        aria-label="Breadcrumb"
        className="mb-4 flex flex-wrap items-center gap-2 text-[13px] text-ink-600"
      >
        <Link
          to="/dashboard"
          className="font-semibold text-blue-500 hover:underline"
        >
          ← Back to Dashboard
        </Link>
        <span aria-hidden="true">/</span>
        <span aria-current="page">{title}</span>
      </nav>

      <div className="library-page-heading mb-6">
        <div className="library-eyebrow">{eyebrow}</div>

        <h1 className="m-0 mb-1.5 font-heading text-2xl font-bold">{title}</h1>

        <p className="m-0 text-[14.5px] text-ink-600">
          {loading || error
            ? subtitle
            : `${subtitle} · ${books.length} ${
                books.length === 1 ? "book" : "books"
              }`}
        </p>
      </div>

      {error && (
        <div className="library-feedback library-error" role="alert">
          <strong>{errorTitle}</strong>
          <span>{error}</span>
          <button type="button" onClick={() => void load()}>
            Try again
          </button>
        </div>
      )}

      {loading && (
        <div className="space-y-4" aria-busy="true">
          <BookRowSkeletons count={8} />
        </div>
      )}

      {!loading && !error && books.length === 0 && (
        <div className="library-empty-state py-16 text-center text-ink-600">
          <span>✧</span>
          <strong>{emptyTitle}</strong>
          <p>{emptyText}</p>
        </div>
      )}

      {!loading && !error && books.length > 0 && (
        <ol className="m-0 list-none space-y-4 p-0">
          {books.map((book, index) => (
            <li key={book._id}>
              <div
                className={`rounded-2xl border border-line bg-card ${
                  renderDetails
                    ? "transition-colors hover:border-[rgba(125,211,252,.35)]"
                    : "books-admin-row"
                }`}
              >
                <Link
                  to={`/books/${book._id}`}
                  className="flex w-full items-center gap-3 p-4 text-left sm:gap-5 sm:p-5"
                >
                  <span
                    className={`flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-full text-[12px] font-extrabold ${
                      index < 3
                        ? "bg-gold-500 text-[#2A1B00]"
                        : "bg-surface text-ink-600"
                    }`}
                    aria-label={`Rank ${index + 1}`}
                  >
                    {index + 1}
                  </span>

                  <BookCover
                    book={book}
                    index={index}
                    className="h-24 w-16 shrink-0 rounded-lg text-base sm:h-28 sm:w-20"
                  />

                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-base font-semibold text-ink-900 sm:text-lg">
                      {book.title}
                    </span>

                    <span className="mt-1 block truncate text-sm text-ink-600 sm:text-base">
                      {book.author}
                    </span>
                  </span>

                  <span className="shrink-0 text-right">{renderStat(book)}</span>
                </Link>

                {renderDetails && (
                  <div className="border-t border-line px-4 pb-4 pt-3 sm:px-5">
                    <button
                      type="button"
                      onClick={() => toggleOpen(book._id)}
                      aria-expanded={openIds.includes(book._id)}
                      className="text-[13px] font-semibold text-blue-500 hover:underline"
                    >
                      {openIds.includes(book._id)
                        ? `Hide ${detailsLabel} ▴`
                        : `View ${detailsLabel} ▾`}
                    </button>

                    {openIds.includes(book._id) && (
                      <div className="mt-3">
                        {renderDetails(book, (changes) =>
                          patchBook(book._id, changes)
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </li>
          ))}
        </ol>
      )}

      {list.loadingMore && <div className="mt-4 space-y-4" aria-busy="true"><BookRowSkeletons count={4} /></div>}
      {list.error && books.length > 0 && (
        <div className="library-feedback library-error mt-4" role="alert">
          <span>{list.error.message}</span>
          <button type="button" onClick={list.retry}>Retry</button>
        </div>
      )}
      <div ref={list.sentinelRef} aria-hidden="true" style={{ height: 1 }} />
      {!list.hasMore && !list.error && books.length > 0 && (
        <p className="mb-0 mt-6 text-center text-[13px] text-ink-600" role="status">
          You have reached the end of this list.
        </p>
      )}
    </div>
  );
}
