import { useCallback, useEffect, useState } from "react";
import { ReviewRowSkeletons } from "./BookSkeletons";

import api from "../api/axios";

export interface BookReview {
  _id: string;
  userName: string;
  mine: boolean;
  rating: number;
  review: string;
  createdAt: string;
}

interface Props {
  bookId: string;
  // Admins can edit and delete any member's rating and review.
  isAdmin: boolean;
  // Called with the book's new average after an admin edit / delete.
  onStatsChange?: (stats: { rating: number; ratingCount: number }) => void;
}

// Ratings and reviews of one book. Everyone signed in can read them;
// only admins get Edit / Delete.
export default function BookReviewsPanel({
  bookId,
  isAdmin,
  onStatsChange,
}: Props) {
  const [reviews, setReviews] = useState<BookReview[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftRating, setDraftRating] = useState(0);
  const [draftReview, setDraftReview] = useState("");
  const [savingId, setSavingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const { data } = await api.get<BookReview[]>(`/books/${bookId}/reviews`);
      setReviews(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(
        err?.response?.data?.message ||
          "Could not load reviews. Check your connection and try again."
      );
    } finally {
      setLoading(false);
    }
  }, [bookId]);

  useEffect(() => {
    void load();
  }, [load]);

  function startEdit(item: BookReview) {
    setNotice("");
    setConfirmDeleteId(null);
    setEditingId(item._id);
    setDraftRating(item.rating);
    setDraftReview(item.review);
  }

  function cancelEdit() {
    setEditingId(null);
    setDraftRating(0);
    setDraftReview("");
  }

  async function saveEdit(item: BookReview) {
    if (draftRating < 1) {
      setNotice("Select a rating from 1 to 5.");
      return;
    }

    setSavingId(item._id);
    setNotice("");

    try {
      const { data } = await api.put(
        `/books/${bookId}/ratings/${item._id}`,
        { rating: draftRating, review: draftReview.trim() }
      );

      setReviews((current) =>
        current.map((r) =>
          r._id === item._id
            ? { ...r, rating: draftRating, review: draftReview.trim() }
            : r
        )
      );
      onStatsChange?.({
        rating: data.averageRating,
        ratingCount: data.ratingCount,
      });
      cancelEdit();
      setNotice("Review updated.");
    } catch (err: any) {
      setNotice(err?.response?.data?.message || "Could not update this review.");
    } finally {
      setSavingId(null);
    }
  }

  async function confirmDelete(item: BookReview) {
    setDeletingId(item._id);
    setNotice("");

    try {
      const { data } = await api.delete(
        `/books/${bookId}/ratings/${item._id}`
      );

      setReviews((current) => current.filter((r) => r._id !== item._id));
      onStatsChange?.({
        rating: data.averageRating,
        ratingCount: data.ratingCount,
      });
      setConfirmDeleteId(null);
      setNotice("Review deleted.");
    } catch (err: any) {
      setNotice(err?.response?.data?.message || "Could not delete this review.");
    } finally {
      setDeletingId(null);
    }
  }

  if (loading) {
    return <ReviewRowSkeletons count={2} />;
  }

  if (error) {
    return (
      <div className="text-[13.5px] text-danger" role="alert">
        <p className="m-0">{error}</p>
        <button
          type="button"
          onClick={() => void load()}
          className="font-semibold underline"
        >
          Try again
        </button>
      </div>
    );
  }

  return (
    <div>
      {notice && (
        <p className="m-0 mb-3 text-[13px] text-ink-600" role="status">
          {notice}
        </p>
      )}

      {reviews.length === 0 ? (
        <p className="m-0 text-[13.5px] text-ink-600">
          No reviews for this book yet.
        </p>
      ) : (
        <ul className="m-0 list-none space-y-3 p-0">
          {reviews.map((item) => {
            const editing = editingId === item._id;
            const saving = savingId === item._id;
            const confirming = confirmDeleteId === item._id;
            const deleting = deletingId === item._id;

            return (
              <li
                key={item._id}
                className="rounded-xl border border-line bg-surface p-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0 text-[13px] text-ink-600">
                    <span className="font-semibold text-ink-900">
                      {item.userName}
                    </span>
                    {item.mine && (
                      <span className="ml-2 rounded-full bg-primary px-2 py-0.5 text-[10.5px] font-bold text-white">
                        You
                      </span>
                    )}
                    <span> · {new Date(item.createdAt).toLocaleDateString()}</span>
                  </div>

                  {!editing && (
                    <span
                      className="whitespace-nowrap text-gold-500"
                      aria-label={`${item.rating} out of 5`}
                    >
                      {"★".repeat(item.rating)}
                      {"☆".repeat(5 - item.rating)}
                    </span>
                  )}
                </div>

                {editing ? (
                  <div className="mt-3">
                    <div
                      className="mb-3 flex gap-1.5"
                      role="radiogroup"
                      aria-label="Rating"
                    >
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          role="radio"
                          aria-checked={star === draftRating}
                          aria-label={`${star} star${star > 1 ? "s" : ""}`}
                          onClick={() => setDraftRating(star)}
                          className={`text-3xl leading-none ${
                            star <= draftRating
                              ? "text-gold-500"
                              : "text-ink-600"
                          }`}
                        >
                          {star <= draftRating ? "★" : "☆"}
                        </button>
                      ))}
                    </div>

                    <textarea
                      value={draftReview}
                      onChange={(event) => setDraftReview(event.target.value)}
                      maxLength={500}
                      rows={3}
                      placeholder="Review text (optional)"
                      aria-label="Review text"
                      className="w-full resize-none rounded-lg border border-line bg-field p-3 text-[13.5px] outline-none focus:border-blue-500"
                    />

                    <div className="mt-1 text-right text-[11.5px] text-ink-600">
                      {draftReview.length}/500
                    </div>

                    <div className="mt-3 flex gap-2.5">
                      <button
                        type="button"
                        onClick={() => void saveEdit(item)}
                        disabled={saving || draftRating === 0}
                        className="rounded-lg bg-primary px-5 py-2 text-[13px] font-bold text-white disabled:opacity-50"
                      >
                        {saving ? "Saving..." : "Save changes"}
                      </button>

                      <button
                        type="button"
                        onClick={cancelEdit}
                        disabled={saving}
                        className="rounded-lg border border-line px-5 py-2 text-[13px] font-semibold"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    {item.review ? (
                      <p className="mb-0 mt-2 whitespace-pre-wrap break-words text-[13.5px] leading-relaxed text-ink-600">
                        “{item.review}”
                      </p>
                    ) : (
                      <p className="mb-0 mt-2 text-[13px] italic text-ink-600">
                        No written review.
                      </p>
                    )}

                    {isAdmin && (
                      <div className="mt-3 flex flex-wrap items-center gap-2.5">
                        {confirming ? (
                          <>
                            <span className="text-[13px] text-ink-600">
                              Delete this rating and review?
                            </span>

                            <button
                              type="button"
                              onClick={() => void confirmDelete(item)}
                              disabled={deleting}
                              className="rounded-lg bg-danger px-4 py-1.5 text-[12.5px] font-bold text-white disabled:opacity-50"
                            >
                              {deleting ? "Deleting..." : "Yes, delete"}
                            </button>

                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              disabled={deleting}
                              className="rounded-lg border border-line px-4 py-1.5 text-[12.5px] font-semibold"
                            >
                              Keep it
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={() => startEdit(item)}
                              className="rounded-lg border border-line px-4 py-1.5 text-[12.5px] font-semibold hover:border-blue-500 hover:text-blue-500"
                            >
                              Edit
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                setNotice("");
                                setConfirmDeleteId(item._id);
                              }}
                              className="rounded-lg border border-line px-4 py-1.5 text-[12.5px] font-semibold text-danger hover:border-danger"
                            >
                              Delete
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
