import { useNavigate } from "react-router-dom";
import { Book } from "../types";
import BookCover from "./BookCover";

const GRADIENTS = [
  "linear-gradient(135deg,#2454D6,#16215C)",
  "linear-gradient(135deg,#F5A623,#DE8E0E)",
  "linear-gradient(135deg,#2FA86A,#16215C)",
  "linear-gradient(135deg,#E5484D,#16215C)",
  "linear-gradient(135deg,#3B6FE0,#0B1230)",
  "linear-gradient(135deg,#DE8E0E,#2454D6)",
];

export function gradientFor(index: number) {
  return GRADIENTS[index % GRADIENTS.length];
}

export function initialsFor(title: string) {
  return title.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();
}

interface Props {
  book: Book;
  index: number;
  onPreview: (book: Book) => void;
  badgeOverride?: { text: string; className: string };
}

export default function BookCard({ book, index, onPreview, badgeOverride }: Props) {
  const navigate = useNavigate();

  const badge = badgeOverride || {
    text: book.status === "Available" ? "● Available" : "● Borrowed",
    className: book.status === "Available" ? "badge-available" : "badge-borrowed",
  };

  return (
    <div
      onClick={() => navigate(`/books/${book._id}`)}
      className="book-card bg-card border border-line rounded-2xl p-4 cursor-pointer flex flex-col gap-3 transition-transform duration-300 ease-out hover:scale-[1.015]"
    >
      <BookCover book={book} index={index} className="h-[205px] rounded-xl text-3xl" />
      <span className={`badge w-fit ${badge.className}`}>{badge.text}</span>
      <h4 className="text-base leading-snug font-semibold m-0">{book.title}</h4>
      <p className="text-sm text-ink-600 m-0">{book.author}</p>
      <p className="text-xs text-ink-600 m-0">{book.category} · {book.format}</p>
      <button
        onClick={(e) => {
          e.stopPropagation();
          onPreview(book);
        }}
        className="self-start border border-line rounded-lg px-3 py-2 text-xs font-semibold text-ink-600 hover:border-blue-500 hover:text-blue-500"
      >
        Preview
      </button>
    </div>
  );
}
