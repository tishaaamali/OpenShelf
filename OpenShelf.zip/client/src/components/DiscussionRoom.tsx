import { FormEvent, useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { DiscussionThread } from "../types";
import { timeAgo } from "../utils/timeAgo";
import { RowSkeletons } from "./BookSkeletons";

// The discussion room shown at the bottom of a book's page:
// a list of conversation threads plus a "start a discussion" form.
export default function DiscussionRoom({
  bookId,
  isAdmin,
}: {
  bookId: string;
  isAdmin: boolean;
}) {
  const [threads, setThreads] = useState<DiscussionThread[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [composing, setComposing] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [spoiler, setSpoiler] = useState(false);
  const [posting, setPosting] = useState(false);
  const [formError, setFormError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const { data } = await api.get<DiscussionThread[]>(`/books/${bookId}/discussions`);
      setThreads(data);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not load discussions.");
    } finally {
      setLoading(false);
    }
  }, [bookId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setFormError("");
    if (title.trim().length < 3) return setFormError("Give your discussion a title (at least 3 characters).");
    if (body.trim().length < 3) return setFormError("Write a few words to get the conversation going.");

    try {
      setPosting(true);
      await api.post(`/books/${bookId}/discussions`, { title, body, spoiler });
      setTitle("");
      setBody("");
      setSpoiler(false);
      setComposing(false);
      await load();
    } catch (err: any) {
      setFormError(err?.response?.data?.message || "Could not start the discussion.");
    } finally {
      setPosting(false);
    }
  }

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="m-0 text-[13px] text-ink-600">
          Chat with other readers about plot, themes, characters — anything.
        </p>
        {!composing && !isAdmin && (
          <button
            type="button"
            onClick={() => setComposing(true)}
            className="rounded-full bg-primary px-4 py-2 text-[13px] font-bold text-white"
          >
            + Start a discussion
          </button>
        )}
      </div>

      {composing && (
        <form
          onSubmit={submit}
          className="mb-5 rounded-2xl border border-line bg-card p-4"
        >
          <label className="mb-1 block text-[13px] font-semibold" htmlFor="disc-title">
            Topic
          </label>
          <input
            id="disc-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={120}
            placeholder="e.g. What did you make of the ending?"
            className="mb-3 w-full rounded-xl border border-line-strong bg-field px-4 py-2.5 text-[14px] outline-none focus:border-blue-500"
          />

          <label className="mb-1 block text-[13px] font-semibold" htmlFor="disc-body">
            Your thoughts
          </label>
          <textarea
            id="disc-body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            maxLength={2000}
            rows={4}
            placeholder="Share your take or ask the room a question…"
            className="w-full resize-none rounded-xl border border-line-strong bg-field px-4 py-3 text-[14px] outline-none focus:border-blue-500"
          />
          <div className="mt-1 text-right text-[11px] text-ink-600">{body.length}/2000</div>

          <label className="mt-1 flex items-center gap-2 text-[13px]">
            <input
              type="checkbox"
              checked={spoiler}
              onChange={(e) => setSpoiler(e.target.checked)}
            />
            This post contains spoilers
          </label>

          {formError && (
            <p className="mt-2 text-[13px] text-danger" role="alert">
              {formError}
            </p>
          )}

          <div className="mt-4 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => {
                setComposing(false);
                setFormError("");
              }}
              className="rounded-full border border-line px-4 py-2 text-[13px] font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={posting}
              className="rounded-full bg-primary px-5 py-2 text-[13px] font-bold text-white disabled:opacity-50"
            >
              {posting ? "Posting…" : "Post"}
            </button>
          </div>
        </form>
      )}

      {error ? (
        <p className="text-[13.5px] text-danger" role="alert">
          {error}
        </p>
      ) : loading ? (
        <RowSkeletons count={2} />
      ) : threads.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line-strong p-6 text-center text-[14px] text-ink-600">
          No discussions yet.{" "}
          {!isAdmin && "Be the first to start one!"}
        </div>
      ) : (
        <ul className="m-0 list-none space-y-2.5 p-0">
          {threads.map((t) => (
            <li key={t._id}>
              <Link
                to={`/discussions/${t._id}`}
                className="block rounded-xl border border-line bg-card p-3.5 transition-colors hover:border-line-strong"
              >
                <div className="flex flex-wrap items-center gap-2">
                  {t.pinned && (
                    <span className="rounded-full bg-gold-500/20 px-2 py-0.5 text-[11px] font-bold text-gold-500">
                      Pinned
                    </span>
                  )}
                  {t.locked && (
                    <span className="rounded-full bg-surface px-2 py-0.5 text-[11px] font-bold text-ink-600">
                      Locked
                    </span>
                  )}
                  {t.spoiler && (
                    <span className="rounded-full bg-danger-bg px-2 py-0.5 text-[11px] font-bold text-danger">
                      Spoilers
                    </span>
                  )}
                  <span className="font-heading text-[14.5px] font-bold text-ink-900">
                    {t.title}
                  </span>
                </div>
                <div className="mt-1.5 text-[12px] text-ink-600">
                  {t.userName} · {timeAgo(t.createdAt)} · {t.replyCount} {t.replyCount === 1 ? "reply" : "replies"} · {t.upvoteCount} {t.upvoteCount === 1 ? "upvote" : "upvotes"}
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
