import { useEffect, useState } from "react";
import api from "../api/axios";
import { useConfirm } from "../context/ConfirmContext";
import { useInfiniteList } from "../hooks/useInfiniteList";
import { QuoteItem, QuotePage } from "../types";
import { onQuoteLike } from "../utils/quoteEvents";
import { QuoteCardSkeletons } from "./BookSkeletons";
import QuoteCard from "./QuoteCard";

const BATCH = 10;

interface Props {
  // "highlights" = every quote (filtered); "saved" = the user's own collection;
  // "book" = the highlights of one book (needs bookId).
  mode: "highlights" | "saved" | "book";
  bookId?: string;
  hideBook?: boolean;
  params?: { q?: string; sort?: "new" | "top"; kind?: string };
  isAdmin: boolean;
  empty: React.ReactNode;
}

// Progressive, server-paginated list of quote cards, shared by Book Highlights
// and the full Words Worth Keeping page: 10 quotes per batch, skeletons while
// loading, retry on failure, and an end-of-list message.
export default function QuoteFeed({ mode, bookId, hideBook = false, params = {}, isAdmin, empty }: Props) {
  const confirm = useConfirm();
  const [toast, setToast] = useState("");
  const saved = mode === "saved";
  const resetKey = JSON.stringify([mode, bookId || "", params.q || "", params.sort || "new", params.kind || ""]);

  const list = useInfiniteList<QuoteItem>(async (page, { removed }) => {
    // Rows removed since the list started shift every later row up by one, so the
    // next batch starts at (rows already loaded) rather than at a fixed page boundary.
    const offset = Math.max(0, (page - 1) * BATCH - removed);
    const { data } = saved
      ? await api.get<QuotePage>("/quotes/saved", { params: { limit: BATCH, offset } })
      : mode === "book"
        ? await api.get<QuotePage>(`/books/${bookId}/quotes`, { params: { limit: BATCH, offset } })
        : await api.get<QuotePage>("/quotes", {
            params: {
              limit: BATCH,
              offset,
              sort: params.sort || "new",
              q: params.q || undefined,
              kind: params.kind || undefined,
            },
          });
    return { items: data.quotes, hasMore: data.hasMore, total: data.total };
  }, resetKey);

  const { items, updateItem, removeItem, mapItems } = list;

  // Keep this list in step with likes made elsewhere on the same screen.
  useEffect(
    () =>
      onQuoteLike(({ quoteId, liked, likeCount }) => {
        if (saved && !liked) removeItem(quoteId);
        else mapItems((q) => (q._id === quoteId ? { ...q, liked, likeCount } : q));
      }),
    [saved, removeItem, mapItems]
  );

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  }

  function handleChange(updated: QuoteItem) {
    // Availability of a book is shared by all its quotes.
    mapItems((q) =>
      q._id === updated._id
        ? updated
        : q.book && updated.book && q.book._id === updated.book._id
          ? { ...q, book: updated.book }
          : q
    );
    if (saved && !updated.liked) removeItem(updated._id);
  }

  async function handleDelete(quote: QuoteItem) {
    if (
      !(await confirm({
        title: "Delete this quote?",
        message: "This removes it for everyone and cannot be undone.",
        confirmLabel: "Delete",
      }))
    )
      return;
    try {
      await api.delete(`/quotes/${quote._id}`);
      removeItem(quote._id);
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not delete the quote");
    }
  }

  if (list.initialLoading) {
    return (
      <div className="highlight-grid" aria-busy="true" aria-label="Loading quotes">
        <QuoteCardSkeletons count={6} noCover={hideBook} />
      </div>
    );
  }

  if (list.error && items.length === 0) {
    return (
      <div className="library-feedback library-error" role="alert">
        <strong>Could not load quotes</strong>
        <span>{list.error.message}</span>
        <button type="button" onClick={list.retry}>
          Try again
        </button>
      </div>
    );
  }

  if (items.length === 0) {
    return <div className="library-empty-state p-8 text-center text-ink-600">{empty}</div>;
  }

  return (
    <>
      <div className="highlight-grid">
        {items.map((quote) => (
          <QuoteCard
            key={quote._id}
            quote={quote}
            isAdmin={isAdmin}
            variant={saved ? "saved" : "default"}
            hideBook={hideBook}
            onChange={handleChange}
            onDelete={saved ? undefined : handleDelete}
            onMessage={showToast}
          />
        ))}
        {list.loadingMore && <QuoteCardSkeletons count={3} noCover={hideBook} />}
      </div>

      {list.error && (
        <div className="library-feedback library-error mt-4" role="alert">
          <strong>Could not load more quotes</strong>
          <span>{list.error.message}</span>
          <button type="button" onClick={list.retry}>
            Try again
          </button>
        </div>
      )}

      {/* Scroll sentinel: loads the next batch shortly before it is reached. */}
      <div ref={list.sentinelRef} aria-hidden="true" style={{ height: 1 }} />

      {!list.hasMore && !list.error && (
        <p className="mb-0 mt-6 text-center text-[13px] text-ink-600" role="status">
          {saved
            ? "That is everything you have saved."
            : mode === "book"
              ? "That is every highlight from this book."
              : "You have reached the end of Book Highlights."}
        </p>
      )}

      {toast && (
        <div
          role="status"
          className="fixed bottom-6 left-1/2 z-[100] max-w-[90vw] -translate-x-1/2 rounded-full bg-primary px-6 py-3 text-center text-sm font-semibold text-white shadow-xl"
        >
          {toast}
        </div>
      )}
    </>
  );
}
