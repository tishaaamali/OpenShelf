import { useState } from "react";

// Text hidden behind a blur until the reader chooses to reveal it.
export default function SpoilerText({
  text,
  spoiler,
  className = "",
}: {
  text: string;
  spoiler: boolean;
  className?: string;
}) {
  const [revealed, setRevealed] = useState(false);

  if (!spoiler || revealed) {
    return <p className={`whitespace-pre-wrap break-words ${className}`}>{text}</p>;
  }

  return (
    <button
      type="button"
      onClick={() => setRevealed(true)}
      className="relative block w-full overflow-hidden rounded-lg border border-dashed border-line-strong bg-surface p-3 text-left"
      aria-label="Spoiler hidden. Click to reveal."
    >
      <span
        aria-hidden="true"
        className={`block select-none whitespace-pre-wrap break-words blur-sm ${className}`}
      >
        {text}
      </span>
      <span className="absolute inset-0 flex items-center justify-center text-[12.5px] font-bold text-ink-900">
        Contains spoilers. Click to reveal
      </span>
    </button>
  );
}
