import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { QuoteItem, QuotePage } from "../types";
import { onQuoteLike } from "../utils/quoteEvents";
import { QuoteCardSkeletons } from "./BookSkeletons";
import BookCover from "./BookCover";

const PREVIEW_COUNT = 4;

// "Words Worth Keeping" on the My Account page: at most 4 of the quotes the
// user has liked in Book Highlights, plus a link to the full collection.
export default function WordsWorthKeeping() {
  const [quotes, setQuotes] = useState<QuoteItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const { data } = await api.get<QuotePage>("/quotes/saved", {
        params: { page: 1, limit: PREVIEW_COUNT },
      });
      setQuotes(data.quotes.slice(0, PREVIEW_COUNT)); // never more than 4
      setTotal(data.total);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not load your saved quotes.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // A quote liked or removed elsewhere on this screen refreshes the preview.
  useEffect(() => onQuoteLike(() => void load()), [load]);

  return (
    <section
      className="mt-6 min-w-0 rounded-2xl border border-line bg-card p-6"
      aria-labelledby="wwk-heading"
    >
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h3 id="wwk-heading" className="m-0 font-heading text-[15.5px] font-bold">
          Words Worth Keeping
          {!loading && !error && total > 0 && (
            <span className="ml-2 text-[12.5px] font-normal text-ink-600">{total} saved</span>
          )}
        </h3>
        {!loading && !error && total > 0 && (
          <Link to="/account/words-worth-keeping" className="text-[13px] font-semibold text-blue-500">
            View More
          </Link>
        )}
      </div>

      {loading ? (
        <div className="wwk-grid" aria-busy="true" aria-label="Loading saved quotes">
          <QuoteCardSkeletons count={PREVIEW_COUNT} compact />
        </div>
      ) : error ? (
        <div className="library-feedback library-error" role="alert">
          <strong>Could not load your quotes</strong>
          <span>{error}</span>
          <button type="button" onClick={() => void load()}>
            Try again
          </button>
        </div>
      ) : quotes.length === 0 ? (
        <p className="m-0 text-[13.5px] text-ink-600">
          You have not saved any quotes yet. Like a quote in{" "}
          <Link to="/highlights" className="font-semibold text-blue-500">
            Book Highlights
          </Link>{" "}
          and it will be kept here.
        </p>
      ) : (
        <div className="wwk-grid">
          {quotes.map((quote) => (
            <figure key={quote._id} className="highlight-card highlight-card-compact m-0">
              <blockquote className="highlight-quote font-heading highlight-text-sm wwk-clamp">
                <span className="highlight-mark" aria-hidden="true">“</span>
                {quote.text}
              </blockquote>
              <figcaption className="highlight-caption">
                {quote.book && (
                  <Link to={`/books/${quote.book._id}`} className="highlight-cover" aria-label={`Open ${quote.book.title}`}>
                    <BookCover book={quote.book} className="h-[68px] w-[46px] rounded-md text-xs" />
                  </Link>
                )}
                <div className="min-w-0">
                  {quote.author && <div className="highlight-author">{quote.author}</div>}
                  {(quote.sourceTitle || quote.book) && (
                    <div className="highlight-source">
                      {quote.book ? (
                        <Link to={`/books/${quote.book._id}`}>{quote.sourceTitle || quote.book.title}</Link>
                      ) : (
                        <span>{quote.sourceTitle}</span>
                      )}
                    </div>
                  )}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      )}
    </section>
  );
}
