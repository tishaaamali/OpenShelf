import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useConfirm } from "../context/ConfirmContext";
import { useInfiniteList } from "../hooks/useInfiniteList";
import { NotificationItem } from "../types";
import { timeAgo } from "../utils/timeAgo";
import { emitNotificationsChanged, onNotificationsChanged } from "../utils/notificationEvents";
import { NotificationRowSkeletons } from "../components/BookSkeletons";

const BATCH = 10;

interface NotificationPage {
  unread: number;
  items: NotificationItem[];
  total: number;
  hasMore: boolean;
}

// Reached from "View more" in the bell menu: every notification, 10 at a time.
export default function Notifications() {
  const confirm = useConfirm();
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);
  const [version, setVersion] = useState(0); // bumped to reload from the top
  const ownChange = useRef(false);

  // Tell the bell about a change made here without reloading this page's list.
  function announce() {
    ownChange.current = true;
    emitNotificationsChanged();
    ownChange.current = false;
  }

  const list = useInfiniteList<NotificationItem>(async (page) => {
    const { data } = await api.get<NotificationPage>("/notifications", {
      params: { limit: BATCH, offset: (page - 1) * BATCH },
    });
    setUnread(data.unread);
    return { items: data.items, hasMore: data.hasMore, total: data.total };
  }, String(version));

  const { items, mapItems } = list;

  // Something changed in the bell menu: start over so both stay identical.
  useEffect(
    () =>
      onNotificationsChanged(() => {
        if (!ownChange.current) setVersion((v) => v + 1);
      }),
    []
  );

  async function markAll() {
    await api.post("/notifications/read-all");
    mapItems((n) => ({ ...n, read: true }));
    setUnread(0);
    announce();
  }

  async function clearAll() {
    if (
      !(await confirm({
        title: "Clear all notifications?",
        message: "Every notification will be removed from your list.",
        confirmLabel: "Clear all",
      }))
    )
      return;
    await api.delete("/notifications");
    setUnread(0);
    setVersion((v) => v + 1);
    announce();
  }

  async function openItem(n: NotificationItem) {
    if (!n.read) {
      mapItems((x) => (x._id === n._id ? { ...x, read: true } : x));
      setUnread((u) => Math.max(0, u - 1));
      void api
        .post(`/notifications/${n._id}/read`)
        .then(announce)
        .catch(() => undefined);
    }
    if (n.link) navigate(n.link);
  }

  return (
    <div className="library-page mx-auto max-w-3xl">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="m-0 mb-1.5 font-heading text-2xl font-bold">Notifications</h1>
          <p className="m-0 text-[14px] text-ink-600">
            {list.initialLoading
              ? "\u00a0"
              : list.total
                ? `${list.total} in total${unread ? ` · ${unread} unread` : ""}`
                : "Nothing here yet"}
            {" · "}
            <Link to="/" className="text-blue-500 hover:underline">
              Back to home
            </Link>
          </p>
        </div>

        {items.length > 0 && (
          <div className="flex gap-3 text-[13px] font-semibold">
            {unread > 0 && (
              <button type="button" onClick={() => void markAll()} className="text-blue-500">
                Mark all read
              </button>
            )}
            <button type="button" onClick={() => void clearAll()} className="text-ink-600">
              Clear all
            </button>
          </div>
        )}
      </div>

      {list.initialLoading ? (
        <NotificationRowSkeletons count={8} framed />
      ) : list.error && items.length === 0 ? (
        <div className="library-feedback library-error" role="alert">
          <strong>Could not load notifications</strong>
          <span>{list.error.message}</span>
          <button type="button" onClick={list.retry}>
            Try again
          </button>
        </div>
      ) : items.length === 0 ? (
        <div className="library-empty-state py-16 text-center text-ink-600">
          <span>✧</span>
          <strong>You&apos;re all caught up</strong>
          <p>New activity on your books and requests will appear here.</p>
        </div>
      ) : (
        <>
          <ul className="m-0 list-none overflow-hidden rounded-2xl border border-line bg-card p-0">
            {items.map((n) => (
              <li key={n._id}>
                <button
                  type="button"
                  onClick={() => void openItem(n)}
                  className={`block w-full border-b border-line px-5 py-4 text-left last:border-b-0 hover:bg-surface ${
                    n.read ? "" : "bg-primary/5"
                  }`}
                >
                  <span className="block text-[14px] leading-snug text-ink-900">
                    {!n.read && (
                      <span
                        className="mr-2 inline-block h-2 w-2 rounded-full bg-cyan-400"
                        aria-label="Unread"
                      />
                    )}
                    {n.message}
                  </span>
                  <span className="mt-1 block text-[12px] text-ink-600">{timeAgo(n.createdAt)}</span>
                </button>
              </li>
            ))}
          </ul>

          {list.loadingMore && (
            <div className="mt-3">
              <NotificationRowSkeletons count={3} framed />
            </div>
          )}

          {list.error && (
            <div className="library-feedback library-error mt-4" role="alert">
              <strong>Could not load more notifications</strong>
              <span>{list.error.message}</span>
              <button type="button" onClick={list.retry}>
                Try again
              </button>
            </div>
          )}

          <div ref={list.sentinelRef} aria-hidden="true" style={{ height: 1 }} />

          {!list.hasMore && !list.error && items.length > BATCH && (
            <p className="mb-0 mt-6 text-center text-[13px] text-ink-600" role="status">
              That is every notification.
            </p>
          )}
        </>
      )}
    </div>
  );
}
