
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import BookCover from "../components/BookCover";
import ScanIssuePanel from "../components/ScanIssuePanel";
import { DashboardLayoutSkeleton } from "../components/BookSkeletons";
import {
  Book,
  ActivityItem,
  DueSoonItem,
} from "../types";

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.role === "admin";

  const [popular, setPopular] = useState<Book[]>([]);
  const [topRated, setTopRated] = useState<Book[]>([]);
  const [activity, setActivity] = useState<ActivityItem[]>([]);
  const [arrivals, setArrivals] = useState<Book[]>([]);
  const [dueSoon, setDueSoon] = useState<DueSoonItem[]>([]);
  const [arrivalIndex, setArrivalIndex] = useState(0);
  const [toast, setToast] = useState("");
  const [loadError, setLoadError] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoadError("");
    setLoading(true);

    // Only what the dashboard shows is requested - never the whole library.
    const requests: Promise<any>[] = [
      api.get("/books/stats/popular", { params: { limit: 6 } }),
      api.get("/books/stats/top-rated", { params: { limit: 5 } }),
      api.get("/activity"),
    ];

    if (isAdmin) {
      requests.push(
        api.get("/books/stats/arrivals"),
        api.get("/books/stats/due-soon")
      );
    } else {
      // Members see their own loans that are overdue or due within 3 days.
      requests.push(api.get("/account/me"));
    }

    try {
      const results = await Promise.all(requests);

      setPopular(results[0].data);
      setTopRated(results[1].data);
      setActivity(results[2].data);

      if (isAdmin) {
        setArrivals(results[3].data);
        setDueSoon(results[4].data);
      } else {
        const mine: DueSoonItem[] = (results[3].data?.borrowed ?? [])
          .filter((loan: any) => loan.dueDate)
          .map((loan: any) => ({
            bookId: loan.bookId,
            title: loan.title,
            author: loan.author,
            coverImage: loan.coverImage,
            isbn13: loan.isbn13,
            isbn10: loan.isbn10,
            borrowerName: "You",
            dueDate: loan.dueDate,
            daysUntil: Math.ceil(
              (new Date(loan.dueDate).getTime() - Date.now()) / 86400000
            ),
          }))
          .sort((a: DueSoonItem, b: DueSoonItem) => a.daysUntil - b.daysUntil);

        setDueSoon(mine);
      }
    } catch (err: any) {
      setLoadError(
        err?.response?.data?.message ||
          "Could not load the dashboard. Check your connection and try again."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!isAdmin || arrivals.length === 0) return;

    const timer = setInterval(() => {
      setArrivalIndex((i) => (i + 1) % arrivals.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [isAdmin, arrivals]);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(""), 3000);
  }

  async function sendReminders() {
    try {
      const { data } = await api.post(
        "/activity/send-overdue-reminders"
      );

      showToast(data.message);
      await load();
    } catch (err: any) {
      showToast(
        err?.response?.data?.message ||
          "Could not send overdue reminders"
      );
    }
  }

  if (loading) {
    return <DashboardLayoutSkeleton isAdmin={isAdmin} />;
  }

  if (loadError) {
    return (
      <div className="library-feedback" role="alert">
        <strong>Dashboard unavailable</strong>
        <span>{loadError}</span>
        <button type="button" onClick={load}>
          Try again
        </button>
      </div>
    );
  }

  const currentArrival = arrivals[arrivalIndex];

  return (
    <div className="library-page dashboard-page">
      {/* HEADER */}
      <div className="mb-6">
        <div className="library-eyebrow">
          LIBRARY INSIGHTS
        </div>

        <h1 className="text-2xl font-heading font-bold m-0 mb-1.5">
          Dashboard
        </h1>

        <p className="text-ink-600 text-[14.5px] m-0">
          Library overview at a glance
        </p>
      </div>

      {/* UPCOMING DUE DATES */}
      <div className="mt-6">
        <Panel
          title="Upcoming Due Dates"
          badge={isAdmin ? "admin view" : undefined}
        >
          {dueSoon.length === 0 ? (
            <div className="due-empty">
              <strong>
                {isAdmin ? "Nothing due soon" : "No borrowed books right now"}
              </strong>
              <span>
                {isAdmin
                  ? "No loans are due in the next few days."
                  : "When you borrow a book, its due date will show up here."}
              </span>
              {!isAdmin && (
                <button type="button" onClick={() => navigate("/books")}>
                  Browse books
                </button>
              )}
            </div>
          ) : (
            <ul className="due-list">
              {dueSoon.slice(0, isAdmin ? 5 : 8).map((item, i) => {
                const overdue = item.daysUntil < 0;
                const label = overdue
                  ? `${Math.abs(item.daysUntil)} day${
                      Math.abs(item.daysUntil) === 1 ? "" : "s"
                    } overdue`
                  : item.daysUntil === 0
                  ? "Due today"
                  : `${item.daysUntil} day${
                      item.daysUntil === 1 ? "" : "s"
                    } left`;
                return (
                  <li
                    key={`${item.bookId}-${i}`}
                    className={`due-item ${overdue ? "due-item-overdue" : ""}`}
                  >
                    <button
                      type="button"
                      className="due-item-link"
                      onClick={() => navigate(`/books/${item.bookId}`)}
                    >
                      <BookCover
                        book={{
                          title: item.title,
                          isbn13: item.isbn13 || "",
                          isbn10: item.isbn10 || "",
                          coverImage: item.coverImage,
                        }}
                        index={i}
                        className="due-cover"
                      />
                      <span className="due-meta">
                        <span className="due-title">{item.title}</span>
                        <span className="due-date">
                          {isAdmin ? `${item.borrowerName} · ` : ""}
                          Due{" "}
                          {new Date(item.dueDate).toLocaleDateString(
                            undefined,
                            { day: "numeric", month: "short", year: "numeric" }
                          )}
                        </span>
                      </span>
                      <span
                        className={`badge ${
                          overdue ? "badge-damaged" : "badge-borrowed"
                        }`}
                      >
                        {label}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>
      </div>

      {/* ROW 1: QUICK ACTIONS + SCAN & ISSUE REQUEST (admin) */}
      {isAdmin && (
        <div className="grid grid-cols-2 gap-6 mt-6 max-md:grid-cols-1">
          <Panel title="Quick Actions">
            <p className="mb-4 mt-0 text-[13.5px] leading-relaxed text-ink-600">
              Add a new title, or remind members with overdue books.
            </p>

            <div className="quick-actions-row">
              <button
                type="button"
                onClick={sendReminders}
                className="quick-action-btn border border-line rounded-lg py-3 font-semibold text-sm"
              >
                Send Overdue Reminders
              </button>

              <button
                type="button"
                onClick={() => navigate("/books/add")}
                className="quick-action-btn bg-primary text-white rounded-lg py-3 font-bold text-sm"
              >
                + Add Book
              </button>
            </div>
          </Panel>

          <Panel title="Scan & Issue Request" badge="admin only">
            <ScanIssuePanel />
          </Panel>
        </div>
      )}

      {/* ROW 2: MOST BORROWED + TOP RATED */}
      <div className="grid grid-cols-2 gap-6 mt-6 max-md:grid-cols-1">
        <Panel
          title="Most Borrowed Books"
          onViewAll={() => navigate("/dashboard/most-borrowed")}
        >
          {popular.length === 0 ? (
            <p className="text-ink-600 text-[13.5px]">
              No borrowing activity yet.
            </p>
          ) : (
            popular.map((book, i) => (
              <RowItem
                key={book._id}
                title={
                  <span className="flex items-center gap-3">
                    <span
                      className={`w-[22px] h-[22px] rounded-full text-[11px] font-extrabold flex items-center justify-center flex-shrink-0 ${
                        i < 3
                          ? "bg-gold-500 text-[#2A1B00]"
                          : "bg-surface text-ink-600"
                      }`}
                    >
                      {i + 1}
                    </span>

                    {book.title}
                  </span>
                }
                subtitle={book.author}
                right={
                  <div className="text-right">
                    <div className="font-semibold text-[13.5px]">
                      {book.borrowCount}
                    </div>

                    <div className="text-[12px] text-ink-600">
                      borrows
                    </div>
                  </div>
                }
              />
            ))
          )}
        </Panel>

        <Panel
          title="Top Rated Books"
          onViewAll={() => navigate("/dashboard/top-rated")}
        >
          {topRated.length === 0 ? (
            <p className="text-ink-600 text-[13.5px]">
              No ratings available yet.
            </p>
          ) : (
            topRated.map((book, i) => (
              <div
                key={book._id}
                className="flex items-center justify-between py-2.5 border-b border-line last:border-none gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span
                    className={`w-[22px] h-[22px] rounded-full text-[11px] font-extrabold flex items-center justify-center flex-shrink-0 ${
                      i < 3
                        ? "bg-gold-500 text-[#2A1B00]"
                        : "bg-surface text-ink-600"
                    }`}
                  >
                    {i + 1}
                  </span>

                  <div className="min-w-0">
                    <div className="font-semibold text-[13.5px] truncate">
                      {book.title}
                    </div>

                    <div className="text-[12px] text-ink-600 truncate">
                      {book.author}
                    </div>
                  </div>
                </div>

                <div className="text-right flex-shrink-0">
                  <div className="font-bold text-[13.5px]">
                    {book.rating.toFixed(1)} / 5
                  </div>

                  <div className="text-[12px] text-ink-600">
                    {book.ratingCount} ratings
                  </div>
                </div>
              </div>
            ))
          )}
        </Panel>
      </div>

      {/* ROW 3: RECENT ACTIVITY + NEW ARRIVALS */}
      <div
        className={`grid ${
          isAdmin ? "grid-cols-2" : "grid-cols-1"
        } gap-6 mt-6 max-md:grid-cols-1`}
      >
        <Panel title="Recent Activity">
          {activity.length === 0 ? (
            <p className="text-ink-600 text-[13.5px]">
              No activity yet.
            </p>
          ) : (
            activity.map((item) => (
              <RowItem
                key={item._id}
                title={item.message}
                right={
                  <span className="text-[12px] text-ink-600">
                    {new Date(
                      item.createdAt
                    ).toLocaleDateString()}
                  </span>
                }
              />
            ))
          )}
        </Panel>

        {isAdmin && (
          <Panel title="New Arrivals" badge="admin review">
            {currentArrival ? (
              <div>
                <div className="flex gap-3.5 items-center mb-3.5">
                  <BookCover
                    book={currentArrival}
                    className="w-[60px] h-[82px] rounded-lg flex-shrink-0 text-sm"
                  />

                  <div className="min-w-0">
                    <span className="badge badge-available mb-1.5">
                      NEW
                    </span>

                    <div className="font-semibold text-sm truncate max-w-[210px]">
                      {currentArrival.title}
                    </div>

                    <div className="text-[12px] text-ink-600">
                      {currentArrival.author} · added{" "}
                      {new Date(
                        currentArrival.addedDate
                      ).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <button
                    type="button"
                    onClick={() =>
                      navigate(`/books/${currentArrival._id}`)
                    }
                    className="bg-primary text-white rounded-lg px-4 py-1.5 text-[12.5px] font-semibold"
                  >
                    Review
                  </button>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      aria-label="Previous arrival"
                      onClick={() =>
                        setArrivalIndex(
                          (i) =>
                            (i - 1 + arrivals.length) %
                            arrivals.length
                        )
                      }
                      className="w-8 h-8 rounded-full border border-line"
                    >
                      ‹
                    </button>

                    <button
                      type="button"
                      aria-label="Next arrival"
                      onClick={() =>
                        setArrivalIndex(
                          (i) => (i + 1) % arrivals.length
                        )
                      }
                      className="w-8 h-8 rounded-full border border-line"
                    >
                      ›
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-ink-600 text-[13.5px]">
                No arrivals yet.
              </p>
            )}
          </Panel>
        )}
      </div>

      {/* TOAST */}
      {toast && (
        <div
          role="status"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-primary text-white px-6 py-3 rounded-full text-sm font-semibold shadow-xl"
        >
          {toast}
        </div>
      )}
    </div>
  );
}

function Panel({
  title,
  badge,
  onViewAll,
  children,
}: {
  title: string;
  badge?: string;
  onViewAll?: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="dashboard-panel bg-card border border-line rounded-2xl p-6">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h3 className="m-0 text-base font-heading font-bold">
          {title}{" "}
          {badge && (
            <span className="text-[11px] text-ink-600 font-medium">
              ({badge})
            </span>
          )}
        </h3>
        {onViewAll && (
          <button type="button" onClick={onViewAll} className="shrink-0 text-sm font-semibold text-blue-500 hover:underline">
            View More →
          </button>
        )}
      </div>

      {children}
    </div>
  );
}

function RowItem({
  title,
  subtitle,
  right,
}: {
  title: React.ReactNode;
  subtitle?: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-2.5 border-b border-line last:border-none text-[13.5px] gap-3">
      <div className="min-w-0">
        <div className="font-semibold">{title}</div>

        {subtitle && (
          <div className="text-[12px] text-ink-600 mt-0.5">
            {subtitle}
          </div>
        )}
      </div>

      {right}
    </div>
  );
}
