import { useRef, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";

const CATEGORIES = [
  "Fiction", "Non-Fiction", "Science", "Fantasy",
  "Biography", "Self-Help", "Technology", "History",
];

const LANGUAGES = ["English", "Hindi", "Gujarati", "Spanish"];
const FORMATS = ["Hardcover", "Paperback", "eBook", "Audio Book"];

const INITIAL_FORM = {
  title: "",
  isbn: "",
  author: "",
  category: "",
  language: "",
  publisher: "",
  edition: "",
  year: "",
  format: "",
  numberOfCopies: "1",
  shelf: "",
  status: "Available",
  description: "",
};

const inputClass =
  "w-full rounded-lg border border-line bg-surface px-3 py-2.5 text-[13.5px] outline-none focus:border-blue-500";

const labelClass =
  "mb-1.5 block text-[12.5px] font-semibold text-ink-600";

export default function AddBookPage() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState(INITIAL_FORM);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [coverPreview, setCoverPreview] = useState("");
  const [error, setError] = useState("");
  // Field-level messages shown right below the field they belong to.
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  function clearFieldError(key: string) {
    setErrors((current) => {
      if (!current[key]) return current;
      const next = { ...current };
      delete next[key];
      return next;
    });
  }

  function update(key: keyof typeof INITIAL_FORM, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
    clearFieldError(key);
  }

  function updateISBN(value: string) {
    setForm((current) => ({ ...current, isbn: value.replace(/\D/g, "").slice(0, 13) }));
    clearFieldError("isbn");
  }

  function handleCoverChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrors((current) => ({ ...current, cover: "Please select an image file (JPG, PNG or WebP)." }));
      event.target.value = "";
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrors((current) => ({ ...current, cover: "The cover image must be 5 MB or smaller." }));
      event.target.value = "";
      return;
    }

    setError("");
    clearFieldError("cover");
    setCoverFile(file);

    setCoverPreview((previous) => {
      if (previous) URL.revokeObjectURL(previous);
      return URL.createObjectURL(file);
    });
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");

    const found: Record<string, string> = {};
    const required: [keyof typeof INITIAL_FORM, string][] = [
      ["title", "Enter the book title."],
      ["isbn", "Enter the ISBN number."],
      ["author", "Enter the author's name."],
      ["category", "Choose a category."],
      ["language", "Choose a language."],
      ["format", "Choose a book format."],
      ["numberOfCopies", "Enter the number of copies."],
      ["shelf", "Enter the shelf or rack."],
      ["status", "Choose a status."],
    ];
    for (const [key, message] of required) {
      if (!String(form[key] ?? "").trim()) found[key] = message;
    }

    if (!found.isbn && !/^\d{10}$|^\d{13}$/.test(form.isbn)) {
      found.isbn = "Enter an ISBN with exactly 10 or 13 digits.";
    }

    const copies = Number(form.numberOfCopies);
    if (!found.numberOfCopies && (!Number.isInteger(copies) || copies < 1)) {
      found.numberOfCopies = "Number of copies must be a whole number of at least 1.";
    }

    if (form.year) {
      const year = Number(form.year);
      if (!Number.isInteger(year) || year < 1 || year > 9999) {
        found.year = "Enter a valid publication year.";
      }
    }

    if (errors.cover) found.cover = errors.cover;

    setErrors(found);
    if (Object.keys(found).length > 0) {
      const firstKey = Object.keys(found)[0];
      const idFor: Record<string, string> = { numberOfCopies: "book-copies", cover: "book-cover" };
      document.getElementById(idFor[firstKey] || `book-${firstKey}`)?.focus();
      return;
    }

    try {
      setSaving(true);

      const coverImage = coverFile
        ? await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = () => reject(new Error("Could not read the cover image."));
            reader.readAsDataURL(coverFile);
          })
        : "";

      await api.post("/books", {
        ...form,
        isbn13: form.isbn.length === 13 ? form.isbn : "",
        isbn10: form.isbn.length === 10 ? form.isbn : "",
        numberOfCopies: String(copies),
        coverImage,
      });

      if (coverPreview) URL.revokeObjectURL(coverPreview);

      navigate("/books", {
        replace: true,
        state: { message: "Book added successfully." },
      });
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { message?: string } } })
          ?.response?.data?.message;

      // Messages about the ISBN belong under the ISBN field, everything else stays on top.
      if (message && /isbn/i.test(message)) {
        setErrors((current) => ({ ...current, isbn: message }));
      } else {
        setError(message || "Failed to add book. Please try again.");
      }
    } finally {
      setSaving(false);
    }
  }

  function cancel() {
    if (coverPreview) URL.revokeObjectURL(coverPreview);
    navigate("/books");
  }

  return (
    <div className="library-page mx-auto max-w-4xl">
      <div className="library-page-heading mb-6">
        <button
          type="button"
          onClick={cancel}
          className="mb-4 text-sm font-semibold text-ink-600 transition hover:text-primary"
        >
          ← Back to Books
        </button>

        <div className="library-eyebrow">THE COLLECTION</div>
        <h1 className="m-0 mb-2 font-heading text-2xl font-bold">
          Add Book
        </h1>

        <p className="m-0 text-sm text-ink-600">
          Add a new title to the OpenShelf collection. Book IDs,
          barcodes and QR codes can be generated automatically by the server.
        </p>
      </div>

      {error && (
        <div
          role="alert"
          className="mb-5 rounded-xl border border-danger bg-danger-bg px-4 py-3 text-sm text-danger"
        >
          {error}
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        noValidate
        className="rounded-2xl border border-line bg-card p-5 shadow-sm sm:p-8"
      >
        <div className="mb-7">
          <h2 className="mb-1 font-heading text-lg font-bold text-ink-900">
            Book Cover
          </h2>
          <p className="mb-4 text-sm text-ink-600">
            Upload an image for this book. JPG, PNG or WebP, up to 5 MB.
          </p>

          <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center">
            <div className="flex h-48 w-36 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-line bg-surface">
              {coverPreview ? (
                <img
                  src={coverPreview}
                  alt="Preview of the selected book cover"
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="px-3 text-center text-sm text-ink-600">
                  <svg
                    viewBox="0 0 24 24"
                    width="34"
                    height="34"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    className="mx-auto mb-2"
                    aria-hidden="true"
                  >
                    <rect x="4" y="3" width="16" height="18" rx="2" />
                    <path d="M8 8h8M8 12h8M8 16h5" />
                  </svg>
                  No cover selected
                </div>
              )}
            </div>

            <div>
              <input
                id="book-cover"
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleCoverChange}
                className="cover-file-input"
                aria-label="Upload book cover image"
              />

              {errors.cover && (
                <p role="alert" className="mt-2 text-xs font-semibold text-danger">
                  {errors.cover}
                </p>
              )}

              {coverFile && (
                <p className="mt-2 break-all text-xs text-ink-600">
                  {coverFile.name} · {(coverFile.size / 1024).toFixed(0)} KB
                </p>
              )}

              {coverFile && (
                <button
                  type="button"
                  onClick={() => {
                    if (coverPreview) URL.revokeObjectURL(coverPreview);
                    setCoverPreview("");
                    setCoverFile(null);
                    if (fileInputRef.current) {
                      fileInputRef.current.value = "";
                    }
                  }}
                  className="mt-3 text-sm font-semibold text-danger hover:underline"
                >
                  Remove cover
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label htmlFor="book-title" className={labelClass}>
              Book Title *
            </label>
            <input
              id="book-title"
              required
              maxLength={200}
              className={`${inputClass} ${errors.title ? "!border-danger" : ""}`}
              value={form.title}
              onChange={(event) => update("title", event.target.value)}
              placeholder="e.g. The Alchemist"
            />
            {errors.title && (
              <p id="error-title" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.title}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-isbn" className={labelClass}>
              ISBN Number *
            </label>
            <input
              id="book-isbn"
              required
              inputMode="numeric"
              maxLength={13}
              pattern="(?:\d{10}|\d{13})"
              className={`${inputClass} ${errors.isbn ? "!border-danger" : ""}`}
              value={form.isbn}
              onChange={(event) => updateISBN(event.target.value)}
              placeholder="10 or 13 digits"
            />
            <p className="mt-1 text-xs text-ink-600">
              Enter exactly 10 or 13 digits.
            </p>
            {errors.isbn && (
              <p id="error-isbn" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.isbn}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-author" className={labelClass}>
              Author(s) *
            </label>
            <input
              id="book-author"
              required
              className={`${inputClass} ${errors.author ? "!border-danger" : ""}`}
              value={form.author}
              onChange={(event) => update("author", event.target.value)}
              placeholder="Paulo Coelho"
            />
            {errors.author && (
              <p id="error-author" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.author}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-category" className={labelClass}>
              Category *
            </label>
            <select
              id="book-category"
              required
              className={`${inputClass} ${errors.category ? "!border-danger" : ""}`}
              value={form.category}
              onChange={(event) => update("category", event.target.value)}
            >
              <option value="">Select...</option>
              {CATEGORIES.map((category) => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
            {errors.category && (
              <p id="error-category" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.category}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-language" className={labelClass}>
              Language *
            </label>
            <select
              id="book-language"
              required
              className={`${inputClass} ${errors.language ? "!border-danger" : ""}`}
              value={form.language}
              onChange={(event) => update("language", event.target.value)}
            >
              <option value="">Select...</option>
              {LANGUAGES.map((language) => (
                <option key={language} value={language}>{language}</option>
              ))}
            </select>
            {errors.language && (
              <p id="error-language" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.language}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-publisher" className={labelClass}>
              Publisher
            </label>
            <input
              id="book-publisher"
              className={`${inputClass} ${errors.publisher ? "!border-danger" : ""}`}
              value={form.publisher}
              onChange={(event) => update("publisher", event.target.value)}
              placeholder="HarperCollins"
            />
            {errors.publisher && (
              <p id="error-publisher" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.publisher}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-edition" className={labelClass}>
              Edition
            </label>
            <input
              id="book-edition"
              className={`${inputClass} ${errors.edition ? "!border-danger" : ""}`}
              value={form.edition}
              onChange={(event) => update("edition", event.target.value)}
              placeholder="2nd Edition"
            />
            {errors.edition && (
              <p id="error-edition" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.edition}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-year" className={labelClass}>
              Publication Year
            </label>
            <input
              id="book-year"
              type="number"
              min="1"
              max="9999"
              step="1"
              className={`${inputClass} ${errors.year ? "!border-danger" : ""}`}
              value={form.year}
              onChange={(event) => update("year", event.target.value)}
              placeholder="2024"
            />
            {errors.year && (
              <p id="error-year" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.year}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-format" className={labelClass}>
              Book Format *
            </label>
            <select
              id="book-format"
              required
              className={`${inputClass} ${errors.format ? "!border-danger" : ""}`}
              value={form.format}
              onChange={(event) => update("format", event.target.value)}
            >
              <option value="">Select...</option>
              {FORMATS.map((format) => (
                <option key={format} value={format}>{format}</option>
              ))}
            </select>
            {errors.format && (
              <p id="error-format" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.format}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-copies" className={labelClass}>
              Number of Copies *
            </label>
            <input
              id="book-copies"
              required
              type="number"
              min="1"
              step="1"
              className={`${inputClass} ${errors.numberOfCopies ? "!border-danger" : ""}`}
              value={form.numberOfCopies}
              onChange={(event) => update("numberOfCopies", event.target.value)}
            />
            {errors.numberOfCopies && (
              <p id="error-copies" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.numberOfCopies}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-shelf" className={labelClass}>
              Shelf / Rack *
            </label>
            <input
              id="book-shelf"
              required
              className={`${inputClass} ${errors.shelf ? "!border-danger" : ""}`}
              value={form.shelf}
              onChange={(event) => update("shelf", event.target.value)}
              placeholder="A-12"
            />
            {errors.shelf && (
              <p id="error-shelf" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.shelf}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="book-status" className={labelClass}>
              Status *
            </label>
            <select
              id="book-status"
              required
              className={`${inputClass} ${errors.status ? "!border-danger" : ""}`}
              value={form.status}
              onChange={(event) => update("status", event.target.value)}
            >
              <option>Available</option>
              <option>Unavailable</option>
              <option>Under Maintenance</option>
            </select>
            {errors.status && (
              <p id="error-status" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.status}
              </p>
            )}
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="book-description" className={labelClass}>
              Description
            </label>
            <textarea
              id="book-description"
              rows={3}
              className={`${inputClass} resize-y`}
              value={form.description}
              onChange={(event) => update("description", event.target.value)}
              placeholder="Short summary of the book..."
            />
            {errors.description && (
              <p id="error-description" role="alert" className="mt-1.5 text-xs font-semibold text-danger">
                {errors.description}
              </p>
            )}
          </div>
        </div>

        <div className="mt-6 rounded-lg bg-surface p-3 text-[12.5px] text-ink-600">
          Auto-generated on save: Book ID, Accession Number, Barcode(s), QR Code and Created Date.
        </div>

        <div className="mt-6 flex flex-wrap justify-end gap-3">
          <button
            type="button"
            onClick={cancel}
            disabled={saving}
            className="rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-ink-900 transition hover:bg-surface disabled:opacity-60"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={saving}
            className="rounded-full bg-gold-500 px-6 py-2.5 text-sm font-bold text-[#2A1B00] transition hover:bg-gold-600 disabled:opacity-60"
          >
            {saving ? "Saving..." : "Save Book"}
          </button>
        </div>
      </form>
    </div>
  );
}
