import RankedBooksPage from "../components/RankedBooksPage";
import BookReviewsPanel from "../components/BookReviewsPanel";
import { useAuth } from "../context/AuthContext";

// Reached only from "View More →" on the Dashboard's Top Rated Books panel.
// It is intentionally not linked from the navbar.
export default function TopRatedBooks() {
  const { user } = useAuth();

  return (
    <RankedBooksPage
      endpoint="/books/stats/top-rated"
      eyebrow="LIBRARY INSIGHTS"
      title="Top Rated Books"
      subtitle="Top 25 by average rating"
      emptyTitle="No ratings available yet"
      emptyText="Books will appear here once readers have rated them."
      errorTitle="Top rated books unavailable"
      detailsLabel="reviews"
      renderDetails={(book, patch) => (
        <BookReviewsPanel
          bookId={book._id}
          isAdmin={user?.role === "admin"}
          onStatsChange={patch}
        />
      )}
      renderStat={(book) =>
        book.ratingCount > 0 && book.rating > 0 ? (
          <>
            <span className="block text-base font-bold text-ink-900">
              <span className="text-gold-500">★</span>{" "}
              {Number(book.rating).toFixed(1)}
            </span>
            <span className="block text-[12px] text-ink-600">
              {book.ratingCount} {book.ratingCount === 1 ? "rating" : "ratings"}
            </span>
          </>
        ) : (
          <span className="block text-[12px] text-ink-600">No ratings yet</span>
        )
      }
    />
  );
}
