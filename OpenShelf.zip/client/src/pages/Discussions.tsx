import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { DiscussionThread } from "../types";
import { timeAgo } from "../utils/timeAgo";
import { RowSkeletons } from "../components/BookSkeletons";
import { useInfiniteList } from "../hooks/useInfiniteList";

export default function Discussions() {
  const [sort, setSort] = useState<"recent" | "top">("recent");
  const [query, setQuery] = useState("");
  const [search, setSearch] = useState("");

  // Only search once there are at least 3 characters, after a short pause.
  useEffect(() => {
    const value = query.trim();
    const next = value.length >= 3 ? value : "";
    const timer = window.setTimeout(() => setSearch(next), 300);
    return () => window.clearTimeout(timer);
  }, [query]);

  const resetKey = JSON.stringify([sort, search.toLowerCase()]);
  const list = useInfiniteList<DiscussionThread>(async (page) => {
    const { data } = await api.get<DiscussionThread[]>("/discussions", {
      params: { sort, q: search || undefined, limit: 10, offset: (page - 1) * 10 },
    });
    return { items: data, hasMore: data.length === 10 };
  }, resetKey);
  const { items: visible, initialLoading: loading, error } = list;

  return (
    <div className="library-page">
      <div className="mb-6">
        <h2 className="m-0 font-heading text-2xl font-bold">Book Discussions</h2>
        <p className="mt-1 text-[14px] text-ink-600">
          Conversations happening across the library. To start a new one, open any book and
          use its discussion room.
        </p>
      </div>

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search topics or book titles…"
            aria-label="Search discussions"
            className="w-full rounded-full border border-line-strong bg-field py-2.5 pl-4 pr-12 text-[14px] outline-none focus:border-blue-500"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label="Clear discussion search"
              className="search-clear-btn"
            >
              ×
            </button>
          )}
        </div>
        <div className="flex rounded-full border border-line p-1" role="group" aria-label="Sort">
          {(["recent", "top"] as const).map((s) => (
            <button
              key={s}
              type="button"
              aria-pressed={sort === s}
              onClick={() => setSort(s)}
              className={`rounded-full px-4 py-1.5 text-[13px] font-semibold ${
                sort === s ? "bg-primary text-white" : "text-ink-600"
              }`}
            >
              {s === "recent" ? "Recent" : "Most active"}
            </button>
          ))}
        </div>
      </div>

      {error && visible.length === 0 ? (
        <div className="text-danger" role="alert">{error.message}<button className="ml-3 underline" onClick={list.retry}>Try again</button></div>
      ) : loading ? (
        <RowSkeletons />
      ) : visible.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line-strong p-8 text-center text-ink-600">
          {search ? "No discussions match your search." : "No discussions yet — open a book and start one!"}
        </div>
      ) : (
        <ul className="m-0 list-none space-y-3 p-0">
          {visible.map((t) => (
            <li key={t._id}>
              <Link
                to={`/discussions/${t._id}`}
                className="block rounded-xl border border-line bg-card p-4 transition-colors hover:border-line-strong"
              >
                <div className="flex flex-wrap items-center gap-2">
                  {t.pinned && <span className="text-[11px] font-bold text-gold-500">Pinned</span>}
                  {t.locked && <span className="text-[11px] font-bold text-ink-600">Locked</span>}
                  <span className="font-heading text-[15px] font-bold">{t.title}</span>
                  {t.spoiler && (
                    <span className="rounded-full bg-danger-bg px-2 py-0.5 text-[11px] font-bold text-danger">
                      Spoilers
                    </span>
                  )}
                </div>
                <div className="mt-1 text-[12.5px] text-blue-500">
                  {t.bookTitle} {t.bookAuthor && <span className="text-ink-600">· {t.bookAuthor}</span>}
                </div>
                <div className="mt-1.5 text-[12px] text-ink-600">
                  {t.userName} · active {timeAgo(t.lastActivityAt)} · {t.replyCount} {t.replyCount === 1 ? "reply" : "replies"} · {t.upvoteCount} {t.upvoteCount === 1 ? "upvote" : "upvotes"}
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
      {list.loadingMore && <div className="mt-4"><RowSkeletons /></div>}
      {error && visible.length > 0 && <p className="mt-4 text-danger" role="alert">{error.message} <button className="underline" onClick={list.retry}>Retry</button></p>}
      <div ref={list.sentinelRef} aria-hidden="true" style={{ height: 1 }} />
      {!list.hasMore && visible.length > 0 && !error && <p className="mt-6 text-center text-[13px] text-ink-600">You have reached the end of discussions.</p>}
    </div>
  );
}
