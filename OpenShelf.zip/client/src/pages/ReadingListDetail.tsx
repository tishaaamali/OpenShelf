import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import api from "../api/axios";
import { useConfirm } from "../context/ConfirmContext";
import BookCover from "../components/BookCover";
import { ReadingListSummary } from "../types";
import { PageSkeleton } from "../components/BookSkeletons";

export default function ReadingListDetail() {
  const confirm = useConfirm();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [list, setList] = useState<ReadingListSummary | null>(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");

  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      setError("");
      const { data } = await api.get<ReadingListSummary>(`/lists/${id}`);
      setList(data);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not load this list.");
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  function showToast(message: string) {
    setToast(message);
    setTimeout(() => setToast(""), 3000);
  }

  async function togglePublic() {
    if (!list) return;
    try {
      const { data } = await api.patch<ReadingListSummary>(`/lists/${list._id}`, {
        isPublic: !list.isPublic,
      });
      setList((l) => (l ? { ...l, isPublic: data.isPublic, followerCount: data.followerCount } : l));
      showToast(data.isPublic ? "List is now public" : "List is now private");
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not update the list");
    }
  }

  async function saveEdit() {
    if (!list) return;
    try {
      setSaving(true);
      await api.patch(`/lists/${list._id}`, { name, description });
      setList((l) => (l ? { ...l, name: name.trim(), description: description.trim() } : l));
      setEditing(false);
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not save changes");
    } finally {
      setSaving(false);
    }
  }

  async function removeBook(bookId: string) {
    if (!list) return;
    try {
      await api.delete(`/lists/${list._id}/books/${bookId}`);
      setList((l) =>
        l
          ? {
              ...l,
              books: l.books?.filter((b) => b._id !== bookId),
              bookCount: l.bookCount - 1,
            }
          : l
      );
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not remove the book");
    }
  }

  async function deleteList() {
    if (!list) return;
    if (
      !(await confirm({
        title: `Delete the list "${list.name}"?`,
        message: "The books stay in the library; only the list is removed.",
        confirmLabel: "Delete list",
      }))
    )
      return;
    try {
      await api.delete(`/lists/${list._id}`);
      navigate("/lists", { replace: true });
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not delete the list");
    }
  }

  async function toggleFollow() {
    if (!list) return;
    try {
      const { data } = await api.post(`/lists/${list._id}/follow`);
      setList((l) => (l ? { ...l, following: data.following, followerCount: data.followerCount } : l));
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not update follow");
    }
  }

  if (!list && !error) return <PageSkeleton variant="list" />;

  if (!list) {
    return (
      <div className="library-feedback" role={error ? "alert" : "status"}>
        {error ? (
          <>
            <strong>List unavailable</strong>
            <span>{error}</span>
            <button type="button" onClick={() => navigate("/lists")}>Back to lists</button>
          </>
        ) : (
          <PageSkeleton variant="list" />
        )}
      </div>
    );
  }

  return (
    <div className="library-page">
      <Link to="/lists" className="mb-4 inline-flex text-sm font-semibold text-blue-500">
        ← All lists
      </Link>

      <div className="mb-6 rounded-2xl border border-line bg-card p-5">
        {editing ? (
          <>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={60}
              aria-label="List name"
              className="mb-2 w-full rounded-xl border border-line-strong bg-field px-4 py-2 font-heading text-lg font-bold outline-none focus:border-blue-500"
            />
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={300}
              rows={2}
              aria-label="Description"
              className="w-full resize-none rounded-xl border border-line-strong bg-field px-4 py-2 text-[14px] outline-none focus:border-blue-500"
            />
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                disabled={saving}
                onClick={() => void saveEdit()}
                className="rounded-full bg-primary px-5 py-2 text-[13px] font-bold text-white disabled:opacity-50"
              >
                Save
              </button>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="rounded-full border border-line px-4 py-2 text-[13px] font-semibold"
              >
                Cancel
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="m-0 font-heading text-[22px] font-bold">{list.name}</h2>
              <span
                className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
                  list.isPublic ? "bg-success-bg text-success" : "bg-surface text-ink-600"
                }`}
              >
                {list.isPublic ? "Public" : "Private"}
              </span>
            </div>
            {list.description && (
              <p className="mb-0 mt-2 text-[14px] text-ink-600">{list.description}</p>
            )}
            <p className="mb-0 mt-2 text-[12.5px] text-ink-600">
              {list.bookCount} {list.bookCount === 1 ? "book" : "books"} · curated by{" "}
              {list.mine ? "you" : list.ownerName}
              {list.isPublic && ` · ${list.followerCount} following`}
            </p>

            <div className="mt-4 flex flex-wrap gap-2">
              {list.mine ? (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setName(list.name);
                      setDescription(list.description);
                      setEditing(true);
                    }}
                    className="rounded-full border border-line px-4 py-1.5 text-[13px] font-semibold"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => void togglePublic()}
                    className="rounded-full border border-line px-4 py-1.5 text-[13px] font-semibold"
                  >
                    {list.isPublic ? "Make private" : "Make public"}
                  </button>
                  <button
                    type="button"
                    onClick={() => void deleteList()}
                    className="rounded-full border border-danger px-4 py-1.5 text-[13px] font-semibold text-danger"
                  >
                    Delete list
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => void toggleFollow()}
                  aria-pressed={list.following}
                  className={`rounded-full px-5 py-1.5 text-[13px] font-bold ${
                    list.following
                      ? "border border-line text-ink-600"
                      : "bg-primary text-white"
                  }`}
                >
                  {list.following ? "Following ✓" : "Follow list"}
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {!list.books || list.books.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line-strong p-8 text-center text-ink-600">
          {list.mine
            ? "This list is empty. Open any book and tap “Add to list”."
            : "This list is empty."}
        </div>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-4">
          {list.books.map((book, index) => (
            <div key={book._id} className="rounded-xl border border-line bg-card p-3">
              <Link to={`/books/${book._id}`} className="block text-left">
                <BookCover
                  book={book}
                  index={index}
                  className="mb-2 h-[150px] rounded-lg text-3xl"
                />
                <div className="text-[13px] font-semibold leading-snug">{book.title}</div>
                <div className="text-[12px] text-ink-600">{book.author}</div>
              </Link>
              {list.mine && (
                <button
                  type="button"
                  onClick={() => void removeBook(book._id)}
                  className="mt-2 text-[12px] font-semibold text-danger"
                >
                  Remove
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[100] max-w-[90vw] -translate-x-1/2 rounded-full bg-primary px-6 py-3 text-center text-sm font-semibold text-white shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
