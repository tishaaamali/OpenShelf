
import { useState, FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AuthShell from "../components/AuthShell";

const inputClass =
  "auth-input w-full px-4 py-3 rounded-xl border text-[14.5px] outline-none transition";

const labelClass =
  "mb-1.5 block text-[13px] font-semibold text-slate-700";

const errorClass =
  "text-danger text-[12px] mt-1";

type FormErrors = {
  email?: string;
  password?: string;
};

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);

  function validateEmail(value: string) {
    if (!value.trim()) {
      setErrors((prev) => ({
        ...prev,
        email: "Email is required",
      }));
      return false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())) {
      setErrors((prev) => ({
        ...prev,
        email: "Enter a valid email address",
      }));
      return false;
    }

    setErrors((prev) => ({
      ...prev,
      email: undefined,
    }));

    return true;
  }

  function validatePassword(value: string) {
    if (!value) {
      setErrors((prev) => ({
        ...prev,
        password: "Password is required",
      }));
      return false;
    }

    setErrors((prev) => ({
      ...prev,
      password: undefined,
    }));

    return true;
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const emailValid = validateEmail(email);
    const passwordValid = validatePassword(password);

    if (!emailValid || !passwordValid) {
      return;
    }

    setLoading(true);

    try {
      await login(email.trim(), password);
      navigate("/");
    } catch (err: any) {
      const message = err?.response?.data?.message;

      setErrors({
        email:
          message ||
          (err?.request
            ? "Can't reach the library server. Make sure the server is running."
            : "Login failed. Please check your details and try again."),
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell mode="login">
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* EMAIL */}
        <div>
          <label htmlFor="email" className={labelClass}>
            Email <span className="text-danger">*</span>
          </label>

          <input
            id="email"
            type="email"
            autoComplete="email"
            placeholder="Email"
            value={email}
            onChange={(e) => {
              const value = e.target.value;
              setEmail(value);

              if (value.trim()) {
                setErrors((prev) => ({
                  ...prev,
                  email: undefined,
                }));
              }
            }}
            onBlur={() => validateEmail(email)}
            className={inputClass}
          />

          {errors.email && (
            <p className={errorClass}>{errors.email}</p>
          )}
        </div>

        {/* PASSWORD */}
        <div>
          <label htmlFor="password" className={labelClass}>
            Password <span className="text-danger">*</span>
          </label>

          <input
            id="password"
            type="password"
            autoComplete="current-password"
            placeholder="Password"
            value={password}
            onChange={(e) => {
              const value = e.target.value;
              setPassword(value);

              if (value) {
                setErrors((prev) => ({
                  ...prev,
                  password: undefined,
                }));
              }
            }}
            onBlur={() => validatePassword(password)}
            className={inputClass}
          />

          {errors.password && (
            <p className={errorClass}>{errors.password}</p>
          )}

          {/* FORGOT PASSWORD */}
          <div className="mt-2 text-right">
            <Link
              to="/forgot-password"
              className="text-sm font-semibold text-blue-700 transition hover:text-sky-600"
            >
              Forgot Password?
            </Link>
          </div>
        </div>

        {/* LOGIN BUTTON */}
        <button
          type="submit"
          disabled={loading}
          className="auth-submit w-full rounded-xl py-3.5 text-[15px] font-bold text-white transition disabled:opacity-60"
        >
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>
    </AuthShell>
  );
}
