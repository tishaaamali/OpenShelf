import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import QuoteFeed from "../components/QuoteFeed";

// Full "Words Worth Keeping" collection (opened from My Account > View More).
export default function WordsWorthKeepingPage() {
  const { user } = useAuth();

  return (
    <div className="library-page">
      <Link to="/account" className="mb-4 inline-flex text-sm font-semibold text-blue-500">
        Back to My Account
      </Link>

      <div className="mb-6">
        <h2 className="m-0 font-heading text-2xl font-bold">Words Worth Keeping</h2>
        <p className="mb-0 mt-1 max-w-[640px] text-[14px] text-ink-600">
          Every quote you have liked in Book Highlights. Remove one and it is gone from your
          account preview too.
        </p>
      </div>

      <QuoteFeed
        mode="saved"
        isAdmin={user?.role === "admin"}
        empty={
          <>
            You have not saved any quotes yet.{" "}
            <Link to="/highlights" className="font-semibold text-blue-500">
              Browse Book Highlights
            </Link>{" "}
            and like the lines you want to keep.
          </>
        }
      />
    </div>
  );
}
