
import { FormEvent, useState } from "react";
import { Link } from "react-router-dom";
import AuthShell from "../components/AuthShell";
import api from "../api/axios";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMessage("");
    setError("");
    setLoading(true);

    try {
      const response = await api.post("/auth/forgot-password", {
        email: email.trim(),
      });

      setMessage(response.data.message);
    } catch (err: any) {
      setError(
        err?.response?.data?.message ||
          "Unable to send the reset email. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell mode="login">
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <h3 className="mb-2 text-xl font-bold text-slate-900">
            Forgot your password?
          </h3>

          <p className="text-sm leading-6 text-slate-500">
            Enter your registered email address. If an account
            exists, we'll send you a password-reset link.
          </p>
        </div>

        <div>
          <label
            htmlFor="reset-email"
            className="mb-1.5 block text-[13px] font-semibold text-slate-700"
          >
            Email address
          </label>

          <input
            id="reset-email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="auth-input w-full rounded-xl border px-4 py-3 text-[14.5px] outline-none"
          />
        </div>

        {message && (
          <p role="status" className="text-sm text-green-700">
            {message}
          </p>
        )}

        {error && (
          <p role="alert" className="text-sm text-red-600">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="auth-submit w-full rounded-xl py-3.5 text-[15px] font-bold text-white transition disabled:opacity-60"
        >
          {loading ? "Sending..." : "Send Reset Link"}
        </button>

        <p className="text-center text-sm">
          Remember your password?{" "}
          <Link
            to="/login"
            className="font-semibold text-blue-700 hover:text-sky-600"
          >
            Back to Login
          </Link>
        </p>
      </form>
    </AuthShell>
  );
}
