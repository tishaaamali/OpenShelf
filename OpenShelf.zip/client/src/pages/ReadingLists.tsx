import { FormEvent, useCallback, useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import api from "../api/axios";
import { ReadingListSummary } from "../types";
import { timeAgo } from "../utils/timeAgo";
import { ListCardSkeletons } from "../components/BookSkeletons";

type Tab = "mine" | "following" | "discover";

const TABS: { id: Tab; label: string }[] = [
  { id: "mine", label: "My lists" },
  { id: "following", label: "Following" },
  { id: "discover", label: "Discover" },
];

export default function ReadingLists() {
  // The selected tab lives in the URL (?tab=following) so a refresh, a shared
  // link or the browser back button keeps the same tab.
  const [searchParams, setSearchParams] = useSearchParams();
  const rawTab = searchParams.get("tab");
  const tab: Tab = TABS.some((t) => t.id === rawTab) ? (rawTab as Tab) : "mine";
  const setTab = useCallback(
    (next: Tab) => setSearchParams(next === "mine" ? {} : { tab: next }, { replace: true }),
    [setSearchParams]
  );
  const [lists, setLists] = useState<ReadingListSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isPublic, setIsPublic] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const { data } = await api.get<ReadingListSummary[]>(`/lists/${tab}`);
      setLists(data);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not load lists.");
    } finally {
      setLoading(false);
    }
  }, [tab]);

  useEffect(() => {
    void load();
  }, [load]);

  async function create(event: FormEvent) {
    event.preventDefault();
    setFormError("");
    if (name.trim().length < 2) return setFormError("Give your list a name (at least 2 characters).");
    try {
      setSaving(true);
      await api.post("/lists", { name, description, isPublic });
      setName("");
      setDescription("");
      setIsPublic(false);
      setCreating(false);
      if (tab === "mine") await load();
      else setTab("mine");
    } catch (err: any) {
      setFormError(err?.response?.data?.message || "Could not create the list.");
    } finally {
      setSaving(false);
    }
  }

  const emptyText: Record<Tab, string> = {
    mine: "You haven't made any lists yet. Create one, then add books from any book page.",
    following: "You aren't following any lists yet. Check the Discover tab for ideas.",
    discover: "No public lists from other readers yet.",
  };

  return (
    <div className="library-page">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="m-0 font-heading text-2xl font-bold">Reading Lists</h2>
          <p className="mt-1 text-[14px] text-ink-600">
            Curate your own shelves — &ldquo;Summer reads&rdquo;, &ldquo;Book club picks&rdquo; — and keep
            them private or share them with other readers.
          </p>
        </div>
        {!creating && (
          <button
            type="button"
            onClick={() => setCreating(true)}
            className="rounded-full bg-primary px-5 py-2.5 text-[13.5px] font-bold text-white"
          >
            + New list
          </button>
        )}
      </div>

      {creating && (
        <form onSubmit={create} className="mb-6 rounded-2xl border border-line bg-card p-5">
          <label htmlFor="list-name" className="mb-1 block text-[13px] font-semibold">
            List name
          </label>
          <input
            id="list-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={60}
            placeholder="e.g. Rainy-day reads"
            className="mb-3 w-full rounded-xl border border-line-strong bg-field px-4 py-2.5 text-[14px] outline-none focus:border-blue-500"
          />
          <label htmlFor="list-desc" className="mb-1 block text-[13px] font-semibold">
            Description <span className="font-normal text-ink-600">(optional)</span>
          </label>
          <textarea
            id="list-desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength={300}
            rows={2}
            className="w-full resize-none rounded-xl border border-line-strong bg-field px-4 py-2.5 text-[14px] outline-none focus:border-blue-500"
          />
          <label className="mt-3 flex items-center gap-2 text-[13.5px]">
            <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} />
            Make this list public so other readers can find and follow it
          </label>
          {formError && (
            <p className="mt-2 text-[13px] text-danger" role="alert">{formError}</p>
          )}
          <div className="mt-4 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => {
                setCreating(false);
                setFormError("");
              }}
              className="rounded-full border border-line px-4 py-2 text-[13px] font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-full bg-primary px-5 py-2 text-[13px] font-bold text-white disabled:opacity-50"
            >
              {saving ? "Creating…" : "Create list"}
            </button>
          </div>
        </form>
      )}

      <div className="mb-5 flex gap-1 border-b border-line" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={`-mb-px border-b-2 px-4 py-2.5 text-[14px] font-semibold ${
              tab === t.id ? "border-cyan-400 text-ink-900" : "border-transparent text-ink-600"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {error ? (
        <p className="text-danger" role="alert">{error}</p>
      ) : loading ? (
        <ListCardSkeletons />
      ) : lists.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line-strong p-8 text-center text-ink-600">
          {emptyText[tab]}
        </div>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(260px,1fr))] gap-4">
          {lists.map((l) => (
            <Link
              key={l._id}
              to={`/lists/${l._id}`}
              className="block rounded-2xl border border-line bg-card p-4 transition-colors hover:border-line-strong"
            >
              <div className="mb-1 flex items-center gap-2">
                <span className="font-heading text-[15.5px] font-bold">{l.name}</span>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10.5px] font-bold ${
                    l.isPublic ? "bg-success-bg text-success" : "bg-surface text-ink-600"
                  }`}
                >
                  {l.isPublic ? "Public" : "Private"}
                </span>
              </div>
              {l.description && (
                <p className="mb-2 line-clamp-2 text-[13px] text-ink-600">{l.description}</p>
              )}
              <div className="text-[12px] text-ink-600">
                {l.bookCount} {l.bookCount === 1 ? "book" : "books"}
                {!l.mine && ` · by ${l.ownerName}`}
                {l.isPublic && l.followerCount > 0 && ` · ${l.followerCount} following`}
                {` · updated ${timeAgo(l.updatedAt)}`}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
