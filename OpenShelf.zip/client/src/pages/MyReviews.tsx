import { useEffect, useState } from "react";
import { ReviewCardSkeletons } from "../components/BookSkeletons";
import { Link, Navigate } from "react-router-dom";

import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { AccountSummary } from "../types";

type ReviewItem = AccountSummary["reviews"][number];

// Full page to see, edit and delete my ratings & reviews.
// It is reached from "Show more" on My Account and is NOT in the navbar.
export default function MyReviews() {
  const { user } = useAuth();

  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");

  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftRating, setDraftRating] = useState(0);
  const [draftReview, setDraftReview] = useState("");
  const [savingId, setSavingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  }

  async function load() {
    setLoading(true);
    setError("");

    try {
      const { data } = await api.get<AccountSummary>("/account/me");
      setReviews(data.reviews);
    } catch (err: any) {
      setError(
        err?.response?.data?.message ||
          "Could not load your reviews. Check your connection and try again."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  if (user?.role === "admin") {
    return <Navigate to="/account" replace />;
  }

  function startEdit(item: ReviewItem) {
    setConfirmDeleteId(null);
    setEditingId(item.bookId);
    setDraftRating(item.rating);
    setDraftReview(item.review);
  }

  function cancelEdit() {
    setEditingId(null);
    setDraftRating(0);
    setDraftReview("");
  }

  async function saveEdit(item: ReviewItem) {
    if (draftRating < 1) {
      showToast("Please select a rating");
      return;
    }

    setSavingId(item.bookId);

    try {
      await api.put(`/books/${item.bookId}/rating`, {
        rating: draftRating,
        review: draftReview.trim(),
      });

      setReviews((current) =>
        current.map((r) =>
          r.bookId === item.bookId
            ? { ...r, rating: draftRating, review: draftReview.trim() }
            : r
        )
      );

      cancelEdit();
      showToast("Review updated");
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not update review");
    } finally {
      setSavingId(null);
    }
  }

  async function confirmDelete(item: ReviewItem) {
    setDeletingId(item.bookId);

    try {
      await api.delete(`/books/${item.bookId}/rating`);

      setReviews((current) => current.filter((r) => r.bookId !== item.bookId));
      setConfirmDeleteId(null);
      showToast("Review deleted");
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not delete review");
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div className="library-page my-reviews-page">
      <div className="library-page-heading mb-6">
        <div className="library-eyebrow">YOUR VOICE</div>

        <h1 className="m-0 mb-1.5 font-heading text-2xl font-bold">
          My Ratings &amp; Reviews
        </h1>

        <p className="m-0 text-[14.5px] text-ink-600">
          {loading
            ? "\u00a0"
            : `${reviews.length} ${reviews.length === 1 ? "review" : "reviews"}`}
          {" · "}
          <Link to="/account" className="text-blue-500 hover:underline">
            ← Back to My Account
          </Link>
        </p>
      </div>

      {error && (
        <div className="library-feedback library-error" role="alert">
          <strong>Reviews unavailable</strong>
          <span>{error}</span>
          <button type="button" onClick={() => void load()}>
            Try again
          </button>
        </div>
      )}

      {loading && <ReviewCardSkeletons count={4} />}

      {!loading && !error && reviews.length === 0 && (
        <div className="library-empty-state py-16 text-center text-ink-600">
          <span>✧</span>
          <strong>No reviews yet</strong>
          <p>Return a book to rate and review it.</p>
        </div>
      )}

      {!loading && (
        <div className="space-y-4">
          {reviews.map((item) => {
            const editing = editingId === item.bookId;
            const saving = savingId === item.bookId;
            const confirming = confirmDeleteId === item.bookId;
            const deleting = deletingId === item.bookId;

            return (
              <div
                key={item.bookId}
                className="rounded-2xl border border-line bg-card p-5"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <Link
                      to={`/books/${item.bookId}`}
                      className="text-[15.5px] font-semibold hover:underline"
                    >
                      {item.title}
                    </Link>

                    <div className="text-[12.5px] text-ink-600">
                      {item.author} ·{" "}
                      {new Date(item.createdAt).toLocaleDateString()}
                    </div>
                  </div>

                  {!editing && (
                    <span
                      className="whitespace-nowrap text-gold-500"
                      aria-label={`${item.rating} out of 5`}
                    >
                      {"★".repeat(item.rating)}
                      {"☆".repeat(5 - item.rating)}
                    </span>
                  )}
                </div>

                {editing ? (
                  <div className="mt-4">
                    <div
                      className="mb-3 flex gap-1.5"
                      role="radiogroup"
                      aria-label="Rating"
                    >
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          role="radio"
                          aria-checked={star === draftRating}
                          aria-label={`${star} star${star > 1 ? "s" : ""}`}
                          onClick={() => setDraftRating(star)}
                          className={`text-3xl leading-none ${
                            star <= draftRating
                              ? "text-gold-500"
                              : "text-ink-600"
                          }`}
                        >
                          {star <= draftRating ? "★" : "☆"}
                        </button>
                      ))}
                    </div>

                    <textarea
                      value={draftReview}
                      onChange={(event) => setDraftReview(event.target.value)}
                      maxLength={500}
                      rows={4}
                      placeholder="Write your review (optional)"
                      aria-label="Your review"
                      className="w-full resize-none rounded-lg border border-line bg-field p-3 text-[13.5px] outline-none focus:border-blue-500"
                    />

                    <div className="mt-1 text-right text-[11.5px] text-ink-600">
                      {draftReview.length}/500
                    </div>

                    <div className="mt-3 flex gap-2.5">
                      <button
                        type="button"
                        onClick={() => void saveEdit(item)}
                        disabled={saving || draftRating === 0}
                        className="rounded-lg bg-primary px-5 py-2 text-[13px] font-bold text-white disabled:opacity-50"
                      >
                        {saving ? "Saving..." : "Save changes"}
                      </button>

                      <button
                        type="button"
                        onClick={cancelEdit}
                        disabled={saving}
                        className="rounded-lg border border-line px-5 py-2 text-[13px] font-semibold"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    {item.review ? (
                      <p className="mb-0 mt-3 whitespace-pre-wrap break-words text-[13.5px] leading-relaxed text-ink-600">
                        “{item.review}”
                      </p>
                    ) : (
                      <p className="mb-0 mt-3 text-[13px] italic text-ink-600">
                        No written review.
                      </p>
                    )}

                    <div className="mt-4 flex flex-wrap items-center gap-2.5">
                      {confirming ? (
                        <>
                          <span className="text-[13px] text-ink-600">
                            Delete this rating &amp; review?
                          </span>

                          <button
                            type="button"
                            onClick={() => void confirmDelete(item)}
                            disabled={deleting}
                            className="rounded-lg bg-danger px-4 py-1.5 text-[12.5px] font-bold text-white disabled:opacity-50"
                          >
                            {deleting ? "Deleting..." : "Yes, delete"}
                          </button>

                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            disabled={deleting}
                            className="rounded-lg border border-line px-4 py-1.5 text-[12.5px] font-semibold"
                          >
                            Keep it
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => startEdit(item)}
                            className="rounded-lg border border-line px-4 py-1.5 text-[12.5px] font-semibold hover:border-blue-500 hover:text-blue-500"
                          >
                            Edit
                          </button>

                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(item.bookId)}
                            className="rounded-lg border border-line px-4 py-1.5 text-[12.5px] font-semibold text-danger hover:border-danger"
                          >
                            Delete
                          </button>
                        </>
                      )}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}

      {toast && (
        <div
          role="status"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white shadow-xl"
        >
          {toast}
        </div>
      )}
    </div>
  );
}
