
import { useEffect, useState, FormEvent } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { AccountSummary, BookRequest } from "../types";
import { Link } from "react-router-dom";
import { useConfirm } from "../context/ConfirmContext";
import RequestQR from "../components/RequestQR";
import WordsWorthKeeping from "../components/WordsWorthKeeping";
import { BookIcon } from "../components/icons";
import { isValidPhone } from "../utils/validators";
import { AccountSkeleton, RequestRowSkeletons } from "../components/BookSkeletons";

const inputClass =
  "w-full px-3 py-2.5 rounded-lg border border-line bg-field text-[13.5px] outline-none focus:border-blue-500";

// Only the most recent QR requests are listed on My Account.
const RECENT_REQUESTS = 3;

export default function Account() {
  const { refreshUser, user } = useAuth();
  const confirm = useConfirm();

  const [summary, setSummary] = useState<AccountSummary | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [toast, setToast] = useState("");
  const [loadError, setLoadError] = useState("");
  const [requests, setRequests] = useState<BookRequest[]>([]);
  const [requestsLoading, setRequestsLoading] = useState(true);
  const [requestsError, setRequestsError] = useState("");
  const [openQr, setOpenQr] = useState<string | null>(null);

  async function loadRequests() {
    try {
      setRequestsLoading(true);
      setRequestsError("");
      const { data } = await api.get("/requests/mine");
      setRequests(data);
    } catch (err: any) {
      setRequestsError(
        err?.response?.data?.message ||
          "Could not load your book requests."
      );
    } finally {
      setRequestsLoading(false);
    }
  }

  async function load() {
    try {
      setLoadError("");
      const { data } = await api.get("/account/me");

      setSummary(data);
      setFirstName(data.profile.firstName || "");
      setLastName(data.profile.lastName || "");
      setEmail(data.profile.email || "");
      setPhone(data.profile.phone || "");
    } catch (err: any) {
      setLoadError(
        err?.response?.data?.message ||
          "Could not load your account. Check your connection and try again."
      );
    }
  }

  useEffect(() => {
    load();
    if (user?.role !== "admin") loadRequests();
    // The account view is role-specific; admins do not have borrowing history.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.role]);

  function showToast(message: string) {
    setToast(message);
    setTimeout(() => setToast(""), 3000);
  }

  async function cancelRequest(id: string) {
    const request = requests.find((r) => r._id === id);
    const ok = await confirm({
      title: "Cancel this request?",
      message: request?.title
        ? `Your request for "${request.title}" will be cancelled and its QR code will stop working.`
        : "Your request will be cancelled and its QR code will stop working.",
      confirmLabel: "Cancel request",
      cancelLabel: "Keep request",
    });
    if (!ok) return;

    try {
      await api.post(`/requests/${id}/cancel`);
      setOpenQr(null);
      showToast("Request cancelled");
      await loadRequests();
    } catch (err: any) {
      showToast(
        err?.response?.data?.message ||
          "Could not cancel this request"
      );
    }
  }

  async function handleSave(e: FormEvent) {
    e.preventDefault();

    if (!firstName.trim() || !lastName.trim()) {
      showToast("First name and last name are required");
      return;
    }

    if (phone.trim() && !isValidPhone(phone)) {
      showToast("Enter a valid phone number, or leave it empty");
      return;
    }

    try {
      const { data } = await api.put("/account/me", {
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        phone: phone.trim(),
      });

      refreshUser({
        name: data.name,
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        phone: data.phone,
      });

      showToast("Account updated");
      await load();
    } catch (err: any) {
      showToast(
        err?.response?.data?.message ||
          "Failed to update account"
      );
    }
  }

  if (!summary && !loadError) {
    // Same shape as the loaded page: stat cards, panels, requests, reviews, profile.
    return <AccountSkeleton isAdmin={user?.role === "admin"} />;
  }

  if (!summary) {
    return (
      <div className="library-feedback" role="alert">
        <strong>Account unavailable</strong>
        <span>{loadError}</span>
        <button type="button" onClick={load}>
          Try again
        </button>
      </div>
    );
  }

  const isAdmin = summary.profile.role === "admin";

  return (
    <div className="library-page account-page">
      <div className="mb-6">
        <h1 className="text-2xl font-heading font-bold m-0 mb-1.5">
          My Account{" "}
          <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-primary text-white align-middle ml-1">
            {summary.profile.role === "admin" ? "Admin" : "Member"}
          </span>
        </h1>

        <p className="text-ink-600 text-[14.5px] m-0">
          {isAdmin ? "Your administrator profile" : "Your borrowing activity & profile"}
        </p>
      </div>

      {!isAdmin && <>
      {/* Account statistics */}
      <div className="grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-4 mb-6">
        <StatCard n={summary.borrowed.length} label="Books Borrowed" />
        <StatCard n={summary.booksRead} label="Books Read" />
        <StatCard
          n={summary.waitlisted.length}
          label="On Waitlist"
        />
        <StatCard
          n={`₹${summary.pendingFees}`}
          label="Pending Fees"
          danger={summary.pendingFees > 0}
        />
      </div>

      {/* Borrowed books and waitlist */}
      <div className="grid grid-cols-2 gap-6 max-md:grid-cols-1">
        <Panel title="Currently Borrowed">
          {summary.borrowed.length === 0 ? (
            <p className="text-ink-600 text-[13.5px]">
              You haven't borrowed any books yet.
            </p>
          ) : (
            summary.borrowed.map((book) => (
              <div
                key={book.bookId}
                className="flex items-center gap-3 py-3 border-b border-line last:border-none text-[13.5px]"
              >
                <Link
                  to={`/books/${book.bookId}`}
                  className="shrink-0"
                  aria-label={`View ${book.title}`}
                >
                  <BookPlaceholder size="small" />
                </Link>

                <div className="min-w-0 flex-1">
                  <Link
                    to={`/books/${book.bookId}`}
                    className="font-semibold hover:underline"
                  >
                    {book.title}
                  </Link>

                  <div className="text-[12px] text-ink-600 mt-1">
                    Due {new Date(book.dueDate).toLocaleDateString()}
                    {book.daysOverdue > 0 &&
                      ` · ${book.daysOverdue} day${
                        book.daysOverdue > 1 ? "s" : ""
                      } overdue`}
                  </div>

                  <div className="mt-2">
                    {book.daysOverdue > 0 ? (
                      <span className="badge badge-damaged">
                        ₹{book.fine} due
                      </span>
                    ) : (
                      <span className="badge badge-available">
                        On time
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </Panel>

        <Panel title="Waitlist Status">
          {summary.waitlisted.length === 0 ? (
            <p className="text-ink-600 text-[13.5px]">
              You're not waiting on any books.
            </p>
          ) : (
            summary.waitlisted.map((book) => (
              <div
                key={book.bookId}
                className="flex items-center gap-3 py-3 border-b border-line last:border-none text-[13.5px]"
              >
                <Link
                  to={`/books/${book.bookId}`}
                  className="shrink-0"
                  aria-label={`View ${book.title}`}
                >
                  <BookPlaceholder size="small" />
                </Link>

                <div className="min-w-0 flex-1">
                  <Link
                    to={`/books/${book.bookId}`}
                    className="font-semibold hover:underline"
                  >
                    {book.title}
                  </Link>

                  <div className="text-[12px] text-ink-600 mt-1">
                    {book.totalWaiting} waiting total
                  </div>
                </div>

                <span className="bg-surface rounded-full px-2.5 py-1 text-[12px] font-bold text-ink-600">
                  #{book.position}
                </span>
              </div>
            ))
          )}
        </Panel>
      </div>

      {/* Book requests with QR */}
      <div className="mt-6">
        <Panel title="My Book Requests (QR)">
          {requestsLoading ? (
            <RequestRowSkeletons count={2} />
          ) : requestsError ? (
            <div className="text-danger text-[13.5px]" role="alert">
              <p>{requestsError}</p>
              <button
                type="button"
                onClick={loadRequests}
                className="underline font-semibold"
              >
                Try again
              </button>
            </div>
          ) : requests.length === 0 ? (
            <p className="text-ink-600 text-[13.5px]">
              No requests yet. Open a book and choose “Request with QR”.
            </p>
          ) : (
            requests.slice(0, RECENT_REQUESTS).map((request) => (
              <div
                key={request._id}
                className="py-3 border-b border-line last:border-none text-[13.5px]"
              >
                <div className="flex items-center gap-3 flex-wrap">
                  <Link
                    to={`/books/${request.bookId}`}
                    className="shrink-0"
                    aria-label={`View ${request.title}`}
                  >
                    <BookPlaceholder size="large" />
                  </Link>

                  <div className="min-w-0 flex-1">
                    <Link
                      to={`/books/${request.bookId}`}
                      className="font-semibold hover:underline"
                    >
                      {request.title}
                    </Link>

                    <div className="text-[12px] text-ink-600 mt-1">
                      {request.status === "Pending" ? (
                        <>
                          Requested{" "}
                          {new Date(
                            request.requestedAt
                          ).toLocaleDateString()}
                          {request.expiresAt && (
                            <>
                              <br />
                              Show this QR at the desk before{" "}
                              {new Date(
                                request.expiresAt
                              ).toLocaleString()}
                            </>
                          )}
                        </>
                      ) : request.status === "Issued" &&
                        request.issuedAt ? (
                        <>
                          Issued{" "}
                          {new Date(
                            request.issuedAt
                          ).toLocaleDateString()}
                        </>
                      ) : (
                        <>
                          Requested{" "}
                          {new Date(
                            request.requestedAt
                          ).toLocaleDateString()}
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap justify-end">
                    <span
                      className={`badge ${
                        request.status === "Pending" ||
                        request.status === "Issued"
                          ? "badge-available"
                          : "badge-damaged"
                      }`}
                    >
                      {request.status}
                    </span>

                    {request.status === "Pending" && (
                      <>
                        <button
                          type="button"
                          onClick={() =>
                            setOpenQr(
                              openQr === request._id
                                ? null
                                : request._id
                            )
                          }
                          className="border border-line rounded-full px-3 py-1 text-[12px] font-semibold"
                        >
                          {openQr === request._id
                            ? "Hide QR"
                            : "Show QR"}
                        </button>

                        <button
                          type="button"
                          onClick={() => cancelRequest(request._id)}
                          className="text-danger text-[12px] font-semibold"
                        >
                          Cancel
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {openQr === request._id && request.token && (
                  <div className="mt-3">
                    <RequestQR token={request.token} />
                  </div>
                )}

                {openQr === request._id && !request.token && (
                  <p className="text-ink-600 text-[12px] mt-3">
                    QR token is unavailable for this request.
                  </p>
                )}
              </div>
            ))
          )}
        </Panel>
      </div>

      {/* Ratings and reviews */}
      <div className="mt-6">
        <Panel title="My Ratings & Reviews">
          {summary.reviews.length === 0 ? (
            <p className="text-ink-600 text-[13.5px]">
              You haven't rated any books yet. Return a book to rate and review it.
            </p>
          ) : (
            <>
              {/* brief view: latest 2 reviews, long text is shortened */}
              {summary.reviews.slice(0, 2).map((review) => (
                <div
                  key={review.bookId}
                  className="py-2.5 border-b border-line last:border-none text-[13.5px]"
                >
                  <div className="flex items-center justify-between gap-3">
                    <Link
                      to={`/books/${review.bookId}`}
                      className="font-semibold hover:underline truncate"
                    >
                      {review.title}
                    </Link>

                    <span
                      className="text-gold-500 whitespace-nowrap"
                      aria-label={`${review.rating} out of 5`}
                    >
                      {"★".repeat(review.rating)}
                      {"☆".repeat(5 - review.rating)}
                    </span>
                  </div>

                  {review.review && (
                    <p className="text-ink-600 text-[13px] mt-1 mb-0">
                      “
                      {review.review.length > 90
                        ? `${review.review.slice(0, 90).trimEnd()}…`
                        : review.review}
                      ”
                    </p>
                  )}

                  <div className="text-[11.5px] text-ink-600 mt-1">
                    {new Date(review.createdAt).toLocaleDateString()}
                  </div>
                </div>
              ))}

              <Link
                to="/my-reviews"
                className="mt-3 inline-block text-[13.5px] font-semibold text-blue-500 hover:underline"
              >
                {summary.reviews.length > 2
                  ? `Show more (${summary.reviews.length - 2} more) →`
                  : "Show more / edit →"}
              </Link>
            </>
          )}
        </Panel>
      </div>
      </>}

      {/* Words Worth Keeping: preview of the quotes this user has liked */}
      <WordsWorthKeeping />

      {/* Profile form */}
      <div className="bg-card border border-line rounded-2xl p-6 mt-6">
        <h3 className="text-[15.5px] font-heading font-bold mb-4">
          Profile
        </h3>

        <form onSubmit={handleSave} className="grid grid-cols-2 gap-x-4 gap-y-4 max-md:grid-cols-1">
          <div className="contents">
            <div>
              <label className="block text-[12.5px] font-semibold text-ink-600 mb-1.5">
                First Name
              </label>
              <input
                required
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-[12.5px] font-semibold text-ink-600 mb-1.5">
                Last Name
              </label>
              <input
                required
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                className={inputClass}
              />
            </div>
          </div>

          <div>
            <label className="block text-[12.5px] font-semibold text-ink-600 mb-1.5">
              Email
            </label>
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputClass}
            />
          </div>

          <div>
            <label className="block text-[12.5px] font-semibold text-ink-600 mb-1.5">
              Phone Number (optional)
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+91 98765 43210"
              className={inputClass}
            />
          </div>

          <div>
            <label className="block text-[12.5px] font-semibold text-ink-600 mb-1.5">
              Member Since
            </label>
            <input
              disabled
              value={new Date(
                summary.profile.since
              ).toLocaleDateString()}
              className={`${inputClass} !opacity-100`}
            />
          </div>

          <div className="flex items-end pb-[6px]">
            <button
              type="submit"
              className="rounded-full bg-gold-500 px-6 py-2.5 text-sm font-bold text-[#2A1B00] hover:bg-gold-600"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>

      {toast && (
        <div
          role="status"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-primary text-white px-6 py-3 rounded-full text-sm font-semibold shadow-xl"
        >
          {toast}
        </div>
      )}
    </div>
  );
}

function BookPlaceholder({ size }: { size: "small" | "large" }) {
  const dimensions =
    size === "small"
      ? "h-[84px] w-[58px]"
      : "h-[96px] w-[66px]";

  return (
    <div
      aria-hidden="true"
      className={`${dimensions} rounded-lg bg-surface border border-line flex items-center justify-center text-ink-600`}
    >
      <BookIcon size={26} />
    </div>
  );
}

function StatCard({
  n,
  label,
  danger,
}: {
  n: number | string;
  label: string;
  danger?: boolean;
}) {
  return (
    <div
      className={`bg-card border rounded-2xl p-5 ${
        danger ? "border-danger" : "border-line"
      }`}
    >
      <div
        className={`text-[28px] font-heading font-extrabold ${
          danger ? "text-danger" : ""
        }`}
      >
        {n}
      </div>
      <div className="text-[13px] text-ink-600 mt-0.5">
        {label}
      </div>
    </div>
  );
}

function Panel({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-card border border-line rounded-2xl p-6">
      <h3 className="text-[15.5px] font-heading font-bold mb-4">
        {title}
      </h3>
      {children}
    </div>
  );
}
