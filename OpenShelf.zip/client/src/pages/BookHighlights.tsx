import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import QuoteFeed from "../components/QuoteFeed";

const SORTS = [
  { id: "new", label: "Latest" },
  { id: "top", label: "Most liked" },
] as const;

const KINDS = [
  { id: "", label: "All" },
  { id: "literary", label: "Literary lines" },
  { id: "member", label: "From readers" },
] as const;

export default function BookHighlights() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [sort, setSort] = useState<"new" | "top">("new");
  const [kind, setKind] = useState<string>("");
  const [query, setQuery] = useState("");
  const [search, setSearch] = useState("");

  // Debounce the search box so each keystroke does not restart the feed, and
  // only call the API once there are at least 3 characters (1-2 show everything).
  useEffect(() => {
    const value = query.trim();
    const next = value.length >= 3 ? value : "";
    const timer = window.setTimeout(() => setSearch(next), 300);
    return () => window.clearTimeout(timer);
  }, [query]);

  return (
    <div className="library-page">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="m-0 font-heading text-2xl font-bold">Book Highlights</h2>
          <p className="mb-0 mt-1 max-w-[640px] text-[14px] text-ink-600">
            Memorable lines from the shelves. Like a quote to keep it in Words Worth Keeping, or
            borrow the book it came from. To add a line, open any book and use its Highlights section.
          </p>
        </div>
        {!isAdmin && (
          <Link to="/account/words-worth-keeping" className="highlight-btn">
            Words Worth Keeping
          </Link>
        )}
      </div>

      <div className="books-toolbar mb-6">
        <div className="relative mb-3">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search lines, authors or books"
            aria-label="Search Book Highlights"
            className="w-full rounded-full border border-line-strong bg-field py-2.5 pl-4 pr-12 text-[14px] outline-none focus:border-blue-500"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label="Clear highlight search"
              className="search-clear-btn"
            >
              ×
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by type">
            {KINDS.map((k) => (
              <button
                key={k.id || "all"}
                type="button"
                aria-pressed={kind === k.id}
                onClick={() => setKind(k.id)}
                className={`highlight-chip ${kind === k.id ? "highlight-chip-on" : ""}`}
              >
                {k.label}
              </button>
            ))}
          </div>

          <div className="flex rounded-full border border-line p-1" role="group" aria-label="Sort">
            {SORTS.map((s) => (
              <button
                key={s.id}
                type="button"
                aria-pressed={sort === s.id}
                onClick={() => setSort(s.id)}
                className={`rounded-full px-4 py-1.5 text-[13px] font-semibold ${
                  sort === s.id ? "bg-primary text-white" : "text-ink-600"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <QuoteFeed
        mode="highlights"
        params={{ q: search, sort, kind }}
        isAdmin={isAdmin}
        empty={
          search || kind
            ? "No highlights match your search or filter."
            : "There are no highlights yet. Open a book and add its best line."
        }
      />
    </div>
  );
}
