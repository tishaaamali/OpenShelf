import { useEffect, useRef, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { Book, BookRequest } from "../types";
import BookCover from "../components/BookCover";
import RequestQR from "../components/RequestQR";
import AdminBookActions from "../components/AdminBookActions";
import BookReviewsPanel from "../components/BookReviewsPanel";
import DiscussionRoom from "../components/DiscussionRoom";
import BookQuotes from "../components/BookQuotes";
import { BookDetailSkeleton } from "../components/BookSkeletons";
import AddToListButton from "../components/AddToListButton";
import { RowSkeletons } from "../components/BookSkeletons";

function overdueDays(dueDate?: string | null): number {
  if (!dueDate) return 0;

  const diff = Math.floor(
    (Date.now() - new Date(dueDate).getTime()) / 86400000
  );

  return diff > 0 ? diff : 0;
}

export default function BookDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Where the reader came from (set by links such as the quote cards), so the
  // back button returns there instead of always going to the Books list.
  const backTarget = (() => {
    const from = (location.state as { from?: string } | null)?.from;
    if (from?.startsWith("/highlights")) return { path: from, label: "Book Highlights" };
    if (from === "/" || from === "/home") return { path: "/", label: "Home" };
    if (from?.startsWith("/account")) return { path: from, label: "My Account" };
    return { path: "/books", label: "Books" };
  })();
  const isAdmin = user?.role === "admin";

  const [book, setBook] = useState<Book | null>(null);
  const [loadError, setLoadError] = useState("");
  const [toast, setToast] = useState("");

  const [canRate, setCanRate] = useState(false);
  const [rated, setRated] = useState(false);
  const [myRating, setMyRating] = useState<number | null>(null);
  const [selectedRating, setSelectedRating] = useState(0);
  const [ratingLoading, setRatingLoading] = useState(false);
  const [ratingModal, setRatingModal] = useState(false);
  const [review, setReview] = useState("");
  // Bumped after the reader posts a rating so the reviews list reloads.
  const [reviewsVersion, setReviewsVersion] = useState(0);

  const [qrRequest, setQrRequest] = useState<BookRequest | null>(null);
  const [qrLoadingCopyId, setQrLoadingCopyId] = useState<string | null>(null);
  const [returningCopy, setReturningCopy] = useState<string | null>(null);
  const [readerNote, setReaderNote] = useState("");
  const [noteSaving, setNoteSaving] = useState(false);

  const [liked, setLiked] = useState(false);
  const [likeLoading, setLikeLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<Book[]>([]);
  const [suggestionsError, setSuggestionsError] = useState("");
  const [suggestionsLoading, setSuggestionsLoading] = useState(false);
  const qrRequestPendingRef = useRef(false);

  async function load() {
    try {
      setLoadError("");
      const { data } = await api.get(`/books/${id}`);
      setBook(data);
    } catch (err: any) {
      setLoadError(
        err?.response?.data?.message ||
          "Could not load this book. Check your connection and try again."
      );
    }
  }

  async function loadRating(): Promise<boolean> {
    try {
      const { data } = await api.get(`/books/${id}/rating`);
      setCanRate(data.canRate);
      setRated(data.rated);
      setMyRating(data.rating);
      return Boolean(data.canRate);
    } catch (err) {
      console.error("Failed to load rating:", err);
      return false;
    }
  }

  async function loadLike() {
    try {
      const { data } = await api.get(`/books/${id}/like`);
      setLiked(data.liked);
      // Already liked: show the suggestions straight away under Copies.
      if (data.liked) void loadSuggestions();
      else setSuggestions([]);
    } catch (err) {
      console.error("Failed to load like status:", err);
    }
  }

  async function loadSuggestions() {
    try {
      setSuggestionsLoading(true);
      setSuggestionsError("");
      const { data } = await api.get(`/books/${id}/suggestions`);
      setSuggestions(data);
    } catch (err: any) {
      setSuggestionsError(
        err?.response?.data?.message || "Could not load suggestions."
      );
    } finally {
      setSuggestionsLoading(false);
    }
  }

  useEffect(() => {
    void load();

    if (!isAdmin) {
      void loadRating();
      void loadLike();
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isAdmin]);

  function showToast(message: string) {
    setToast(message);
    setTimeout(() => setToast(""), 3200);
  }

  async function toggleLike() {
    try {
      setLikeLoading(true);
      const { data } = await api.post(`/books/${id}/like`);
      setLiked(data.liked);

      if (data.liked) {
        await loadSuggestions();
      } else {
        setSuggestions([]);
      }
    } catch (err: any) {
      showToast(
        err?.response?.data?.message || "Could not update your like"
      );
    } finally {
      setLikeLoading(false);
    }
  }

  async function requestWithQr(copyId: string) {
    if (!id || qrRequestPendingRef.current || isAdmin) return;

    try {
      qrRequestPendingRef.current = true;
      setQrLoadingCopyId(copyId);

      const { data } = await api.post("/requests", {
        bookId: id,
        copyId,
      });

      if (!data?.token) {
        showToast(
          "The server did not return a QR token. Please check the backend."
        );
        return;
      }

      setQrRequest(data);
    } catch (err: any) {
      showToast(
        err?.response?.data?.message || "Could not create your request"
      );
    } finally {
      qrRequestPendingRef.current = false;
      setQrLoadingCopyId(null);
    }
  }

  async function cancelQrRequest() {
    if (!qrRequest) return;

    try {
      await api.post(`/requests/${qrRequest._id}/cancel`);
      setQrRequest(null);
      showToast("Request cancelled");
    } catch (err: any) {
      showToast(
        err?.response?.data?.message || "Could not cancel this request"
      );
    }
  }

  async function returnCopy(copyId: string) {
    if (isAdmin) return;
    setReturningCopy(copyId);
    setReaderNote("");
  }

  async function submitReturn() {
    if (isAdmin || !returningCopy || !readerNote.trim()) return;

    try {
      setNoteSaving(true);

      const { data } = await api.post(
        `/books/${id}/copies/${returningCopy}/return`,
        { note: readerNote.trim() }
      );

      showToast(data.message);
      setReturningCopy(null);
      setReaderNote("");

      await load();

      const canRateAfterReturn = await loadRating();

      if (canRateAfterReturn) {
        setSelectedRating(0);
        setReview("");
        setRatingModal(true);
      }
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Failed to return");
    } finally {
      setNoteSaving(false);
    }
  }

  function handleStarClick(star: number) {
    setSelectedRating((current) =>
      current === star ? current - 1 : star
    );
  }

  async function submitRating() {
    if (selectedRating === 0) {
      showToast("Please select a rating");
      return;
    }

    try {
      setRatingLoading(true);

      const { data } = await api.post(`/books/${id}/rating`, {
        rating: selectedRating,
        review: review.trim(),
      });

      showToast(data.message);
      setRatingModal(false);
      setCanRate(false);
      setRated(true);
      setMyRating(selectedRating);
      setSelectedRating(0);
      setReview("");

      await load();
      await loadRating();
      setReviewsVersion((version) => version + 1);
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Failed to submit rating");
    } finally {
      setRatingLoading(false);
    }
  }

  async function joinWaitlist() {
    if (isAdmin) return;

    try {
      const { data } = await api.post(`/books/${id}/waitlist/join`);
      showToast(data.message);
      await load();
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Failed to join waitlist");
    }
  }

  async function leaveWaitlist() {
    if (isAdmin) return;

    try {
      const { data } = await api.post(`/books/${id}/waitlist/leave`);
      showToast(data.message);
      await load();
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Failed to leave waitlist");
    }
  }

  if (!book && !loadError) return <BookDetailSkeleton />;

  if (!book) {
    return (
      <div className="library-feedback" role="alert">
        <strong>Book unavailable</strong>
        <span>{loadError}</span>
        <button type="button" onClick={() => void load()}>
          Try again
        </button>
      </div>
    );
  }

  const availableCount = book.copies.filter(
    (copy) => copy.status === "Available"
  ).length;

  const inWaitlistIndex = book.waitlist.findIndex(
    (entry) => entry.email === user?.email
  );

  return (
    <div className="library-page book-detail-page">
      <button
        type="button"
        onClick={() => navigate(backTarget.path)}
        className="text-blue-500 font-semibold text-sm mb-4 flex items-center gap-1.5"
      >
        ← Back to {backTarget.label}
      </button>

      <div className="grid grid-cols-[220px_1fr] gap-9 max-md:grid-cols-1">
        <BookCover
          book={book}
          className="book-detail-cover h-[290px] rounded-2xl text-5xl"
        />

        <div>
          <h2 className="text-2xl font-heading font-bold m-0 mb-1">
            {book.title}
          </h2>

          <p className="text-ink-600 mb-4 text-[14.5px]">
            by {book.author} · {book.category}
          </p>

          <div className="flex items-center gap-2 mb-4">
            <span className="text-gold-500 text-lg">★</span>

            <span className="font-bold">
              {book.rating ? book.rating.toFixed(1) : "0.0"}
            </span>

            <span className="text-ink-600 text-sm">
              ({book.ratingCount || 0} ratings)
            </span>

            {!isAdmin && (
              <button
                type="button"
                onClick={() => void toggleLike()}
                disabled={likeLoading}
                aria-pressed={liked}
                className={`ml-3 rounded-full border px-3.5 py-1 text-[13px] font-semibold disabled:opacity-60 ${
                  liked
                    ? "border-gold-500 bg-gold-500/20 text-gold-500 shadow-[0_0_0_2px_rgba(245,158,11,.14)]"
                    : "border-line text-ink-600"
                }`}
              >
                {liked ? "♥ Liked" : "♡ Like"}
              </button>
            )}

            {!isAdmin && (
              <AddToListButton bookId={book._id} onMessage={showToast} />
            )}
          </div>

          <div className="flex flex-wrap gap-x-6 gap-y-2 mb-5 text-[13.5px] text-ink-600">
            <div>
              <b className="text-ink-900 font-semibold">ISBN:</b>{" "}
              {book.isbn13 || book.isbn10}
            </div>

            <div>
              <b className="text-ink-900 font-semibold">Publisher:</b>{" "}
              {book.publisher}
            </div>

            <div>
              <b className="text-ink-900 font-semibold">Edition:</b>{" "}
              {book.edition}
            </div>

            <div>
              <b className="text-ink-900 font-semibold">Year:</b>{" "}
              {book.year}
            </div>

            <div>
              <b className="text-ink-900 font-semibold">Language:</b>{" "}
              {book.language}
            </div>

            <div>
              <b className="text-ink-900 font-semibold">Format:</b>{" "}
              {book.format}
            </div>
          </div>

          <p className="text-[14.5px] leading-relaxed max-w-[640px] mb-6">
            {book.description}
          </p>

          <div className="mb-5 max-w-[640px] rounded-xl border border-line bg-card/70 p-4">
            <h3 className="mb-1 font-heading text-sm font-bold">
              A note from last reader
            </h3>

            <p className="m-0 text-sm text-ink-600">
              {book.nextReaderNote ||
                "Enjoy this book and pass it on to another reader."}
            </p>
          </div>

          {isAdmin && (
            <AdminBookActions
              book={book}
              onUpdated={setBook}
              onDeleted={() => navigate("/books", { replace: true })}
              onMessage={showToast}
            />
          )}

          <h3 className="text-[17px] font-heading font-bold mb-2.5">
            Copies
          </h3>

          <table className="w-full border-collapse mb-2">
            <thead>
              <tr className="text-[12px] text-ink-600 text-left">
                <th className="pb-2 border-b-[1.5px] border-line font-semibold">
                  Barcode
                </th>

                <th className="pb-2 border-b-[1.5px] border-line font-semibold">
                  Shelf
                </th>

                <th className="pb-2 border-b-[1.5px] border-line font-semibold">
                  Condition
                </th>

                <th className="pb-2 border-b-[1.5px] border-line font-semibold">
                  Status
                </th>

                <th className="pb-2 border-b-[1.5px] border-line font-semibold">
                  Due Date
                </th>

                {!isAdmin && (
                  <th className="pb-2 border-b-[1.5px] border-line" />
                )}
              </tr>
            </thead>

            <tbody>
              {book.copies.map((copy) => {
                const late =
                  copy.status === "Borrowed"
                    ? overdueDays(copy.dueDate)
                    : 0;

                return (
                  <tr
                    key={copy._id}
                    className="text-[13.5px] border-b border-line"
                  >
                    <td className="py-2.5">{copy.barcode}</td>
                    <td className="py-2.5">{copy.shelf}</td>
                    <td className="py-2.5">{copy.condition}</td>

                    <td className="py-2.5">
                      <span
                        className={`badge ${
                          copy.status === "Available"
                            ? "badge-available"
                            : copy.status === "Borrowed" ||
                                copy.status === "Reserved"
                              ? "badge-borrowed"
                              : "badge-damaged"
                        }`}
                      >
                        {copy.status}
                      </span>
                    </td>

                    <td className="py-2.5">
                      {copy.status === "Borrowed" ? (
                        <span
                          className={
                            late > 0 ? "text-danger font-bold" : ""
                          }
                        >
                          {copy.dueDate
                            ? new Date(copy.dueDate).toLocaleDateString()
                            : "—"}

                          {late > 0 && ` (${late}d late)`}
                        </span>
                      ) : (
                        "—"
                      )}
                    </td>

                    {!isAdmin && (
                      <td className="py-2.5">
                        {copy.status === "Available" && (
                          <button
                            type="button"
                            onClick={() => void requestWithQr(copy._id)}
                            disabled={
                              qrLoadingCopyId === copy._id ||
                              book.copies.some(
                                (item) =>
                                  item.status === "Borrowed" &&
                                  item.borrowedBy === user?.id
                              )
                            }
                            className="whitespace-nowrap rounded-lg bg-primary px-3 py-2 text-xs font-bold text-white disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            {qrLoadingCopyId === copy._id
                              ? "Generating QR…"
                              : "Request with QR"}
                          </button>
                        )}

                        {copy.status === "Borrowed" &&
                          copy.borrowedBy === user?.id && (
                            <button
                              type="button"
                              onClick={() => void returnCopy(copy._id)}
                              className="bg-gold-500 rounded-lg px-4 py-1.5 text-[12.5px] font-semibold text-[#2A1B00]"
                            >
                              Return
                            </button>
                          )}

                        {copy.status === "Borrowed" &&
                          copy.borrowedBy !== user?.id && (
                            <span className="text-ink-600">Borrowed</span>
                          )}

                        {(copy.status === "Damaged" ||
                          copy.status === "Lost") && (
                          <span className="text-ink-600">N/A</span>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>

          {!isAdmin &&
            (availableCount === 0 || book.waitlist.length > 0) && (
              <div className="bg-surface rounded-2xl p-5 mt-6 max-w-[640px]">
                <h4 className="font-heading font-bold text-sm mb-2">
                  Waitlist
                </h4>

                {availableCount > 0 ? (
                  <p className="text-[13px] text-ink-600 mb-3">
                    {book.waitlist.length}{" "}
                    {book.waitlist.length === 1
                      ? "person is"
                      : "people are"}{" "}
                    on the waitlist, but copies are available right now.
                  </p>
                ) : book.waitlist.length === 0 ? (
                  <p className="text-[13px] text-ink-600 mb-3">
                    All copies are currently borrowed. Be the first to join
                    the waitlist.
                  </p>
                ) : (
                  <p className="text-[13px] text-ink-600 mb-3">
                    All copies are currently borrowed. {book.waitlist.length}{" "}
                    {book.waitlist.length === 1
                      ? "person is"
                      : "people are"}{" "}
                    waiting.
                  </p>
                )}

                {availableCount === 0 &&
                  (inWaitlistIndex >= 0 ? (
                    <>
                      <p className="text-[13px] mb-2.5">
                        You&apos;re <b>#{inWaitlistIndex + 1}</b> in line.
                      </p>

                      <button
                        type="button"
                        onClick={() => void leaveWaitlist()}
                        className="border-[1.5px] border-danger text-danger rounded-lg px-4 py-2 text-[13px] font-bold"
                      >
                        Leave Waitlist
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void joinWaitlist()}
                      className="bg-gold-500 rounded-lg px-4 py-2 text-[13px] font-bold text-[#2A1B00]"
                    >
                      Join Waitlist
                    </button>
                  ))}
              </div>
            )}

          {/* SUGGESTIONS - shown right under the copies once the reader likes the book */}
          {!isAdmin && liked && (
            <section className="mt-9" aria-labelledby="book-suggestions-heading">
              <h3
                id="book-suggestions-heading"
                className="text-[17px] font-heading font-bold mb-1"
              >
                You liked this — you might also enjoy
              </h3>

              {suggestionsError ? (
                <p className="text-danger text-[13.5px]" role="alert">
                  {suggestionsError}
                </p>
              ) : suggestionsLoading ? (
                <RowSkeletons count={2} />
              ) : suggestions.length === 0 ? (
                <button
                  type="button"
                  onClick={() => void loadSuggestions()}
                  className="mt-2 rounded-lg border border-line bg-card px-4 py-2 text-sm font-semibold"
                >
                  Show suggestions
                </button>
              ) : (
                <div className="grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-4 mt-3">
                  {suggestions.map((suggestion, index) => (
                    <button
                      key={suggestion._id}
                      type="button"
                      onClick={() => navigate(`/books/${suggestion._id}`)}
                      className="text-left bg-card border border-line rounded-xl p-3"
                    >
                      <BookCover
                        book={suggestion}
                        index={index}
                        className="h-[150px] rounded-lg text-3xl mb-2"
                      />

                      <div className="font-semibold text-[13px] leading-snug">
                        {suggestion.title}
                      </div>

                      <div className="text-[12px] text-ink-600">
                        {suggestion.author}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </section>
          )}

          {/* RATINGS & REVIEWS - everyone reads; admins can edit / delete */}
          <section className="mt-9" aria-labelledby="book-reviews-heading">
            <h3
              id="book-reviews-heading"
              className="text-[17px] font-heading font-bold mb-3"
            >
              Ratings &amp; Reviews
            </h3>

            <BookReviewsPanel
              key={`${book._id}-${reviewsVersion}`}
              bookId={book._id}
              isAdmin={isAdmin}
              onStatsChange={({ rating, ratingCount }) =>
                setBook((current) =>
                  current ? { ...current, rating, ratingCount } : current
                )
              }
            />
          </section>

          {/* BOOK HIGHLIGHTS - short quotes readers loved */}
          <section className="mt-9" aria-labelledby="book-quotes-heading">
            <h3
              id="book-quotes-heading"
              className="text-[17px] font-heading font-bold mb-1"
            >
              Highlights from this Book
            </h3>

            <BookQuotes bookId={book._id} isAdmin={isAdmin} />
          </section>

          {/* DISCUSSION ROOM - readers talk about the book */}
          <section className="mt-9" aria-labelledby="book-discussions-heading">
            <h3
              id="book-discussions-heading"
              className="text-[17px] font-heading font-bold mb-1"
            >
              Discussion Room
            </h3>

            <DiscussionRoom bookId={book._id} isAdmin={isAdmin} />
          </section>
        </div>
      </div>

      {!isAdmin && qrRequest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-5">
          <div
            className="modal-panel w-full max-w-[360px] rounded-2xl p-7 text-center shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <h2 className="font-heading font-bold text-xl mb-1">
              Your request is ready
            </h2>

            <p className="text-[13.5px] text-ink-600 mb-4">
              Show this QR to the librarian to collect{" "}
              <b className="text-ink-900">{book.title}</b>.
              {qrRequest.expiresAt &&
                ` Valid until ${new Date(
                  qrRequest.expiresAt
                ).toLocaleString()}.`}
            </p>

            <div className="flex justify-center mb-4">
              {qrRequest.token ? (
                <RequestQR token={qrRequest.token} />
              ) : (
                <p className="text-danger text-sm">QR token is missing.</p>
              )}
            </div>

            <div className="flex gap-2 justify-center">
              <button
                type="button"
                onClick={() => void cancelQrRequest()}
                className="border border-line rounded-full px-5 py-2 font-semibold text-sm text-danger"
              >
                Cancel request
              </button>

              <button
                type="button"
                onClick={() => setQrRequest(null)}
                className="bg-gold-500 rounded-full px-5 py-2 font-bold text-sm text-[#2A1B00]"
              >
                Done
              </button>
            </div>

            <p className="text-[12px] text-ink-600 mt-3 mb-0">
              You can find this QR again under My Account.
            </p>
          </div>
        </div>
      )}

      {!isAdmin && returningCopy && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-5">
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="reader-note-title"
            className="modal-panel w-full max-w-[440px] rounded-2xl border border-line p-6 shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <h2
              id="reader-note-title"
              className="mb-2 font-heading text-xl font-bold"
            >
              Leave a note for the next reader
            </h2>

            <p className="mb-4 text-sm text-ink-600">
              Share a short suggestion or opinion. This replaces the previous
              note so there is only one note per title.
            </p>

            <textarea
              autoFocus
              value={readerNote}
              onChange={(event) => setReaderNote(event.target.value)}
              maxLength={500}
              rows={4}
              placeholder="What would you like the next reader to know?"
              className="w-full resize-none rounded-xl border border-line bg-field px-4 py-3 text-sm text-ink-900 outline-none focus:border-primary"
            />

            <div className="mt-4 flex justify-end gap-3">
              <button
                type="button"
                disabled={noteSaving}
                onClick={() => setReturningCopy(null)}
                className="rounded-full border border-line px-5 py-2 text-sm font-semibold"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={noteSaving || !readerNote.trim()}
                onClick={() => void submitReturn()}
                className="rounded-full bg-primary px-5 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                {noteSaving ? "Returning…" : "Return book"}
              </button>
            </div>
          </section>
        </div>
      )}

      {!isAdmin && ratingModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-5">
          <div
            className="modal-panel w-full max-w-[440px] rounded-2xl p-7 shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <div className="text-center">
              <h2 className="font-heading font-bold text-xl mb-2">
                Rate this book
              </h2>

              <p className="text-[13.5px] text-ink-600 mb-6">
                You have returned{" "}
                <b className="text-ink-900">{book.title}</b>. How would you
                rate it?
              </p>

              <div className="flex justify-center gap-2 mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => handleStarClick(star)}
                    className={`text-4xl transition-transform hover:scale-110 focus:outline-none ${
                      star <= selectedRating
                        ? "text-gold-500"
                        : "text-ink-600"
                    }`}
                    aria-label={`Rate ${star} out of 5`}
                  >
                    {star <= selectedRating ? "★" : "☆"}
                  </button>
                ))}
              </div>

              <div className="text-left mb-5">
                <label className="block text-sm font-semibold mb-2">
                  Your review
                  <span className="text-ink-600 font-normal">
                    {" "}
                    (optional)
                  </span>
                </label>

                <textarea
                  value={review}
                  onChange={(event) => setReview(event.target.value)}
                  placeholder="Write something about this book..."
                  maxLength={500}
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl border border-line-strong bg-field text-[14px] outline-none focus:border-blue-500 resize-none"
                />

                <div className="text-right text-[11px] text-ink-600 mt-1">
                  {review.length}/500
                </div>
              </div>

              <div className="flex gap-3 justify-center">
                <button
                  type="button"
                  onClick={() => {
                    setRatingModal(false);
                    setSelectedRating(0);
                    setReview("");
                  }}
                  className="border border-line rounded-full px-5 py-2.5 text-sm font-semibold"
                >
                  Maybe Later
                </button>

                <button
                  type="button"
                  onClick={() => void submitRating()}
                  disabled={selectedRating === 0 || ratingLoading}
                  className="bg-primary text-white rounded-full px-6 py-2.5 text-sm font-bold disabled:opacity-50"
                >
                  {ratingLoading ? "Submitting..." : "Submit Rating"}
                </button>
              </div>

              <p className="text-[11.5px] text-ink-600 mt-5">
                You can rate this book only once.
              </p>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-primary text-white px-6 py-3 rounded-full text-sm font-semibold shadow-xl max-w-[90vw] text-center">
          {toast}
        </div>
      )}
    </div>
  );
}