import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import Select from "react-select";
import { TableRowSkeletons } from "../components/BookSkeletons";
import api from "../api/axios";

interface User {
  _id: string;
  name: string;
  email: string;
  phone?: string;
  role?: "member" | "admin";
  isBlocked?: boolean;
}

interface UsersResponse {
  users: User[];
  totalUsers: number;
  totalPages: number;
  currentPage: number;
  limit: number;
}

interface UserForm {
  name: string;
  email: string;
  phone: string;
}

const PAGE_SIZE = 10;

type StatusFilter = "" | "active" | "blocked";

interface StatusOption {
  value: StatusFilter;
  label: string;
}

const statusOptions: StatusOption[] = [
  { value: "", label: "All users" },
  { value: "active", label: "Active" },
  { value: "blocked", label: "Blocked" },
];

const statusSelectStyles = {
  control: (base: any, state: any) => ({
    ...base,
    minHeight: "46px",
    minWidth: "180px",
    borderRadius: "12px",
    backgroundColor: "rgb(var(--field))",
    borderColor: state.isFocused ? "rgb(var(--primary))" : "rgb(var(--line))",
    boxShadow: "none",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: 500,
    ":hover": { borderColor: "rgb(var(--primary))" },
  }),
  valueContainer: (base: any) => ({ ...base, paddingLeft: "14px" }),
  singleValue: (base: any) => ({ ...base, color: "rgb(var(--ink-900))" }),
  dropdownIndicator: (base: any) => ({
    ...base,
    color: "rgb(var(--ink-900))",
    paddingRight: "12px",
  }),
  clearIndicator: (base: any) => ({
    ...base,
    cursor: "pointer",
    padding: "6px",
    color: "rgb(var(--ink-600))",
    ":hover": { color: "rgb(var(--ink-900))" },
  }),
  indicatorSeparator: () => ({ display: "none" }),
  menu: (base: any) => ({
    ...base,
    marginTop: "6px",
    borderRadius: "10px",
    overflow: "hidden",
    backgroundColor: "rgb(var(--card))",
    border: "1px solid rgb(var(--line))",
    boxShadow: "0 18px 36px rgba(0, 0, 0, 0.38)",
  }),
  menuPortal: (base: any) => ({ ...base, zIndex: 9999 }),
  menuList: (base: any) => ({ ...base, padding: "5px" }),
  option: (base: any, state: any) => ({
    ...base,
    borderRadius: "7px",
    padding: "10px 12px",
    fontSize: "14px",
    fontWeight: state.isSelected ? 600 : 500,
    color: state.isSelected ? "#ffffff" : "rgb(var(--ink-900))",
    backgroundColor: state.isSelected
      ? "rgb(var(--primary))"
      : state.isFocused
        ? "rgba(56, 189, 248, 0.14)"
        : "transparent",
    cursor: "pointer",
  }),
};

export default function Users() {
  const [users, setUsers] = useState<User[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [totalUsers, setTotalUsers] = useState(0);

  const [searchText, setSearchText] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [form, setForm] = useState<UserForm>({
    name: "",
    email: "",
    phone: "",
  });

  const [saving, setSaving] = useState(false);
  const [actionUserId, setActionUserId] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<{ user: User; kind: "block" | "unblock" | "delete" } | null>(null);
  const requestIdRef = useRef(0);
  // Automatically dismiss success and error messages after 3 seconds
useEffect(() => {
  if (!notice && !error) return;

  const timer = window.setTimeout(() => {
    setNotice("");
    setError("");
  }, 3000);

  return () => window.clearTimeout(timer);
}, [notice, error]);

  const loadUsers = useCallback(
    async (page: number, searchValue: string, status: StatusFilter) => {
      const requestId = ++requestIdRef.current;
      const startedAt = Date.now();
      try {
        setLoading(true);
        setError("");

        const { data } = await api.get<UsersResponse>("/users", {
          params: {
            page,
            search: searchValue,
            ...(status ? { status } : {}),
          },
        });

        if (requestId === requestIdRef.current) {
          setUsers(data.users ?? []);
          setCurrentPage(data.currentPage ?? page);
          setTotalPages(data.totalPages ?? 0);
          setTotalUsers(data.totalUsers ?? 0);
        }
      } catch (err: unknown) {
        const message =
          (err as { response?: { data?: { message?: string } } })
            ?.response?.data?.message;

        if (requestId === requestIdRef.current) setError(message || "Failed to load users.");
      } finally {
        const remaining = Math.max(0, 2000 - (Date.now() - startedAt));
        if (remaining) await new Promise((resolve) => setTimeout(resolve, remaining));
        if (requestId === requestIdRef.current) setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    void loadUsers(currentPage, search, statusFilter);
  }, [currentPage, search, statusFilter, loadUsers]);

  useEffect(() => {
  const value = searchText.trim();

  if (value.length < 3) {
    if (search !== "") {
      setSearch("");
      setCurrentPage(1);
    }
    return;
  }

  if (value === search) return;

  const timer = window.setTimeout(() => {
    setError("");
    setNotice("");
    setSearch(value);
    setCurrentPage(1);
  }, 350);

  return () => window.clearTimeout(timer);
}, [searchText, search]);

  function handleSearchChange(value: string) {
    setSearchText(value);
  }

  function handleStatusChange(value: StatusFilter) {
    if (value === statusFilter) return;
    setError("");
    setNotice("");
    setStatusFilter(value);
    setCurrentPage(1);
  }

  function goToPage(page: number) {
    if (page < 1 || page > totalPages || page === currentPage) {
      return;
    }

    setCurrentPage(page);
  }

  function getPageNumbers() {
    const pages: number[] = [];

    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
      return pages;
    }

    pages.push(1);

    if (currentPage > 3) pages.push(-1);

    for (
      let i = Math.max(2, currentPage - 1);
      i <= Math.min(totalPages - 1, currentPage + 1);
      i++
    ) {
      pages.push(i);
    }

    if (currentPage < totalPages - 2) pages.push(-1);

    pages.push(totalPages);

    return pages;
  }

  function openEdit(user: User) {
    setEditingUser(user);
    setForm({
      name: user.name,
      email: user.email,
      phone: user.phone || "",
    });
    setError("");
    setNotice("");
  }

  async function saveUser(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!editingUser) return;

    if (!form.name.trim() || !form.email.trim()) {
      setError("Name and email are required.");
      return;
    }

    try {
      setSaving(true);
      setError("");
      setNotice("");

      await api.patch(`/users/${editingUser._id}`, {
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
      });

      setEditingUser(null);
      setNotice("User updated successfully.");
      await loadUsers(currentPage, search, statusFilter);
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { message?: string } } })
          ?.response?.data?.message;

      setError(message || "Failed to update user.");
    } finally {
      setSaving(false);
    }
  }

  async function toggleBlock(user: User, nextBlocked: boolean) {
    if (actionUserId) return;
    const action = nextBlocked ? "block" : "unblock";
    try {
      setActionUserId(user._id);
      setError("");
      setNotice("");

      await api.patch(`/users/${user._id}/block`, {
        isBlocked: nextBlocked,
      });

      setNotice(
        `${user.name} has been ${nextBlocked ? "blocked" : "unblocked"}.`
      );

      await loadUsers(currentPage, search, statusFilter);
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { message?: string } } })
          ?.response?.data?.message;

      setError(message || `Failed to ${action} user.`);
    } finally {
      setActionUserId(null);
    }
  }

  async function deleteUser(user: User) {
    if (actionUserId) return;
    try {
      setActionUserId(user._id);
      setError("");
      setNotice("");

      await api.delete(`/users/${user._id}`);

      const nextTotal = Math.max(0, totalUsers - 1);
      const nextPages = Math.ceil(nextTotal / PAGE_SIZE);
      const nextPage = Math.min(currentPage, Math.max(1, nextPages));

      setNotice(`${user.name} has been deleted.`);
      if (nextPage !== currentPage) {
        setCurrentPage(nextPage); // the page effect performs the single refresh
      } else {
        await loadUsers(nextPage, search, statusFilter);
      }
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { message?: string } } })
          ?.response?.data?.message;

      setError(message || "Failed to delete user.");
    } finally {
      setActionUserId(null);
    }
  }

  const startUser =
    totalUsers === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1;

  const endUser = Math.min(currentPage * PAGE_SIZE, totalUsers);

  return (
    <div className="library-page users-page">
      <div className="library-page-heading mb-6">
        <div className="library-eyebrow">COMMUNITY MANAGEMENT</div>

        <h1 className="m-0 mb-1.5 font-heading text-2xl font-bold">
          Users
        </h1>

        <p className="m-0 text-[14.5px] text-ink-600">
          Manage registered users
        </p>
      </div>

      <div className="users-toolbar mb-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-3 md:max-w-[640px]">
          <div className="flex min-w-[220px] flex-1 items-center rounded-xl border border-line bg-field px-4 py-2.5">
          <input
            type="text"
            name="user-directory-search"
            autoComplete="new-password"
            autoCorrect="off"
            spellCheck={false}
            value={searchText}
            onChange={(event) => handleSearchChange(event.target.value)}
            placeholder="Search users by name or email..."
            aria-label="Search users"
            className="min-w-0 flex-1 border-none bg-transparent text-sm text-ink-900 outline-none"
          />
          {searchText && (
            <button type="button" onClick={() => handleSearchChange("")} aria-label="Clear user search" className="users-clear-btn ml-2 flex h-7 w-7 items-center justify-center rounded-full text-lg">×</button>
          )}
        </div>

          <div className="min-w-[180px]">
          <Select<StatusOption, false>
            value={statusOptions.find((o) => o.value === statusFilter)}
            options={statusOptions}
            styles={statusSelectStyles}
            menuPortalTarget={document.body}
            menuPosition="fixed"
            isSearchable={false}
            isClearable={Boolean(statusFilter)}
            aria-label="Filter users by status"
            onChange={(option) => handleStatusChange(option?.value ?? "")}
          />
        </div>
        </div>

        <div className="rounded-xl border border-line bg-card px-4 py-3 text-sm text-ink-600">
          Total users:{" "}
          <strong className="text-ink-900">{totalUsers}</strong>
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="mb-4 rounded-xl border border-danger bg-danger-bg px-4 py-3 text-sm text-danger"
        >
          {error}
        </div>
      )}

      {notice && (
        <div
          role="status"
          className="mb-4 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-sm text-emerald-800"
        >
          {notice}
        </div>
      )}

      <div className="overflow-hidden rounded-2xl border border-line bg-card">
        {loading ? (
          <TableRowSkeletons count={6} />
        ) : users.length === 0 ? (
          <div className="library-empty-state py-16 text-center text-sm text-ink-600">
            <span>✧</span>
            <strong>No members found</strong>
            <p>Try a different name, email or status filter.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-surface text-left">
                  <th className="border-b border-line px-5 py-4 text-[13px] font-bold text-ink-900">
                    User
                  </th>
                  <th className="border-b border-line px-5 py-4 text-[13px] font-bold text-ink-900">
                    Email
                  </th>
                  <th className="border-b border-line px-5 py-4 text-[13px] font-bold text-ink-900">
                    Status
                  </th>
                  <th className="border-b border-line px-5 py-4 text-[13px] font-bold text-ink-900">
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {users.map((user) => (
                  <tr
                    key={user._id}
                    className="border-b border-line transition last:border-b-0 hover:bg-surface/60"
                  >
                    <td className="px-5 py-4 text-sm font-semibold text-ink-900">
                      {user.name}

                      {user.role === "admin" && (
                        <span className="ml-2 rounded-full bg-blue-100 px-2 py-1 text-[10px] font-bold text-blue-800">
                          ADMIN
                        </span>
                      )}
                    </td>

                    <td className="px-5 py-4 text-sm text-ink-600">
                      {user.email}
                    </td>

                    <td className="px-5 py-4">
                      <span
                        className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                          user.isBlocked
                            ? "bg-red-100 text-red-700"
                            : "bg-emerald-100 text-emerald-700"
                        }`}
                      >
                        {user.isBlocked ? "Blocked" : "Active"}
                      </span>
                    </td>

                    <td className="px-5 py-4">
                      {user.role === "admin" ? (
                        <span className="text-xs text-ink-600">
                          Admin account protected
                        </span>
                      ) : (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => openEdit(user)}
                            title="Edit user"
                            aria-label={`Edit ${user.name}`}
                            className="flex h-9 w-9 items-center justify-center rounded-lg border border-line text-ink-900 transition hover:border-blue-400 hover:bg-blue-500/10 hover:text-blue-500"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="18"
                              height="18"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="1.8"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M12 20h9" />
                              <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z" />
                            </svg>
                          </button>

                          <button
                            type="button"
                            disabled={actionUserId === user._id}
                            onClick={() => setConfirmAction({ user, kind: user.isBlocked ? "unblock" : "block" })}
                            title={user.isBlocked ? "Unblock user" : "Block user"}
                            aria-label={`${user.isBlocked ? "Unblock" : "Block"} ${user.name}`}
                            className={`flex h-9 w-9 items-center justify-center rounded-lg border transition disabled:cursor-not-allowed disabled:opacity-50 ${
                              user.isBlocked
                                ? "border-emerald-400/60 text-emerald-500 hover:bg-emerald-500/10"
                                : "border-amber-400/70 text-amber-500 hover:bg-amber-500/10"
                            }`}
                          >
                            {user.isBlocked ? (
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="1.8"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              >
                                <rect x="3" y="11" width="18" height="10" rx="2" />
                                <path d="M7 11V7a5 5 0 0 1 10 0" />
                              </svg>
                            ) : (
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="1.8"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              >
                                <circle cx="12" cy="12" r="10" />
                                <path d="m4.9 4.9 14.2 14.2" />
                              </svg>
                            )}
                          </button>

                          <button
                            type="button"
                            disabled={actionUserId === user._id}
                            onClick={() => setConfirmAction({ user, kind: "delete" })}
                            title="Delete user"
                            aria-label={`Delete ${user.name}`}
                            className="flex h-9 w-9 items-center justify-center rounded-lg border border-red-400/60 text-red-500 transition hover:bg-red-500/10 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="18"
                              height="18"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="1.8"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M3 6h18" />
                              <path d="M8 6V4h8v2" />
                              <path d="m19 6-1 14H6L5 6" />
                              <path d="M10 11v5M14 11v5" />
                            </svg>
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {!loading && totalUsers > 0 && (
        <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
          <p className="m-0 text-[13px] text-ink-600">
            Showing{" "}
            <span className="font-semibold text-ink-900">
              {startUser}-{endUser}
            </span>{" "}
            of{" "}
            <span className="font-semibold text-ink-900">
              {totalUsers}
            </span>{" "}
            users
          </p>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => goToPage(currentPage - 1)}
              disabled={currentPage === 1}
              className="rounded-lg border border-line px-3 py-2 text-[13px] font-semibold text-ink-900 transition hover:bg-surface disabled:cursor-not-allowed disabled:opacity-40"
            >
              ← Previous
            </button>

            {getPageNumbers().map((page, index) =>
              page === -1 ? (
                <span
                  key={`dots-${index}`}
                  className="px-1.5 text-sm text-ink-600"
                >
                  ...
                </span>
              ) : (
                <button
                  key={page}
                  type="button"
                  onClick={() => goToPage(page)}
                  className={`h-[38px] min-w-[38px] rounded-lg text-[13px] font-semibold transition ${
                    currentPage === page
                      ? "bg-primary text-white"
                      : "border border-line text-ink-900 hover:bg-surface"
                  }`}
                >
                  {page}
                </button>
              )
            )}

            <button
              type="button"
              onClick={() => goToPage(currentPage + 1)}
              disabled={currentPage >= totalPages}
              className="rounded-lg border border-line px-3 py-2 text-[13px] font-semibold text-ink-900 transition hover:bg-surface disabled:cursor-not-allowed disabled:opacity-40"
            >
              Next →
            </button>
          </div>
        </div>
      )}

      {confirmAction && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-950/75 p-4">
          <section role="alertdialog" aria-modal="true" aria-labelledby="user-action-title" className="modal-panel w-full max-w-md rounded-2xl border border-line p-6 shadow-2xl" style={{ backgroundColor: "rgb(var(--card))" }}>
            <h2 id="user-action-title" className="font-heading text-lg font-bold text-ink-900">{confirmAction.kind === "delete" ? "Delete this user?" : `${confirmAction.kind === "block" ? "Block" : "Unblock"} this user?`}</h2>
            <p className="mt-2 text-sm text-ink-600">{confirmAction.kind === "delete" ? `Delete ${confirmAction.user.name} permanently? This action cannot be undone.` : `Are you sure you want to ${confirmAction.kind} ${confirmAction.user.name}?`}</p>
            <div className="mt-6 flex justify-between gap-3">
              <button type="button" onClick={() => setConfirmAction(null)} className="rounded-xl border border-line px-5 py-2.5 text-sm font-semibold text-ink-900 hover:bg-surface">Cancel</button>
              <button type="button" disabled={actionUserId === confirmAction.user._id} onClick={() => {
                const action = confirmAction;
                setConfirmAction(null);
                if (action.kind === "delete") void deleteUser(action.user);
                else void toggleBlock(action.user, action.kind === "block");
              }} className={`rounded-xl px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50 ${confirmAction.kind === "delete" ? "bg-red-600 hover:bg-red-700" : "bg-primary hover:bg-primary-hover"}`}>{actionUserId === confirmAction.user._id ? "Please wait…" : "OK"}</button>
            </div>
          </section>
        </div>
      )}

      {editingUser && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-slate-950/60 p-4"
          style={{ backgroundColor: "rgba(2, 8, 23, .88)" }}
          onMouseDown={(event) => {
            if (event.target === event.currentTarget && !saving) {
              setEditingUser(null);
            }
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="edit-user-title"
            className="modal-panel my-auto w-full max-w-lg rounded-2xl border border-line p-6 shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <div className="mb-5 flex items-start justify-between gap-4">
              <div>
                <p className="library-eyebrow">USER MANAGEMENT</p>
                <h2
                  id="edit-user-title"
                  className="font-heading text-xl font-bold text-ink-900"
                >
                  Edit user
                </h2>
                <p className="mt-1 text-sm text-ink-600">
                  Update this user's profile details.
                </p>
              </div>

              <button
                type="button"
                disabled={saving}
                onClick={() => setEditingUser(null)}
                aria-label="Close edit form"
                className="rounded-lg px-3 py-1 text-xl text-ink-600 hover:bg-surface disabled:opacity-50"
              >
                ×
              </button>
            </div>

            <form onSubmit={saveUser} className="space-y-4">
              <div>
                <label
                  htmlFor="edit-user-name"
                  className="mb-1.5 block text-sm font-semibold text-ink-900"
                >
                  Full name
                </label>
                <input
                  id="edit-user-name"
                  required
                  maxLength={100}
                  value={form.name}
                  onChange={(event) =>
                    setForm({ ...form, name: event.target.value })
                  }
                  className="w-full rounded-xl border border-line bg-card px-4 py-3 text-sm text-ink-900 outline-none focus:border-primary"
                />
              </div>

              <div>
                <label
                  htmlFor="edit-user-email"
                  className="mb-1.5 block text-sm font-semibold text-ink-900"
                >
                  Email address
                </label>
                <input
                  id="edit-user-email"
                  type="email"
                  required
                  maxLength={254}
                  value={form.email}
                  onChange={(event) =>
                    setForm({ ...form, email: event.target.value })
                  }
                  className="w-full rounded-xl border border-line bg-card px-4 py-3 text-sm text-ink-900 outline-none focus:border-primary"
                />
              </div>

              <div>
                <label
                  htmlFor="edit-user-phone"
                  className="mb-1.5 block text-sm font-semibold text-ink-900"
                >
                  Phone (optional)
                </label>
                <input
                  id="edit-user-phone"
                  type="tel"
                  maxLength={30}
                  value={form.phone}
                  onChange={(event) =>
                    setForm({ ...form, phone: event.target.value })
                  }
                  className="w-full rounded-xl border border-line bg-card px-4 py-3 text-sm text-ink-900 outline-none focus:border-primary"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => setEditingUser(null)}
                  className="rounded-xl border border-line px-4 py-2.5 text-sm font-semibold text-ink-900 hover:bg-surface disabled:opacity-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-hover disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {saving ? "Saving…" : "Save changes"}
                </button>
              </div>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}
