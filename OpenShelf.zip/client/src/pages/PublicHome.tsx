import { MouseEvent, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import ThemeToggle from "../components/ThemeToggle";

const heroSlides = [
  {
    eyebrow: "A library that moves with you",
    lines: ["Stories worth", "finding.", "Space to grow."],
    accent: 2,
    description: "Discover your next favourite, keep your reading life in order, and make every visit to the library feel like the start of something.",
    action: "Start exploring",
    note: "Find your next favourite",
    caption: "Every story starts somewhere",
  },
  {
    eyebrow: "Your next chapter is closer",
    lines: ["One shelf.", "More stories.", "More wonder."],
    accent: 1,
    description: "Search by title or author, find an available copy, and make a little room for a book you will remember.",
    action: "Browse the shelves",
    note: "A new world, one page away",
    caption: "Pick up where curiosity leads",
  },
  {
    eyebrow: "The joy is in the journey",
    lines: ["Find a little", "wonder in", "every visit."],
    accent: 2,
    description: "Borrow, return, join a waitlist, and keep your reading life together in one calm, welcoming place.",
    action: "Make it yours",
    note: "Your reading life, in order",
    caption: "Keep your place in every story",
  },
];

// Nav links: drop focus so no ring stays on the link, pause for a moment, then
// glide down to the section (the sticky header hides itself while scrolling down).
const NAV_SCROLL_DELAY_MS = 300;
const NAV_SCROLL_DURATION_MS = 1100;
let navScrollFrame = 0;

function goToSection(event: MouseEvent<HTMLAnchorElement>, id: string) {
  event.preventDefault();
  event.currentTarget.blur();

  window.setTimeout(() => {
    const target = document.getElementById(id);
    if (!target) return;

    cancelAnimationFrame(navScrollFrame);
    const startY = window.scrollY;
    const maxY = document.documentElement.scrollHeight - window.innerHeight;
    // "About" lives in the footer, so scroll all the way down for it.
    const endY = id === "about"
      ? maxY
      : Math.min(maxY, Math.max(0, target.getBoundingClientRect().top + startY - 24));

    if (Math.abs(endY - startY) < 2) return;

    // Always a visible glide (not skipped for reduced-motion) so the page
    // scrolls to the section instead of jumping straight to it.
    const startTime = performance.now();
    const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
    const step = (now: number) => {
      const progress = Math.min(1, (now - startTime) / NAV_SCROLL_DURATION_MS);
      window.scrollTo({ top: startY + (endY - startY) * ease(progress), behavior: "instant" as ScrollBehavior });
      if (progress < 1) navScrollFrame = requestAnimationFrame(step);
    };
    navScrollFrame = requestAnimationFrame(step);
  }, NAV_SCROLL_DELAY_MS);
}

export default function PublicHome() {
  const [activeSlide, setActiveSlide] = useState(0);
  const [paused, setPaused] = useState(false);
  const [headerVisible, setHeaderVisible] = useState(true);
  const previousScrollY = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentY = window.scrollY;
      const nextVisible = currentY < 80 || currentY < previousScrollY.current;
      setHeaderVisible((visible) => visible === nextVisible ? visible : nextVisible);
      previousScrollY.current = currentY;
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const sections = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) {
      sections.forEach((section) => section.classList.add("is-visible"));
      return;
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        // Toggle visibility on both enter and exit so the reveal animation
        // plays again each time the visitor scrolls back to a section.
        entry.target.classList.toggle("is-visible", entry.isIntersecting);
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -45px 0px" });

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (paused || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => {
      setActiveSlide((current) => (current + 1) % heroSlides.length);
    }, 6500);
    return () => window.clearInterval(timer);
  }, [paused]);

  return (
    <main className="public-home min-h-screen overflow-x-clip text-slate-900">
      <header className={`landing-nav sticky top-0 z-50 mx-auto flex max-w-7xl items-center justify-between px-6 py-5 sm:px-10 lg:px-14 ${headerVisible ? "landing-nav-visible" : "landing-nav-hidden"}`}>
        <Link to="/" className="flex items-center gap-3 text-blue-950">
          <span className="brand-mark brand-mark-small"><BookIcon /></span>
          <span className="font-heading text-xl font-bold tracking-tight">openshelf</span>
        </Link>
        <nav className="hidden items-center gap-8 text-sm font-medium text-blue-950/70 md:flex" aria-label="Main navigation">
          <a href="#discover" onClick={(event) => goToSection(event, "discover")} className="transition hover:text-sky-600">Discover</a>
          <a href="#how-it-works" onClick={(event) => goToSection(event, "how-it-works")} className="transition hover:text-sky-600">How it works</a>
          <a href="#about" onClick={(event) => goToSection(event, "about")} className="transition hover:text-sky-600">About</a>
        </nav>
        <div className="flex items-center gap-3">
          <ThemeToggle className="landing-theme-toggle" />
          <Link to="/login" className="landing-signin hidden rounded-full px-4 py-2.5 text-sm font-semibold text-blue-950 transition hover:bg-white/60 sm:inline-flex">Sign in</Link>
          <Link to="/register" className="rounded-full bg-blue-950 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-950/15 transition hover:bg-sky-700">Join Openshelf</Link>
        </div>
      </header>

      <section onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocusCapture={() => setPaused(true)} onBlurCapture={() => setPaused(false)} className="landing-hero relative mx-auto grid min-h-[620px] max-w-7xl items-center gap-12 px-6 pb-16 pt-8 sm:px-10 lg:min-h-[690px] lg:grid-cols-[.95fr_1.05fr] lg:px-14 lg:pb-24">
        <div className="relative z-10 max-w-xl">
          <div className="hero-slide-window" aria-label="Openshelf highlights">
            <div className="hero-slide-track" style={{ transform: `translate3d(-${(activeSlide * 100) / heroSlides.length}%, 0, 0)` }}>
              {heroSlides.map((slide, index) => (
                <article className="hero-copy-slide" key={slide.eyebrow} aria-hidden={index !== activeSlide}>
                  <span className="hero-eyebrow mb-6 inline-flex items-center gap-2 rounded-full border border-sky-200 bg-white/55 px-4 py-2 text-xs font-semibold uppercase tracking-[.16em] text-blue-800 shadow-sm backdrop-blur">
                    <span className="eyebrow-dot h-2 w-2 rounded-full bg-sky-500" /> {slide.eyebrow}
                  </span>
                  <h1 className="font-heading text-5xl font-semibold leading-[1.02] tracking-[-.055em] sm:text-6xl lg:text-[4.65rem]">
                    {slide.lines.map((line, lineIndex) => <span key={line} className={`block ${lineIndex === slide.accent ? "hero-title-accent" : "text-blue-950"}`}>{line}</span>)}
                  </h1>
                  <p className="mt-7 max-w-md text-base leading-7 text-blue-950/65 sm:text-lg sm:leading-8">{slide.description}</p>
                  <div className="mt-9 flex flex-wrap items-center gap-4">
                    <Link tabIndex={index === activeSlide ? 0 : -1} to="/register" className="hero-primary-link rounded-full px-7 py-3.5 text-sm font-bold text-white shadow-xl shadow-blue-950/20 transition hover:-translate-y-0.5">{slide.action} <span className="ml-2">↗</span></Link>
                    <Link tabIndex={index === activeSlide ? 0 : -1} to="/login" className="hero-secondary-link rounded-full border px-7 py-3.5 text-sm font-semibold transition">I have an account</Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
          <div className="mt-12 flex items-center gap-4 text-sm text-blue-950/60">
            <div className="flex -space-x-2" aria-hidden="true"><span className="reader-dot bg-sky-300">A</span><span className="reader-dot bg-blue-300">M</span><span className="reader-dot bg-indigo-300">J</span></div>
            <span><strong className="text-blue-950">A little room for everyone.</strong><br />Readers, librarians, and curious minds.</span>
          </div>
        </div>

        <div className={`hero-art hero-art-slide-${activeSlide} relative mx-auto flex h-[390px] w-full max-w-[570px] items-center justify-center sm:h-[490px] lg:h-[560px]`} aria-label="Illustration of an open book surrounded by soft blue shapes" role="img">
          <div className="hero-halo" />
          <div className="hero-glass hero-glass-one" />
          <div className="hero-glass hero-glass-two" />
          <div className="hero-book" key={activeSlide}><BookIllustration /></div>
          <div className="floating-note floating-note-top" key={`note-${activeSlide}`}><span>✦</span> {heroSlides[activeSlide].note}</div>
          <div className="floating-note floating-note-bottom"><span>↗</span> {heroSlides[activeSlide].caption}</div>
          <span className="hero-spark spark-one">✳</span><span className="hero-spark spark-two">✦</span><span className="hero-spark spark-three">·</span>
        </div>
      </section>

      <section id="discover" data-reveal className="relative z-10 mx-auto max-w-7xl px-6 pb-14 sm:px-10 lg:px-14">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-5">
          <div>
            <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-sky-700">A good place to begin</p>
            <h2 className="font-heading text-3xl font-semibold tracking-[-.04em] text-blue-950 sm:text-4xl">A library that feels easy.</h2>
          </div>
          <p className="max-w-md text-sm leading-6 text-blue-950/60">From the first curious search to the day a book finds its next reader, Openshelf keeps the little things in order.</p>
        </div>
        <div className="feature-strip grid gap-4 md:grid-cols-3">
          <Feature number="01" title="Find the next one" copy="Explore an organized collection, search by title or author, and save a place in the waitlist." />
          <Feature number="02" title="Make it yours for a while" copy="Borrow available copies and keep due dates close, with a five-day loan period." />
          <Feature number="03" title="Always know your place" copy="See current loans, returns, fees, and reading history together in your account." />
        </div>
      </section>

      <section id="how-it-works" data-reveal className="mx-auto grid max-w-7xl items-center gap-10 px-6 py-12 sm:px-10 lg:grid-cols-[.72fr_1.28fr] lg:px-14 lg:py-20">
        <div>
          <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-sky-700">Simple by design</p>
          <h2 className="max-w-md font-heading text-3xl font-semibold leading-tight tracking-[-.04em] text-blue-950 sm:text-4xl">More time with the story. Less time managing the shelf.</h2>
          <p className="mt-5 max-w-md text-sm leading-7 text-blue-950/60">Everything you need for a smooth library visit, brought together in one calm, clear space.</p>
          <Link to="/register" className="mt-7 inline-flex items-center gap-2 font-semibold text-blue-800 transition hover:text-sky-600">Get your library started <span aria-hidden="true">↗</span></Link>
        </div>
        <div className="reading-steps">
          <Step number="1" title="Discover" copy="Search a shelf full of possibilities." />
          <Step number="2" title="Borrow" copy="Check out an available copy or join its waitlist." />
          <Step number="3" title="Keep track" copy="See due dates and reading history at a glance." />
        </div>
      </section>

      <section data-reveal className="mx-auto max-w-7xl px-6 pb-16 pt-5 sm:px-10 lg:px-14 lg:pb-24">
        <div className="closing-panel relative overflow-hidden rounded-[30px] px-7 py-10 text-white sm:px-12 sm:py-14 lg:px-16">
          <div className="relative z-10 max-w-xl">
            <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-sky-200">Your next chapter starts here</p>
            <h2 className="font-heading text-3xl font-semibold leading-tight tracking-[-.04em] sm:text-4xl">Ready to find a book that stays with you?</h2>
            <p className="mt-4 max-w-md text-sm leading-6 text-blue-100/75">Join Openshelf and make your next library visit a little more yours.</p>
            <Link to="/register" className="mt-7 inline-flex rounded-full bg-white px-6 py-3 text-sm font-bold text-blue-950 shadow-lg transition hover:-translate-y-0.5 hover:bg-sky-50">Join Openshelf <span className="ml-2">↗</span></Link>
          </div>
          <div className="closing-orbit" aria-hidden="true"><span>O</span><i /><b /></div>
        </div>
      </section>

      <footer className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-6 pb-8 text-xs text-blue-950/45 sm:px-10 lg:px-14">
        <span id="about">© Openshelf · Find a book. Find your place.</span><span>Made for the love of reading.</span>
      </footer>
    </main>
  );
}

function Feature({ number, title, copy }: { number: string; title: string; copy: string }) {
  return <article className="feature-card"><span className="feature-number">{number}</span><div><h3 className="font-heading text-lg font-semibold text-blue-950">{title}</h3><p className="mt-2 text-sm leading-6 text-blue-950/60">{copy}</p></div><span className="feature-arrow" aria-hidden="true">↗</span></article>;
}

function Step({ number, title, copy }: { number: string; title: string; copy: string }) {
  return <article className="step-card"><span className="step-number">{number}</span><div><h3 className="font-heading text-xl font-semibold text-blue-950">{title}</h3><p className="mt-2 text-sm leading-6 text-blue-950/60">{copy}</p></div></article>;
}

function BookIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 5.5c3.1-.8 5.6-.3 7.5 1.4v13c-1.9-1.7-4.4-2.2-7.5-1.4v-13Zm15 0c-3.1-.8-5.6-.3-7.5 1.4v13c1.9-1.7 4.4-2.2 7.5-1.4v-13Z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round"/><path d="M12 7v12.9" stroke="currentColor" strokeWidth="1.5"/></svg>;
}

function BookIllustration() {
  return <svg viewBox="0 0 500 380" fill="none" aria-hidden="true"><defs><linearGradient id="leftPage" x1="30" y1="80" x2="250" y2="320" gradientUnits="userSpaceOnUse"><stop stopColor="#fff"/><stop offset="1" stopColor="#DDF4FF"/></linearGradient><linearGradient id="rightPage" x1="250" y1="78" x2="460" y2="320" gradientUnits="userSpaceOnUse"><stop stopColor="#F8FDFF"/><stop offset="1" stopColor="#B9E8FF"/></linearGradient><linearGradient id="cover" x1="80" y1="75" x2="420" y2="330" gradientUnits="userSpaceOnUse"><stop stopColor="#0C2D68"/><stop offset="1" stopColor="#147CB7"/></linearGradient><filter id="bookShadow" x="15" y="20" width="470" height="360" colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse"><feGaussianBlur stdDeviation="14"/></filter></defs><ellipse cx="252" cy="324" rx="190" ry="27" fill="#123B7A" fillOpacity=".18" filter="url(#bookShadow)"/><path d="M57 99c68-32 135-27 193 13v206c-58-40-125-45-193-13V99Z" fill="url(#cover)"/><path d="M443 99c-68-32-135-27-193 13v206c58-40 125-45 193-13V99Z" fill="#072B62"/><path d="M67 108c64-26 123-19 175 17v180c-52-36-111-43-175-17V108Z" fill="url(#leftPage)"/><path d="M433 108c-64-26-123-19-175 17v180c52-36 111-43 175-17V108Z" fill="url(#rightPage)"/><path d="M242 126c5 10 10 15 8 20v159c-3-8-8-13-16-18V129l8-3Z" fill="#77C8EC"/><path d="M101 153c36-11 73-8 108 8M101 178c36-11 73-8 108 8M101 203c36-11 73-8 108 8M290 161c34-16 70-19 108-8M290 186c34-16 70-19 108-8M290 211c34-16 70-19 108-8" stroke="#78BDE0" strokeWidth="5" strokeLinecap="round"/><path d="m163 121 16 22 25-26" stroke="#31A6DE" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/><path d="M252 112v202" stroke="#123B7A" strokeOpacity=".24" strokeWidth="4"/></svg>;
}
