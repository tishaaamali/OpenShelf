
import { FormEvent, useState } from "react";
import { Link, useParams } from "react-router-dom";
import AuthShell from "../components/AuthShell";
import api from "../api/axios";

export default function ResetPassword() {
  const { token } = useParams<{ token: string }>();

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMessage("");
    setError("");

    if (!token) {
      setError("This password-reset link is invalid.");
      return;
    }

    if (password.length < 8 || password.length > 72) {
      setError("Password must be between 8 and 72 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);

    try {
      const response = await api.post(
        `/auth/reset-password/${encodeURIComponent(token)}`,
        { password }
      );

      setMessage(response.data.message);
      setSuccess(true);
      setPassword("");
      setConfirmPassword("");
    } catch (err: any) {
      setError(
        err?.response?.data?.message ||
          "Unable to reset your password. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell mode="login">
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <h3 className="mb-2 text-xl font-bold text-slate-900">
            Create a new password
          </h3>

          <p className="text-sm leading-6 text-slate-500">
            Choose a new password for your OpenShelf account.
          </p>
        </div>

        {!success && (
          <>
            <div>
              <label
                htmlFor="new-password"
                className="mb-1.5 block text-[13px] font-semibold text-slate-700"
              >
                New password
              </label>

              <input
                id="new-password"
                type="password"
                autoComplete="new-password"
                minLength={8}
                maxLength={72}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="auth-input w-full rounded-xl border px-4 py-3 text-[14.5px] outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="confirm-password"
                className="mb-1.5 block text-[13px] font-semibold text-slate-700"
              >
                Confirm new password
              </label>

              <input
                id="confirm-password"
                type="password"
                autoComplete="new-password"
                minLength={8}
                maxLength={72}
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="auth-input w-full rounded-xl border px-4 py-3 text-[14.5px] outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="auth-submit w-full rounded-xl py-3.5 text-[15px] font-bold text-white transition disabled:opacity-60"
            >
              {loading ? "Updating..." : "Update Password"}
            </button>
          </>
        )}

        {message && (
          <p role="status" className="text-sm text-green-700">
            {message}
          </p>
        )}

        {error && (
          <p role="alert" className="text-sm text-red-600">
            {error}
          </p>
        )}

        {(success ||
          error.toLowerCase().includes("invalid") ||
          error.toLowerCase().includes("expired")) && (
          <Link
            to="/login"
            className="block text-center text-sm font-semibold text-blue-700 hover:text-sky-600"
          >
            Return to Login
          </Link>
        )}
      </form>
    </AuthShell>
  );
}
