import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import QuoteFeed from "../components/QuoteFeed";
import { Sk } from "../components/BookSkeletons";

interface BookHead {
  _id: string;
  title: string;
  author: string;
}

// "View more" from a book's Highlights section: every highlight of that one
// book, 10 at a time.
export default function BookHighlightsOfBook() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [book, setBook] = useState<BookHead | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setBook(null);
    setError("");
    api
      .get<BookHead>(`/books/${id}`)
      .then(({ data }) => !cancelled && setBook({ _id: data._id, title: data.title, author: data.author }))
      .catch((err: any) => !cancelled && setError(err?.response?.data?.message || "Could not load this book."));
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (error) {
    return (
      <div className="library-feedback" role="alert">
        <strong>Book unavailable</strong>
        <span>{error}</span>
        <Link to="/books" className="font-semibold underline">
          Back to books
        </Link>
      </div>
    );
  }

  return (
    <div className="library-page">
      <Link
        to={`/books/${id}`}
        className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-blue-500"
      >
        ← Back to book
      </Link>

      <div className="mb-6">
        {book ? (
          <>
            <h2 className="m-0 font-heading text-2xl font-bold">Highlights from {book.title}</h2>
            <p className="mb-0 mt-1 text-[14px] text-ink-600">
              Lines readers loved from this book, by {book.author}. To add a line, use the Highlights
              section on the book&apos;s page.
            </p>
          </>
        ) : (
          <div aria-busy="true" aria-label="Loading book">
            <Sk w="46%" h={26} r={8} className="mb-3" />
            <Sk w="64%" h={13} />
          </div>
        )}
      </div>

      {id && (
        <QuoteFeed
          mode="book"
          bookId={id}
          hideBook
          isAdmin={isAdmin}
          empty="No highlights yet. Open the book and add its best line."
        />
      )}
    </div>
  );
}
