import { FormEvent, useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import api from "../api/axios";
import { useConfirm } from "../context/ConfirmContext";
import { useAuth } from "../context/AuthContext";
import { DiscussionThread as Thread } from "../types";
import SpoilerText from "../components/SpoilerText";
import { timeAgo } from "../utils/timeAgo";
import { PageSkeleton } from "../components/BookSkeletons";

export default function DiscussionThread() {
  const confirm = useConfirm();
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.role === "admin";

  const [thread, setThread] = useState<Thread | null>(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");

  const [reply, setReply] = useState("");
  const [replySpoiler, setReplySpoiler] = useState(false);
  const [sending, setSending] = useState(false);

  const load = useCallback(async () => {
    try {
      setError("");
      const { data } = await api.get<Thread>(`/discussions/${id}`);
      setThread(data);
    } catch (err: any) {
      setError(err?.response?.data?.message || "Could not load this discussion.");
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  function showToast(message: string) {
    setToast(message);
    setTimeout(() => setToast(""), 3000);
  }

  async function sendReply(event: FormEvent) {
    event.preventDefault();
    if (!reply.trim() || sending) return;
    try {
      setSending(true);
      const { data } = await api.post<Thread>(`/discussions/${id}/replies`, {
        body: reply,
        spoiler: replySpoiler,
      });
      setThread(data);
      setReply("");
      setReplySpoiler(false);
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not post your reply");
    } finally {
      setSending(false);
    }
  }

  async function upvote() {
    try {
      const { data } = await api.post(`/discussions/${id}/upvote`);
      setThread((t) => (t ? { ...t, upvoted: data.upvoted, upvoteCount: data.upvoteCount } : t));
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not update your vote");
    }
  }

  async function moderate(patch: { pinned?: boolean; locked?: boolean }) {
    try {
      const { data } = await api.patch<Thread>(`/discussions/${id}/moderate`, patch);
      setThread(data);
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Action failed");
    }
  }

  async function deleteThread() {
    if (
      !(await confirm({
        title: "Delete this discussion?",
        message: "The discussion and all of its replies will be removed. This cannot be undone.",
        confirmLabel: "Delete",
      }))
    )
      return;
    try {
      await api.delete(`/discussions/${id}`);
      navigate(thread ? `/books/${thread.bookId}` : "/discussions", { replace: true });
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not delete");
    }
  }

  async function deleteReply(replyId: string) {
    if (
      !(await confirm({
        title: "Delete this reply?",
        message: "This cannot be undone.",
        confirmLabel: "Delete",
      }))
    )
      return;
    try {
      const { data } = await api.delete<Thread>(`/discussions/${id}/replies/${replyId}`);
      setThread(data);
    } catch (err: any) {
      showToast(err?.response?.data?.message || "Could not delete");
    }
  }

  if (!thread && !error) return <PageSkeleton variant="thread" />;

  if (!thread) {
    return (
      <div className="library-feedback" role={error ? "alert" : "status"}>
        {error ? (
          <>
            <strong>Discussion unavailable</strong>
            <span>{error}</span>
            <button type="button" onClick={() => navigate("/discussions")}>
              Back to discussions
            </button>
          </>
        ) : (
          <PageSkeleton variant="thread" />
        )}
      </div>
    );
  }

  const canDeleteThread = thread.mine || isAdmin;

  return (
    <div className="library-page mx-auto max-w-3xl">
      <Link
        to={`/books/${thread.bookId}`}
        className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-blue-500"
      >
        ← {thread.bookTitle || "Back to book"}
      </Link>

      <article className="rounded-2xl border border-line bg-card p-5">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          {thread.pinned && (
            <span className="rounded-full bg-gold-500/20 px-2 py-0.5 text-[11px] font-bold text-gold-500">
              Pinned
            </span>
          )}
          {thread.locked && (
            <span className="rounded-full bg-surface px-2 py-0.5 text-[11px] font-bold text-ink-600">
              Locked
            </span>
          )}
        </div>
        <h2 className="m-0 mb-1 font-heading text-[21px] font-bold">{thread.title}</h2>
        <p className="mb-4 text-[12.5px] text-ink-600">
          {thread.userName} · {timeAgo(thread.createdAt)}
          {thread.bookAuthor ? ` · on “${thread.bookTitle}” by ${thread.bookAuthor}` : ""}
        </p>

        <SpoilerText text={thread.body} spoiler={thread.spoiler} className="text-[14.5px] leading-relaxed" />

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void upvote()}
            aria-pressed={thread.upvoted}
            className={`rounded-full border px-3.5 py-1.5 text-[13px] font-semibold ${
              thread.upvoted
                ? "border-primary bg-primary/10 text-primary"
                : "border-line text-ink-600"
            }`}
          >
            Upvote ({thread.upvoteCount})
          </button>

          {isAdmin && (
            <>
              <button
                type="button"
                onClick={() => void moderate({ pinned: !thread.pinned })}
                className="rounded-full border border-line px-3.5 py-1.5 text-[13px] font-semibold"
              >
                {thread.pinned ? "Unpin" : "Pin"}
              </button>
              <button
                type="button"
                onClick={() => void moderate({ locked: !thread.locked })}
                className="rounded-full border border-line px-3.5 py-1.5 text-[13px] font-semibold"
              >
                {thread.locked ? "Unlock" : "Lock"}
              </button>
            </>
          )}

          {canDeleteThread && (
            <button
              type="button"
              onClick={() => void deleteThread()}
              className="ml-auto rounded-full border border-danger px-3.5 py-1.5 text-[13px] font-semibold text-danger"
            >
              Delete
            </button>
          )}
        </div>
      </article>

      <h3 className="mb-3 mt-7 font-heading text-[16px] font-bold">
        {thread.replyCount} {thread.replyCount === 1 ? "Reply" : "Replies"}
      </h3>

      <ul className="m-0 list-none space-y-2.5 p-0">
        {thread.replies?.map((r) => (
          <li key={r._id} className="rounded-xl border border-line bg-card p-3.5">
            <div className="mb-1.5 flex items-center justify-between gap-2 text-[12px] text-ink-600">
              <span>
                <b className="text-ink-900">{r.userName}</b>
                {r.mine && " (you)"} · {timeAgo(r.createdAt)}
              </span>
              {(r.mine || isAdmin) && (
                <button
                  type="button"
                  onClick={() => void deleteReply(r._id)}
                  className="font-semibold text-danger"
                >
                  Delete
                </button>
              )}
            </div>
            <SpoilerText text={r.body} spoiler={r.spoiler} className="text-[14px] leading-relaxed" />
          </li>
        ))}
      </ul>

      {thread.locked ? (
        <p className="mt-5 rounded-xl bg-surface p-4 text-center text-[13.5px] text-ink-600">
          This discussion is locked. No new replies can be added.
        </p>
      ) : (
        <form onSubmit={sendReply} className="mt-5 rounded-2xl border border-line bg-card p-4">
          <label htmlFor="reply" className="mb-1 block text-[13px] font-semibold">
            Add a reply
          </label>
          <textarea
            id="reply"
            value={reply}
            onChange={(e) => setReply(e.target.value)}
            maxLength={1000}
            rows={3}
            placeholder="Join the conversation…"
            className="w-full resize-none rounded-xl border border-line-strong bg-field px-4 py-3 text-[14px] outline-none focus:border-blue-500"
          />
          <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
            <label className="flex items-center gap-2 text-[13px]">
              <input
                type="checkbox"
                checked={replySpoiler}
                onChange={(e) => setReplySpoiler(e.target.checked)}
              />
              Contains spoilers
            </label>
            <div className="flex items-center gap-3">
              <span className="text-[11px] text-ink-600">{reply.length}/1000</span>
              <button
                type="submit"
                disabled={sending || !reply.trim()}
                className="rounded-full bg-primary px-5 py-2 text-[13px] font-bold text-white disabled:opacity-50"
              >
                {sending ? "Posting…" : "Reply"}
              </button>
            </div>
          </div>
        </form>
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[100] max-w-[90vw] -translate-x-1/2 rounded-full bg-primary px-6 py-3 text-center text-sm font-semibold text-white shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
