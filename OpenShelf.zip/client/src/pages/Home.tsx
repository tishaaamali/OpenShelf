import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import {
  Book,
  AccountSummary,
  CategoryCount,
  PaginatedBooks,
} from "../types";
import BookCard from "../components/BookCard";
import FeaturedCarousel from "../components/FeaturedCarousel";
import QuickPreviewModal from "../components/QuickPreviewModal";
import QuoteOfTheDay from "../components/QuoteOfTheDay";
import { HomeSkeleton } from "../components/BookSkeletons";

// Every book list loads 10 books at once.
const PAGE_SIZE = 10;

export default function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [featured, setFeatured] = useState<Book[]>([]);
  const [trending, setTrending] = useState<Book[]>([]);
  const [recentlyAdded, setRecentlyAdded] = useState<Book[]>([]);
  const [shelfBooks, setShelfBooks] = useState<Book[]>([]);
  const [categories, setCategories] = useState<CategoryCount[]>([]);
  const [account, setAccount] = useState<AccountSummary | null>(null);
  const [previewBook, setPreviewBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadAll() {
    try {
      setLoading(true);
      setError("");

      // Only the pieces the page shows are requested - never the whole library.
      const [featuredRes, trendingRes, recentRes, categoryRes, accountRes] =
        await Promise.all([
          api.get<PaginatedBooks>("/books", {
            params: { page: 1, limit: PAGE_SIZE, sort: "rating" },
          }),
          api.get<Book[]>("/books/stats/popular", {
            params: { limit: PAGE_SIZE },
          }),
          api.get<PaginatedBooks>("/books", {
            params: { page: 1, limit: PAGE_SIZE },
          }),
          api.get<CategoryCount[]>("/books/stats/categories"),
          user ? api.get<AccountSummary>("/account/me") : Promise.resolve(null),
        ]);

      setFeatured(featuredRes.data.books);
      setTrending(trendingRes.data);
      setRecentlyAdded(recentRes.data.books);
      setCategories(categoryRes.data);

      if (accountRes) {
        setAccount(accountRes.data);

        const ids = accountRes.data.borrowed.map((item) => item.bookId);
        if (ids.length > 0) {
          const shelfRes = await api.get<Book[]>("/books", {
            params: { ids: ids.join(",") },
          });
          setShelfBooks(shelfRes.data);
        }
      }
    } catch (err: any) {
      setError(
        err?.response?.data?.message ||
          err?.message ||
          "Could not load books"
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) return <HomeSkeleton pageSize={PAGE_SIZE} />;

  return (
    <div className="home-content">
      {/* ERROR MESSAGE */}
      {error && (
        <div className="mb-6 rounded-xl border border-line bg-card p-4 text-[14px]">
          Couldn&apos;t load books: {error}.
          <br />
          Check that the server is running (npm run dev in the server folder).
        </div>
      )}

      {/* FEATURED - Bootstrap carousel */}
      <FeaturedCarousel books={featured} />

      {/* QUOTE OF THE DAY - borrow straight from a line you love */}
      <QuoteOfTheDay />

      {/* CATEGORY CHIPS */}
      <div className="home-categories flex gap-2.5 flex-wrap mb-8">
        {categories.map(({ category, count }) => (
          <button
            key={category}
            onClick={() =>
              navigate(`/books?category=${encodeURIComponent(category)}`)
            }
            className="bg-card border-[1.5px] border-line rounded-full px-4 py-2 text-[13px] font-semibold hover:border-blue-500 hover:text-blue-500"
          >
            {category} ({count})
          </button>
        ))}
      </div>

      {/* YOUR SHELF */}
      {shelfBooks.length > 0 && account && (
        <Section
          title="Your Shelf"
          onViewAll={() => navigate("/account")}
          viewAllLabel="View Account →"
        >
          <BookGrid>
            {shelfBooks.map((book, index) => {
              const borrowedBook = account.borrowed.find(
                (item) => item.bookId === book._id
              );

              return (
                <BookCard
                  key={book._id}
                  book={book}
                  index={index}
                  onPreview={setPreviewBook}
                  badgeOverride={
                    borrowedBook && borrowedBook.daysOverdue > 0
                      ? {
                          text: `${borrowedBook.daysOverdue}d overdue`,
                          className: "badge-damaged",
                        }
                      : borrowedBook
                        ? {
                            text: `Due ${new Date(
                              borrowedBook.dueDate
                            ).toLocaleDateString()}`,
                            className: "badge-borrowed",
                          }
                        : undefined
                  }
                />
              );
            })}
          </BookGrid>
        </Section>
      )}

      {/* TRENDING */}
      <Section title="Trending Now" onViewAll={() => navigate("/books")} viewAllLabel="View all books →">
        <BookGrid>
          {trending.map((book, index) => (
            <BookCard
              key={book._id}
              book={book}
              index={index}
              onPreview={setPreviewBook}
              badgeOverride={{
                text: `#${index + 1} · ${book.borrowCount} borrows`,
                className: "badge-borrowed",
              }}
            />
          ))}
        </BookGrid>
      </Section>

      {/* RECENTLY ADDED */}
      <Section title="Recently Added" onViewAll={() => navigate("/books")} viewAllLabel="View all books →">
        <BookGrid>
          {recentlyAdded.map((book, index) => (
            <BookCard
              key={book._id}
              book={book}
              index={index}
              onPreview={setPreviewBook}
            />
          ))}
        </BookGrid>
      </Section>

      {/* PREVIEW MODAL */}
      <QuickPreviewModal
        book={previewBook}
        index={0}
        onClose={() => setPreviewBook(null)}
      />
    </div>
  );
}

function Section({
  title,
  children,
  onViewAll,
  viewAllLabel = "View all →",
}: {
  title: string;
  children: React.ReactNode;
  onViewAll: () => void;
  viewAllLabel?: string;
}) {
  return (
    <div className="mb-9">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-[17px] font-heading font-bold m-0">{title}</h2>

        <button
          onClick={onViewAll}
          className="text-[13.5px] text-blue-500 font-semibold"
        >
          {viewAllLabel}
        </button>
      </div>

      {children}
    </div>
  );
}

function BookGrid({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[repeat(auto-fill,minmax(230px,1fr))] gap-5">
      {children}
    </div>
  );
}
