import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import Select, { components } from "react-select";

import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { Book, CategoryCount, PaginatedBooks } from "../types";
import BookCard from "../components/BookCard";
import BookCover from "../components/BookCover";
import QuickPreviewModal from "../components/QuickPreviewModal";
import {
  BookCardSkeletons,
  BookRowSkeletons,
} from "../components/BookSkeletons";

// Every request loads exactly this many books.
const PAGE_SIZE = 10;

interface Option {
  value: string;
  label: string;
}

/* ---------- react-select customisation (multi category) ---------- */

// Shows "Fantasy, Fiction" instead of one chip (and one cross) per category,
// so the whole control has a single cross: the clear-all indicator.
function SummaryValueContainer({ children, ...props }: any) {
  const selected = props.getValue() as Option[];

  if (selected.length === 0) {
    return (
      <components.ValueContainer {...props}>
        {children}
      </components.ValueContainer>
    );
  }

  const input = Array.isArray(children) ? children[1] : null;
  const label = selected.map((item) => item.label).join(", ");

  return (
    <components.ValueContainer {...props}>
      <span
        title={label}
        style={{
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
          color: "rgb(var(--ink-900))",
        }}
      >
        {label}
      </span>
      {input}
    </components.ValueContainer>
  );
}

function CheckOption(props: any) {
  return (
    <components.Option {...props}>
      <span style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span
          style={{
            width: 16,
            height: 16,
            flexShrink: 0,
            borderRadius: 4,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 11,
            fontWeight: 800,
            color: "#fff",
            border: "1.5px solid rgb(var(--line))",
            background: props.isSelected
              ? "rgb(var(--primary))"
              : "transparent",
          }}
        >
          {props.isSelected ? "✓" : ""}
        </span>
        {props.label}
      </span>
    </components.Option>
  );
}

function buildSelectStyles(multi: boolean) {
  return {
    control: (base: any, state: any) => ({
      ...base,
      minHeight: "44px",
      height: "44px",
      borderRadius: "10px",
      borderColor: state.isFocused ? "#38bdf8" : "rgb(var(--line))",
      backgroundColor: "rgb(var(--field))",
      boxShadow: state.isFocused ? "0 0 0 1px #38bdf8" : "none",
      cursor: "pointer",
      minWidth: "180px",
      fontSize: "14px",
      fontWeight: 500,
      transition: "all 0.2s ease",
      flexWrap: "nowrap" as const,
    }),
    valueContainer: (base: any) => ({
      ...base,
      paddingLeft: "14px",
      paddingRight: "8px",
      flexWrap: "nowrap" as const,
      overflow: "hidden",
    }),
    singleValue: (base: any) => ({
      ...base,
      color: "rgb(var(--ink-900))",
    }),
    placeholder: (base: any) => ({
      ...base,
      color: "rgb(var(--ink-900))",
    }),
    menu: (base: any) => ({
      ...base,
      marginTop: "6px",
      borderRadius: "10px",
      overflow: "hidden",
      backgroundColor: "rgb(var(--card))",
      border: "1px solid rgb(var(--line))",
      boxShadow: "0 18px 36px rgba(0, 0, 0, 0.38)",
      zIndex: 100,
    }),
    menuPortal: (base: any) => ({
      ...base,
      zIndex: 9999,
    }),
    menuList: (base: any) => ({
      ...base,
      padding: "5px",
      maxHeight: "300px",
    }),
    option: (base: any, state: any) => {
      const highlighted = multi
        ? state.isSelected
          ? "rgba(56, 189, 248, 0.18)"
          : state.isFocused
            ? "rgba(56, 189, 248, 0.10)"
            : "transparent"
        : state.isSelected
          ? "rgb(var(--primary))"
          : state.isFocused
            ? "rgba(56, 189, 248, 0.14)"
            : "transparent";

      return {
        ...base,
        borderRadius: "7px",
        padding: "10px 12px",
        fontSize: "14px",
        fontWeight: state.isSelected ? 600 : 500,
        color:
          !multi && state.isSelected ? "#ffffff" : "rgb(var(--ink-900))",
        backgroundColor: highlighted,
        cursor: "pointer",
        transition: "all 0.15s ease",
        ":active": {
          backgroundColor: "rgba(56, 189, 248, 0.22)",
        },
      };
    },
    dropdownIndicator: (base: any) => ({
      ...base,
      color: "rgb(var(--ink-900))",
      paddingRight: "12px",
      paddingLeft: "4px",
    }),
    clearIndicator: (base: any) => ({
      ...base,
      cursor: "pointer",
      padding: "6px",
      color: "rgb(var(--ink-600))",
      ":hover": { color: "rgb(var(--ink-900))" },
    }),
    indicatorSeparator: () => ({
      display: "none",
    }),
  };
}

const categoryStyles = buildSelectStyles(true);
const statusStyles = buildSelectStyles(false);

const statusOptions: Option[] = [
  { value: "", label: "All statuses" },
  { value: "Available", label: "Available" },
  { value: "Borrowed", label: "Borrowed" },
];

export default function Books() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const isAdmin = user?.role === "admin";

  // ----- filters (URL is the source of truth) -----
  const q = searchParams.get("q") || "";
  const categoryParam = searchParams.get("category") || "";
  const status = searchParams.get("status") || "";

  const selectedCategoryValues = useMemo(
    () => categoryParam.split(",").map((c) => c.trim()).filter(Boolean),
    [categoryParam]
  );

  const [searchText, setSearchText] = useState(q);
  const [categoryCounts, setCategoryCounts] = useState<CategoryCount[]>([]);
  const [openDropdown, setOpenDropdown] = useState<"category" | "status" | null>(null);

  // ----- list state -----
  const [books, setBooks] = useState<Book[]>([]);
  const [total, setTotal] = useState(0);
  const [totalAll, setTotalAll] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true); // first page
  const [loadingMore, setLoadingMore] = useState(false); // next pages
  const [error, setError] = useState("");
  const [previewBook, setPreviewBook] = useState<Book | null>(null);

  const pageRef = useRef(0);
  const busyRef = useRef(false);
  const requestIdRef = useRef(0);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // Close portaled filter menus when the page scrolls.
  useEffect(() => {
    const closeDropdowns = () => setOpenDropdown(null);
    window.addEventListener("scroll", closeDropdowns, { passive: true });
    return () => window.removeEventListener("scroll", closeDropdowns);
  }, []);

  // Categories for the multi select (loaded once).
  useEffect(() => {
    api
      .get<CategoryCount[]>("/books/stats/categories")
      .then(({ data }) => setCategoryCounts(data))
      .catch(() => setCategoryCounts([]));
  }, []);

  // Fetch one page (10 books).  page === 1 replaces the list, other pages append.
  const fetchPage = useCallback(
    async (page: number) => {
      const requestId = ++requestIdRef.current;
      busyRef.current = true;
      setError("");

      if (page === 1) setLoading(true);
      else setLoadingMore(true);

      try {
        const { data } = await api.get<PaginatedBooks>("/books", {
          params: {
            page,
            limit: PAGE_SIZE,
            q: q.trim() || undefined,
            category: categoryParam || undefined,
            status: status || undefined,
            coverFirst: 1,
          },
        });

        // A newer request (filter changed) already took over: drop this one.
        if (requestId !== requestIdRef.current) return;

        pageRef.current = page;
        setTotal(data.total);
        setTotalAll(data.totalAll);
        setHasMore(data.hasMore);
        setBooks((current) => {
          if (page === 1) return data.books;
          const seen = new Set(current.map((book) => book._id));
          return [
            ...current,
            ...data.books.filter((book) => !seen.has(book._id)),
          ];
        });
      } catch (err: any) {
        if (requestId !== requestIdRef.current) return;

        setHasMore(false);
        setError(
          err?.response?.data?.message ||
            "Could not load the collection. Check your connection and try again."
        );
      } finally {
        if (requestId === requestIdRef.current) {
          busyRef.current = false;
          setLoading(false);
          setLoadingMore(false);
        }
      }
    },
    [q, categoryParam, status]
  );

  // First page: on mount and whenever a filter changes.
  useEffect(() => {
    pageRef.current = 0;
    setBooks([]);
    setHasMore(false);
    void fetchPage(1);
  }, [fetchPage]);

  // Infinite scroll: when the sentinel nears the viewport, load the next 10.
  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasMore || loading || loadingMore || error) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !busyRef.current) {
          void fetchPage(pageRef.current + 1);
        }
      },
      { rootMargin: "240px 0px" }
    );

    observer.observe(node);
    return () => observer.disconnect();
    // books.length makes the observer fire again if the sentinel is still visible
  }, [hasMore, loading, loadingMore, error, books.length, fetchPage]);

  // ----- search box (debounced into the URL) -----
  useEffect(() => {
    setSearchText(q);
  }, [q]);

  useEffect(() => {
    const nextQuery = searchText.trim();
    if (nextQuery === q) return;

    const debounce = window.setTimeout(() => {
      const next = new URLSearchParams(searchParams);

      if (nextQuery.length >= 3) next.set("q", nextQuery);
      else next.delete("q");

      setSearchParams(next, { replace: true });
    }, 350);

    return () => window.clearTimeout(debounce);
  }, [searchText, q, searchParams, setSearchParams]);

  // The single cross: clears the text AND the URL filter immediately.
  function clearSearch() {
    setSearchText("");

    const next = new URLSearchParams(searchParams);
    next.delete("q");
    setSearchParams(next, { replace: true });
  }

  // Resets the search box, category and status filters in one go.
  // Typing in the search box does not count: it has its own cross.
  const hasFilters = Boolean(categoryParam || status);

  function clearAllFilters() {
    setSearchText("");
    setOpenDropdown(null);
    setSearchParams(new URLSearchParams(), { replace: true });
  }

  function updateParam(key: string, value: string) {
    const next = new URLSearchParams(searchParams);

    if (value) next.set(key, value);
    else next.delete(key);

    setSearchParams(next);
  }

  const categoryOptions: Option[] = categoryCounts.map((item) => ({
    value: item.category,
    label: item.category,
  }));

  const selectedCategories: Option[] = selectedCategoryValues.map(
    (value) =>
      categoryOptions.find((option) => option.value === value) || {
        value,
        label: value,
      }
  );

  const selectedStatus =
    statusOptions.find((option) => option.value === status) ||
    statusOptions[0];

  const showSkeleton = loading;
  const showEmpty = !loading && !error && books.length === 0;

  return (
    <div className="library-page books-page">
      <div className="library-page-heading mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="library-eyebrow">THE COLLECTION</div>

          <h1 className="m-0 mb-1.5 font-heading text-2xl font-bold">
            Books
          </h1>

          <p className="m-0 text-[14.5px] text-ink-600">
            {loading && books.length === 0
              ? "Searching..."
              : `${total} of ${totalAll} titles`}
          </p>
        </div>
      </div>

      <div
        className="books-toolbar relative z-20 mb-6 flex flex-wrap items-center gap-3"
      >
        {/* SEARCH - one custom cross, native browser cross is hidden in CSS */}
        <div className="search-field relative min-w-[200px] flex-1">
          <input
            type="text"
            value={searchText}
            onChange={(event) => setSearchText(event.target.value)}
            placeholder="Search by title, author or ISBN..."
            aria-label="Search by title, author or ISBN"
            className="w-full rounded-lg border border-line bg-field py-2.5 pl-4 pr-11 text-sm outline-none focus:border-blue-500"
          />

          {searchText && (
            <button
              type="button"
              onClick={clearSearch}
              aria-label="Clear book search"
              className="search-clear-btn"
            >
              ×
            </button>
          )}
        </div>

        {/* CATEGORY - multiple selection */}
        <div className="min-w-[185px] max-w-[280px]">
          <Select<Option, true>
            isMulti
            value={selectedCategories}
            options={categoryOptions}
            styles={categoryStyles}
            menuPortalTarget={document.body}
            menuPosition="fixed"
            menuIsOpen={openDropdown === "category"}
            onMenuOpen={() => setOpenDropdown("category")}
            onMenuClose={() => setOpenDropdown(null)}
            isSearchable={false}
            isClearable
            closeMenuOnSelect={false}
            hideSelectedOptions={false}
            backspaceRemovesValue
            placeholder="All categories"
            aria-label="Filter by category"
            components={{
              ValueContainer: SummaryValueContainer,
              Option: CheckOption,
            }}
            onChange={(options) =>
              updateParam(
                "category",
                (options || []).map((option) => option.value).join(",")
              )
            }
          />
        </div>

        {/* STATUS */}
        <div className="min-w-[175px]">
          <Select<Option, false>
            value={selectedStatus}
            options={statusOptions}
            styles={statusStyles}
            menuPortalTarget={document.body}
            menuPosition="fixed"
            menuIsOpen={openDropdown === "status"}
            onMenuOpen={() => setOpenDropdown("status")}
            onMenuClose={() => setOpenDropdown(null)}
            isSearchable={false}
            isClearable={Boolean(status)}
            aria-label="Filter by status"
            onChange={(option) =>
              updateParam("status", option?.value || "")
            }
          />
        </div>

        {hasFilters && (
          <button type="button" onClick={clearAllFilters} className="clear-filters-btn">
            Clear filters
          </button>
        )}

        {isAdmin && (
          <button
            type="button"
            onClick={() => navigate("/books/add")}
            className="library-primary-button rounded-lg bg-primary px-5 py-2.5 text-sm font-bold text-white transition hover:bg-primary-hover"
          >
            + Add Book
          </button>
        )}
      </div>

      {error && (
        <div className="library-feedback library-error" role="alert">
          <strong>We couldn’t reach the shelves.</strong>
          <span>{error}</span>
          <button
            type="button"
            onClick={() =>
              void fetchPage(pageRef.current === 0 ? 1 : pageRef.current + 1)
            }
          >
            Try again
          </button>
        </div>
      )}

      {showEmpty && (
        <div className="library-empty-state py-16 text-center text-ink-600">
          <span>✧</span>
          <strong>No books found</strong>
          <p>Try a different title, author, or filter.</p>
        </div>
      )}

      {/* LIST (admin rows / member cards) - skeletons only, no spinner */}
      {isAdmin ? (
        <div className="space-y-4" aria-busy={loading || loadingMore}>
          {books.map((book, index) => {
            const availableCopies =
              book.copies?.filter((copy) => copy.status === "Available")
                .length ?? 0;

            return (
              <button
                key={book._id}
                type="button"
                onClick={() => navigate(`/books/${book._id}`)}
                className="books-admin-row flex w-full items-center gap-5 rounded-2xl border border-line bg-card p-5 text-left"
              >
                <BookCover
                  book={book}
                  index={index}
                  className="h-28 w-20 shrink-0 rounded-lg text-base"
                />

                <span className="min-w-0 flex-1">
                  <span className="block truncate text-lg font-semibold text-ink-900">
                    {book.title}
                  </span>

                  <span className="mt-1 block truncate text-base text-ink-600">
                    {book.author}
                  </span>

                  <span className="mt-1 block text-sm text-ink-600">
                    {book.category} · {book.format}
                  </span>
                </span>

                <span className="shrink-0 text-right">
                  <span
                    className={`block text-base font-semibold ${
                      availableCopies > 0
                        ? "text-emerald-500"
                        : "text-amber-500"
                    }`}
                  >
                    {availableCopies > 0 ? "Available" : "Borrowed"}
                  </span>

                  <span className="mt-1 block text-sm text-ink-600">
                    {availableCopies} available
                  </span>
                </span>
              </button>
            );
          })}

          {(showSkeleton || loadingMore) && (
            <BookRowSkeletons count={showSkeleton ? PAGE_SIZE : 3} />
          )}
        </div>
      ) : (
        <div
          className="grid grid-cols-[repeat(auto-fill,minmax(230px,1fr))] gap-5"
          aria-busy={loading || loadingMore}
        >
          {books.map((book, index) => (
            <BookCard
              key={book._id}
              book={book}
              index={index}
              onPreview={setPreviewBook}
            />
          ))}

          {(showSkeleton || loadingMore) && (
            <BookCardSkeletons count={showSkeleton ? PAGE_SIZE : 5} />
          )}
        </div>
      )}

      {/* Infinite-scroll trigger */}
      <div ref={sentinelRef} className="h-px w-full" aria-hidden="true" />

      {!loading && !hasMore && books.length > PAGE_SIZE && (
        <p className="mt-8 text-center text-sm text-ink-600">
          You’ve reached the end · {books.length} books
        </p>
      )}

      <QuickPreviewModal
        book={previewBook}
        index={previewBook ? books.indexOf(previewBook) : 0}
        onClose={() => setPreviewBook(null)}
      />
    </div>
  );
}
