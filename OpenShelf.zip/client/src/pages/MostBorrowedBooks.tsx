import RankedBooksPage from "../components/RankedBooksPage";

// Reached only from "View More →" on the Dashboard's Most Borrowed Books panel.
// It is intentionally not linked from the navbar.
export default function MostBorrowedBooks() {
  return (
    <RankedBooksPage
      endpoint="/books/stats/popular"
      eyebrow="LIBRARY INSIGHTS"
      title="Most Borrowed Books"
      subtitle="Top 25 by total borrows"
      emptyTitle="No books yet"
      emptyText="Books will appear here once they have been added to the library."
      errorTitle="Most borrowed books unavailable"
      renderStat={(book) => (
        <>
          <span className="block text-base font-semibold text-ink-900">
            {book.borrowCount}
          </span>
          <span className="block text-[12px] text-ink-600">
            {book.borrowCount === 1 ? "borrow" : "borrows"}
          </span>
        </>
      )}
    />
  );
}
