import { useState, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AuthShell from "../components/AuthShell";
import { isValidPhone } from "../utils/validators";

const inputClass =
  "auth-input w-full px-4 py-3 rounded-xl border text-[14.5px] outline-none transition";

const labelClass =
  "mb-1.5 block text-[13px] font-semibold text-slate-700";

const errorClass =
  "text-danger text-[12px] mt-1";

type FormErrors = {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  phone?: string;
};

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [firstName, setFirstName] =
    useState("");

  const [lastName, setLastName] =
    useState("");

  const [email, setEmail] =
    useState("");

  const [password, setPassword] =
    useState("");

  const [confirmPassword, setConfirmPassword] =
    useState("");

  const [phone, setPhone] =
    useState("");

  const [errors, setErrors] =
    useState<FormErrors>({});

  const [loading, setLoading] =
    useState(false);

  // -----------------------------
  // VALIDATION
  // -----------------------------

  function validateFirstName(value: string) {
    if (!value.trim()) {
      setErrors((prev) => ({
        ...prev,
        firstName: "First name is required",
      }));
      return false;
    }

    setErrors((prev) => ({
      ...prev,
      firstName: undefined,
    }));

    return true;
  }

  function validateLastName(value: string) {
    if (!value.trim()) {
      setErrors((prev) => ({
        ...prev,
        lastName: "Last name is required",
      }));
      return false;
    }

    setErrors((prev) => ({
      ...prev,
      lastName: undefined,
    }));

    return true;
  }

  function validateEmail(value: string) {
    if (!value.trim()) {
      setErrors((prev) => ({
        ...prev,
        email: "Email is required",
      }));
      return false;
    }

    if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        value.trim()
      )
    ) {
      setErrors((prev) => ({
        ...prev,
        email: "Enter a valid email address",
      }));
      return false;
    }

    setErrors((prev) => ({
      ...prev,
      email: undefined,
    }));

    return true;
  }

  function validatePassword(value: string) {
    if (!value) {
      setErrors((prev) => ({
        ...prev,
        password: "Password is required",
      }));
      return false;
    }

    if (value.length < 6) {
      setErrors((prev) => ({
        ...prev,
        password:
          "Password must be at least 6 characters",
      }));
      return false;
    }

    setErrors((prev) => ({
      ...prev,
      password: undefined,
    }));

    return true;
  }

  function validateConfirmPassword(
    value: string
  ) {
    if (!value) {
      setErrors((prev) => ({
        ...prev,
        confirmPassword:
          "Please confirm your password",
      }));
      return false;
    }

    if (value !== password) {
      setErrors((prev) => ({
        ...prev,
        confirmPassword:
          "Passwords do not match",
      }));
      return false;
    }

    setErrors((prev) => ({
      ...prev,
      confirmPassword: undefined,
    }));

    return true;
  }

  function validatePhone(value: string) {
    // Phone is optional
    if (!value.trim()) {
      setErrors((prev) => ({
        ...prev,
        phone: undefined,
      }));

      return true;
    }

    if (!isValidPhone(value)) {
      setErrors((prev) => ({
        ...prev,
        phone: "Enter a valid phone number",
      }));

      return false;
    }

    setErrors((prev) => ({
      ...prev,
      phone: undefined,
    }));

    return true;
  }

  // -----------------------------
  // SUBMIT
  // -----------------------------

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();

    const firstValid =
      validateFirstName(firstName);

    const lastValid =
      validateLastName(lastName);

    const emailValid =
      validateEmail(email);

    const passwordValid =
      validatePassword(password);

    const confirmValid =
      validateConfirmPassword(
        confirmPassword
      );

    const phoneValid =
      validatePhone(phone);

    if (
      !firstValid ||
      !lastValid ||
      !emailValid ||
      !passwordValid ||
      !confirmValid ||
      !phoneValid
    ) {
      return;
    }

    setLoading(true);

    try {
      await register({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        phone: phone.trim() || undefined,
        password,
      });

      navigate("/");
    } catch (err: any) {
      const message = err?.response?.data?.message;
      setErrors({
        email: message || (err?.request
          ? "Can't reach the library server. Make sure the server is running on port 5001."
          : "Registration failed. Please check your details and try again."),
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell mode="register">
        <form
          onSubmit={handleSubmit}
          className="space-y-3.5"
        >

          {/* FIRST NAME + LAST NAME */}
          <div className="grid grid-cols-2 gap-3">

            {/* FIRST NAME */}
            <div>
              <label
                htmlFor="firstName"
                className={labelClass}
              >
                First Name{" "}
                <span className="text-danger">
                  *
                </span>
              </label>

              <input
                id="firstName"
                type="text"
                autoComplete="given-name"
                placeholder="First Name"
                value={firstName}
                onChange={(e) => {
                  const value =
                    e.target.value;

                  setFirstName(value);

                  if (value.trim()) {
                    setErrors((prev) => ({
                      ...prev,
                      firstName: undefined,
                    }));
                  }
                }}
                onBlur={() =>
                  validateFirstName(firstName)
                }
                className={inputClass}
              />

              {errors.firstName && (
                <p className={errorClass}>
                  {errors.firstName}
                </p>
              )}
            </div>

            {/* LAST NAME */}
            <div>
              <label
                htmlFor="lastName"
                className={labelClass}
              >
                Last Name{" "}
                <span className="text-danger">
                  *
                </span>
              </label>

              <input
                id="lastName"
                type="text"
                autoComplete="family-name"
                placeholder="Last Name"
                value={lastName}
                onChange={(e) => {
                  const value =
                    e.target.value;

                  setLastName(value);

                  if (value.trim()) {
                    setErrors((prev) => ({
                      ...prev,
                      lastName: undefined,
                    }));
                  }
                }}
                onBlur={() =>
                  validateLastName(lastName)
                }
                className={inputClass}
              />

              {errors.lastName && (
                <p className={errorClass}>
                  {errors.lastName}
                </p>
              )}
            </div>

          </div>

          {/* EMAIL */}
          <div>
            <label
              htmlFor="email"
              className={labelClass}
            >
              Email{" "}
              <span className="text-danger">
                *
              </span>
            </label>

            <input
              id="email"
              type="email"
              autoComplete="email"
              placeholder="Email"
              value={email}
              onChange={(e) => {
                const value =
                  e.target.value;

                setEmail(value);

                if (value.trim()) {
                  setErrors((prev) => ({
                    ...prev,
                    email: undefined,
                  }));
                }
              }}
              onBlur={() =>
                validateEmail(email)
              }
              className={inputClass}
            />

            {errors.email && (
              <p className={errorClass}>
                {errors.email}
              </p>
            )}
          </div>

          {/* PASSWORD */}
          <div>
            <label
              htmlFor="password"
              className={labelClass}
            >
              Password{" "}
              <span className="text-danger">
                *
              </span>
            </label>

            <input
              id="password"
              type="password"
              autoComplete="new-password"
              placeholder="Password (min 6 characters)"
              value={password}
              onChange={(e) => {
                const value =
                  e.target.value;

                setPassword(value);

                if (value.length >= 6) {
                  setErrors((prev) => ({
                    ...prev,
                    password: undefined,
                  }));
                }

                if (
                  confirmPassword &&
                  value === confirmPassword
                ) {
                  setErrors((prev) => ({
                    ...prev,
                    confirmPassword:
                      undefined,
                  }));
                }
              }}
              onBlur={() =>
                validatePassword(password)
              }
              className={inputClass}
            />

            {errors.password && (
              <p className={errorClass}>
                {errors.password}
              </p>
            )}
          </div>

          {/* CONFIRM PASSWORD */}
          <div>
            <label
              htmlFor="confirmPassword"
              className={labelClass}
            >
              Confirm Password{" "}
              <span className="text-danger">
                *
              </span>
            </label>

            <input
              id="confirmPassword"
              type="password"
              autoComplete="new-password"
              placeholder="Confirm Password"
              value={confirmPassword}
              onChange={(e) => {
                const value =
                  e.target.value;

                setConfirmPassword(value);

                if (
                  value &&
                  value === password
                ) {
                  setErrors((prev) => ({
                    ...prev,
                    confirmPassword:
                      undefined,
                  }));
                }
              }}
              onBlur={() =>
                validateConfirmPassword(
                  confirmPassword
                )
              }
              className={inputClass}
            />

            {errors.confirmPassword && (
              <p className={errorClass}>
                {errors.confirmPassword}
              </p>
            )}
          </div>

          {/* PHONE - OPTIONAL */}
          <div>
            <label
              htmlFor="phone"
              className={labelClass}
            >
              Phone Number{" "}
              <span className="font-normal text-ink-600">
                (optional)
              </span>
            </label>

            <input
              id="phone"
              type="tel"
              autoComplete="tel"
              placeholder="Phone Number"
              value={phone}
              onChange={(e) => {
                const value =
                  e.target.value;

                setPhone(value);

                if (!value.trim()) {
                  setErrors((prev) => ({
                    ...prev,
                    phone: undefined,
                  }));
                }
              }}
              onBlur={() =>
                validatePhone(phone)
              }
              className={inputClass}
            />

            {errors.phone && (
              <p className={errorClass}>
                {errors.phone}
              </p>
            )}
          </div>

          {/* REGISTER BUTTON */}
          <button
            type="submit"
            disabled={loading}
            className="auth-submit w-full rounded-xl py-3.5 text-[15px] font-bold text-white transition disabled:opacity-60"
          >
            {loading
              ? "Creating account..."
              : "Register"}
          </button>

        </form>

    </AuthShell>
  );
}
