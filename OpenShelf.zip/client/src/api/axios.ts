import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

const api = axios.create({ baseURL: API_BASE_URL });

// Reuse identical in-flight and very recent GETs across sibling components
// (for example, dashboard panels and book cards) to avoid duplicate API work.
const baseAdapter = axios.getAdapter(api.defaults.adapter);
const GET_CACHE_MS = 4000;
const getCache = new Map<string, { expiresAt: number; response: any }>();
const pendingGets = new Map<string, Promise<any>>();
let cacheVersion = 0;
let apiQueue: Promise<unknown> = Promise.resolve();

function enqueueApi<T>(request: () => Promise<T>): Promise<T> {
  const result = apiQueue.then(request, request);
  apiQueue = result.then(() => undefined, () => undefined);
  return result;
}

function getCacheKey(config: any) {
  const auth = config.headers?.Authorization || config.headers?.authorization || "";
  return [config.baseURL, config.url, JSON.stringify(config.params || {}), auth].join("|");
}

api.defaults.adapter = async (config) => {
  if ((config.method || "get").toLowerCase() !== "get") {
    cacheVersion += 1;
    getCache.clear();
    pendingGets.clear();
    return enqueueApi(() => baseAdapter(config));
  }

  const key = getCacheKey(config);
  const cached = getCache.get(key);
  if (cached && cached.expiresAt > Date.now()) {
    return { ...cached.response, config };
  }
  if (cached) getCache.delete(key);

  const pending = pendingGets.get(key);
  if (pending) return pending.then((response) => ({ ...response, config }));

  const startedAtVersion = cacheVersion;
  let request: Promise<any>;
  request = enqueueApi(() => baseAdapter(config))
    .then((response) => {
      if (startedAtVersion === cacheVersion) {
        getCache.set(key, { response, expiresAt: Date.now() + GET_CACHE_MS });
      }
      return response;
    })
    .finally(() => {
      if (pendingGets.get(key) === request) pendingGets.delete(key);
    });

  pendingGets.set(key, request);
  return request;
};

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("openshelf_token");
  if (token) {
    config.headers = config.headers || {};
    config.headers["Authorization"] = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      localStorage.removeItem("openshelf_token");
      localStorage.removeItem("openshelf_user");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export default api;
