import { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Home from "./pages/Home";
import PublicHome from "./pages/PublicHome";
import Books from "./pages/Books";
import BookDetail from "./pages/BookDetail";
import AddBookPage from "./pages/AddBookPage";
import Dashboard from "./pages/Dashboard";
import Users from "./pages/Users";
import Account from "./pages/Account";
import MyReviews from "./pages/MyReviews";
import MostBorrowedBooks from "./pages/MostBorrowedBooks";
import TopRatedBooks from "./pages/TopRatedBooks";
import Discussions from "./pages/Discussions";
import DiscussionThread from "./pages/DiscussionThread";
import ReadingLists from "./pages/ReadingLists";
import ReadingListDetail from "./pages/ReadingListDetail";
import BookHighlights from "./pages/BookHighlights";
import WordsWorthKeepingPage from "./pages/WordsWorthKeepingPage";
import BookHighlightsOfBook from "./pages/BookHighlightsOfBook";
import Notifications from "./pages/Notifications";

import Navbar from "./components/Navbar";
import ProtectedRoute, { AdminRoute } from "./components/ProtectedRoute";
import { useAuth } from "./context/AuthContext";

function AppLayout({
  children,
  home = false,
  darkLibrary = true,
}: {
  children: React.ReactNode;
  home?: boolean;
  darkLibrary?: boolean;
}) {
  return (
    <div
      className={`min-h-screen bg-surface ${
        home ? "signed-home-layout" : darkLibrary ? "dark-library-layout" : ""
      }`}
    >
      <Navbar />

      <main
        className={
          home
            ? "home-main mx-auto w-full max-w-[1440px] px-5 py-8 sm:px-8 lg:px-10"
            : "mx-auto max-w-6xl px-6 py-8"
        }
      >
        {children}
      </main>
    </div>
  );
}

export default function App() {
  const { user } = useAuth();

  return (
    <>
      <ScrollEffects />

      <Routes>
        <Route
          path="/login"
          element={user ? <Navigate to="/" replace /> : <Login />}
        />

        <Route
          path="/register"
          element={user ? <Navigate to="/" replace /> : <Register />}
        />

        <Route
          path="/forgot-password"
          element={user ? <Navigate to="/" replace /> : <ForgotPassword />}
        />

        <Route
          path="/reset-password/:token"
          element={<ResetPassword />}
        />

        <Route
          path="/"
          element={
            user?.role === "admin" ? (
              <Navigate to="/dashboard" replace />
            ) : user ? (
              <AppLayout home>
                <Home />
              </AppLayout>
            ) : (
              <PublicHome />
            )
          }
        />

        <Route
          path="/books"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <Books />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        {/* ADD BOOK: private route, accessible only to admins */}
        <Route
          path="/books/add"
          element={
            <AdminRoute>
              <AppLayout darkLibrary>
                <AddBookPage />
              </AppLayout>
            </AdminRoute>
          }
        />

        <Route
          path="/books/:id"
          element={
            <ProtectedRoute>
              <AppLayout>
                <BookDetail />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        {/* Reached only via "View more" in a book's Highlights - not in the navbar */}
        <Route
          path="/books/:id/highlights"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <BookHighlightsOfBook />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        {/* Reached only via "View more" in the notification menu - not in the navbar */}
        <Route
          path="/notifications"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <Notifications />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <Dashboard />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        {/* Reached only via "View More" on the Dashboard - not in the navbar */}
        <Route
          path="/dashboard/most-borrowed"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <MostBorrowedBooks />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/dashboard/top-rated"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <TopRatedBooks />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/users"
          element={
            <ProtectedRoute>
              {user?.role === "admin" ? (
                <AppLayout>
                  <Users />
                </AppLayout>
              ) : (
                <Navigate to="/" replace />
              )}
            </ProtectedRoute>
          }
        />

        <Route
          path="/account"
          element={
            <ProtectedRoute>
              <AppLayout>
                <Account />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        {/* Reached only via "Show more" on My Account - not in the navbar */}
        <Route
          path="/my-reviews"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <MyReviews />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        {/* Community features */}
        <Route
          path="/discussions"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <Discussions />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/discussions/:id"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <DiscussionThread />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/lists"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <ReadingLists />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/lists/:id"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <ReadingListDetail />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/highlights"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <BookHighlights />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        {/* The feature used to live at /quotes; keep old links working. */}
        <Route path="/quotes" element={<Navigate to="/highlights" replace />} />

        <Route
          path="/account/words-worth-keeping"
          element={
            <ProtectedRoute>
              <AppLayout darkLibrary>
                <WordsWorthKeepingPage />
              </AppLayout>
            </ProtectedRoute>
          }
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}

function ScrollEffects() {
  useEffect(() => {
    const selector = [
      ".home-hero",
      ".home-spotlight",
      ".home-categories",
      ".book-card",
      ".library-page-heading",
      ".books-toolbar",
      ".books-page > .grid",
      ".dashboard-stats",
      ".dashboard-page > .grid",
      ".dashboard-panel",
      ".account-page > .grid > *",
      ".account-page > .bg-card",
      ".book-detail-page > .grid",
      ".book-detail-page > .bg-surface",
      ".users-toolbar",
      ".users-page > .bg-card",
      ".auth-panel",
      ".auth-panel form > *",
    ].join(",");

    const shouldReveal =
      !window.matchMedia("(prefers-reduced-motion: reduce)").matches &&
      "IntersectionObserver" in window;
    const revealObserver = shouldReveal ? new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          entry.target.classList.toggle(
            "scroll-in-view",
            entry.isIntersecting
          );
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    ) : null;

    const observe = (root: ParentNode) => {
      if (
        revealObserver &&
        root instanceof Element &&
        root.matches(selector) &&
        !root.classList.contains("scroll-reveal")
      ) {
        root.classList.add("scroll-reveal");
        revealObserver.observe(root);
      }

      root.querySelectorAll?.(selector).forEach((element) => {
        if (revealObserver && !element.classList.contains("scroll-reveal")) {
          element.classList.add("scroll-reveal");
          revealObserver.observe(element);
        }
      });
    };

    // Retain each book card's layout box while it is outside the viewport.
    // This avoids scroll jumps and works for cards appended by pagination.
    const bookCardSelector = ".book-card, .books-admin-row";
    let scrollingDown = window.scrollY > 0;
    let previousY = window.scrollY;
    const bookVisibilityObserver = "IntersectionObserver" in window
      ? new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              const card = entry.target as HTMLElement;
              if (entry.isIntersecting) {
                card.classList.remove("book-scroll-hidden");
              } else if (
                scrollingDown &&
                entry.boundingClientRect.bottom < 0
              ) {
                card.classList.add("book-scroll-hidden");
              }
            });
          },
          { rootMargin: "0px" }
        )
      : null;
    const observeBookCards = (root: ParentNode) => {
      if (root instanceof Element && root.matches(bookCardSelector)) {
        (root as HTMLElement).dataset.scrollManagedBook = "true";
        bookVisibilityObserver?.observe(root);
      }
      root.querySelectorAll?.(bookCardSelector).forEach((element) => {
        (element as HTMLElement).dataset.scrollManagedBook = "true";
        bookVisibilityObserver?.observe(element);
      });
    };

    observe(document.body);

    const mutationObserver = new MutationObserver((records) => {
      records.forEach((record) => {
        record.addedNodes.forEach((node) => {
          if (node instanceof Element) {
            observe(node);
            observeBookCards(node);
          }
        });

        record.removedNodes.forEach((node) => {
          if (!(node instanceof Element)) return;

          if (node.classList.contains("scroll-reveal")) {
            revealObserver?.unobserve(node);
          }

          node
            .querySelectorAll(".scroll-reveal")
            .forEach((element) => revealObserver?.unobserve(element));
        });
      });
    });

    mutationObserver.observe(document.body, {
      childList: true,
      subtree: true,
    });

    observeBookCards(document.body);

    let frame = 0;
    const updateHiddenCards = () => {
      frame = 0;
      const currentY = window.scrollY;
      scrollingDown = currentY > previousY;
      previousY = currentY;
      const restoreBoundary = window.innerHeight * 1.5;
      document
        .querySelectorAll<HTMLElement>("[data-scroll-managed-book]")
        .forEach((card) => {
          const rect = card.getBoundingClientRect();
          if (scrollingDown && rect.bottom < -80) {
            card.classList.add("book-scroll-hidden");
          } else if (!scrollingDown && rect.bottom > -restoreBoundary) {
            card.classList.remove("book-scroll-hidden");
          }
        });
    };
    const onScroll = () => {
      if (bookVisibilityObserver) {
        const currentY = window.scrollY;
        scrollingDown = currentY > previousY;
        previousY = currentY;
      } else if (!frame) {
        frame = window.requestAnimationFrame(updateHiddenCards);
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    return () => {
      mutationObserver.disconnect();
      revealObserver?.disconnect();
      bookVisibilityObserver?.disconnect();
      window.removeEventListener("scroll", onScroll);
      if (frame) window.cancelAnimationFrame(frame);
      document
        .querySelectorAll(".book-scroll-hidden")
        .forEach((element) => element.classList.remove("book-scroll-hidden"));
    };
  }, []);

  return null;
}
