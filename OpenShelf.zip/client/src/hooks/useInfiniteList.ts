import { useCallback, useEffect, useRef, useState } from "react";

export interface PageResult<T> {
  items: T[];
  hasMore: boolean;
  total?: number;
}

// `removed` = how many already-loaded items the user has removed since the list
// was (re)started. Lists whose rows disappear server-side when removed (like
// Words Worth Keeping) use it to request the right offset, so no row is skipped.
export interface FetchContext {
  removed: number;
}

export type PageFetcher<T> = (page: number, context: FetchContext) => Promise<PageResult<T>>;

interface ListError {
  message: string;
  phase: "initial" | "more";
}

// Server-paginated list with "load the next page when the sentinel scrolls
// into view". It guards against the usual infinite-scroll problems:
//  - one request at a time (rapid scrolling cannot fire duplicates),
//  - responses from an outdated search/filter are ignored (generation check),
//  - items are de-duplicated by _id (new rows inserted while scrolling),
//  - after a failure it stops and waits for the user to press Retry,
//  - the observer is disconnected on unmount.
export function useInfiniteList<T extends { _id: string }>(
  fetchPage: PageFetcher<T>,
  resetKey: string
) {
  const [items, setItems] = useState<T[]>([]);
  const [total, setTotal] = useState<number | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [initialLoading, setInitialLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<ListError | null>(null);

  const fetchRef = useRef(fetchPage);
  fetchRef.current = fetchPage;

  const nextPage = useRef(1);
  const inFlight = useRef(false);
  const hasMoreRef = useRef(true);
  const generation = useRef(0);
  const removedCount = useRef(0);
  const removedIds = useRef<Set<string>>(new Set());
  const itemsRef = useRef<T[]>(items);
  itemsRef.current = items; // always the latest rendered list

  const load = useCallback(async (reset: boolean) => {
    if (reset) {
      generation.current += 1;
      nextPage.current = 1;
      removedCount.current = 0;
      removedIds.current = new Set();
      hasMoreRef.current = true;
      inFlight.current = false;
      setItems([]);
      setTotal(null);
      setHasMore(true);
    } else if (inFlight.current || !hasMoreRef.current) {
      return;
    }

    const gen = generation.current;
    const page = nextPage.current;
    inFlight.current = true;
    setError(null);
    if (page === 1) {
      setInitialLoading(true);
      setLoadingMore(false);
    } else {
      setLoadingMore(true);
    }

    try {
      const result = await fetchRef.current(page, { removed: removedCount.current });
      if (gen !== generation.current) return; // superseded by a newer search/filter
      setItems((prev) => {
        const seen = new Set(prev.map((item) => item._id));
        return [...prev, ...result.items.filter((item) => !seen.has(item._id))];
      });
      nextPage.current = page + 1;
      hasMoreRef.current = result.hasMore;
      setHasMore(result.hasMore);
      if (result.total !== undefined) setTotal(result.total);
    } catch (err: any) {
      if (gen !== generation.current) return;
      setError({
        message: err?.response?.data?.message || "Could not load this list. Please check your connection.",
        phase: page === 1 ? "initial" : "more",
      });
    } finally {
      if (gen === generation.current) {
        inFlight.current = false;
        setInitialLoading(false);
        setLoadingMore(false);
      }
    }
  }, []);

  // Start over whenever the search / filter / sort changes (and on mount).
  useEffect(() => {
    void load(true);
    return () => {
      generation.current += 1; // ignore anything still in flight after unmount / change
    };
  }, [resetKey, load]);

  const loadMore = useCallback(() => void load(false), [load]);

  const retry = useCallback(() => {
    void load(error?.phase === "initial");
  }, [error, load]);

  // Sentinel element: when it comes within 400px of the viewport, load more.
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const canLoadMore = hasMore && !error && !initialLoading && !loadingMore;

  useEffect(() => {
    const node = sentinelRef.current;
    if (!canLoadMore || !node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) loadMore();
      },
      { rootMargin: "400px 0px" }
    );
    observer.observe(node);
    return () => observer.disconnect();
    // Re-created after every batch so a sentinel that is still on screen
    // (short content, tall viewport) immediately requests the next batch.
  }, [canLoadMore, items.length, loadMore]);

  const updateItem = useCallback((updated: T) => {
    setItems((all) => all.map((item) => (item._id === updated._id ? updated : item)));
  }, []);

  const removeItem = useCallback((id: string) => {
    // Idempotent: a card and the shared like-event may both report the same removal.
    if (removedIds.current.has(id)) return;
    // A quote that is not in this list (never loaded) must not shift the offset.
    if (!itemsRef.current.some((item) => item._id === id)) return;
    removedIds.current.add(id);
    removedCount.current += 1;
    itemsRef.current = itemsRef.current.filter((item) => item._id !== id);
    setItems((all) => all.filter((item) => item._id !== id));
    setTotal((t) => (t === null ? t : Math.max(0, t - 1)));
  }, []);

  const mapItems = useCallback((fn: (item: T) => T) => {
    setItems((all) => all.map(fn));
  }, []);

  return {
    items,
    total,
    hasMore,
    initialLoading,
    loadingMore,
    error,
    retry,
    loadMore,
    sentinelRef,
    updateItem,
    removeItem,
    mapItems,
  };
}
