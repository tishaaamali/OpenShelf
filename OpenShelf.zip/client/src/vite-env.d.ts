/// <reference types="vite/client" />

// Bootstrap's carousel (JS only - the carousel CSS lives in index.css so it
// does not clash with Tailwind).
declare module "bootstrap/js/dist/carousel" {
  interface CarouselOptions {
    interval?: number | false;
    ride?: boolean | "carousel";
    pause?: "hover" | false;
    touch?: boolean;
    wrap?: boolean;
    keyboard?: boolean;
  }

  export default class Carousel {
    constructor(element: Element, options?: CarouselOptions);
    static getOrCreateInstance(
      element: Element,
      options?: CarouselOptions
    ): Carousel;
    next(): void;
    prev(): void;
    to(index: number): void;
    cycle(): void;
    pause(): void;
    dispose(): void;
  }
}
