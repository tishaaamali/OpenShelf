import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import api from "../api/axios";
import { User } from "../types";

export interface RegisterPayload {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string; // optional
  password: string;
}

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (payload: RegisterPayload) => Promise<void>;
  logout: () => void;
  refreshUser: (u: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("openshelf_user");
    if (stored) setUser(JSON.parse(stored));
    setLoading(false);
  }, []);

  function persist(token: string, u: User) {
    localStorage.setItem("openshelf_token", token);
    localStorage.setItem("openshelf_user", JSON.stringify(u));
    setUser(u);
  }

  async function login(email: string, password: string) {
    const { data } = await api.post("/auth/login", { email, password });
    persist(data.token, { ...data.user, id: data.user.id || data.user._id });
  }

  async function register(payload: RegisterPayload) {
    const { data } = await api.post("/auth/register", payload);
    persist(data.token, { ...data.user, id: data.user.id || data.user._id });
  }

  function logout() {
    localStorage.removeItem("openshelf_token");
    localStorage.removeItem("openshelf_user");
    setUser(null);
  }

  function refreshUser(partial: Partial<User>) {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...partial };
      localStorage.setItem("openshelf_user", JSON.stringify(next));
      return next;
    });
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
