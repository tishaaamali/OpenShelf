import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from "react";

// A themed replacement for the browser's window.confirm():
//   const confirm = useConfirm();
//   if (!(await confirm({ title: "Delete this quote?", confirmLabel: "Delete" }))) return;
// Cancel sits on the left, the confirm button on the right.

export interface ConfirmOptions {
  title: string;
  message?: string;
  confirmLabel?: string; // default "OK"
  cancelLabel?: string; // default "Cancel"
  danger?: boolean; // red confirm button (default true)
}

type ConfirmFn = (options: ConfirmOptions) => Promise<boolean>;

const ConfirmContext = createContext<ConfirmFn | null>(null);

export function useConfirm(): ConfirmFn {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error("useConfirm must be used inside <ConfirmProvider>");
  return ctx;
}

interface Pending extends ConfirmOptions {
  resolve: (value: boolean) => void;
}

export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [pending, setPending] = useState<Pending | null>(null);
  const cancelRef = useRef<HTMLButtonElement | null>(null);
  const returnFocusRef = useRef<HTMLElement | null>(null);

  const confirm = useCallback<ConfirmFn>(
    (options) =>
      new Promise<boolean>((resolve) => {
        returnFocusRef.current = document.activeElement as HTMLElement | null;
        // A second dialog while one is open cancels the first.
        setPending((current) => {
          current?.resolve(false);
          return { ...options, resolve };
        });
      }),
    []
  );

  const close = useCallback((result: boolean) => {
    setPending((current) => {
      current?.resolve(result);
      return null;
    });
    returnFocusRef.current?.focus?.();
  }, []);

  // Escape cancels; focus starts on Cancel so Enter never deletes by accident.
  useEffect(() => {
    if (!pending) return;
    cancelRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") close(false);
    };
    document.addEventListener("keydown", onKey);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [pending, close]);

  const danger = pending?.danger !== false;

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      {pending && (
        <div
          className="confirm-backdrop fixed inset-0 z-[200] flex items-center justify-center p-5"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) close(false);
          }}
        >
          <div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            aria-describedby={pending.message ? "confirm-message" : undefined}
            className="modal-panel confirm-panel w-full max-w-[400px] rounded-2xl p-6 shadow-2xl"
            style={{ backgroundColor: "rgb(var(--card))" }}
          >
            <h2 id="confirm-title" className="m-0 font-heading text-[18px] font-bold leading-snug">
              {pending.title}
            </h2>
            {pending.message && (
              <p id="confirm-message" className="mb-0 mt-2 text-[14px] leading-relaxed text-ink-600">
                {pending.message}
              </p>
            )}

            <div className="mt-6 flex justify-end gap-3">
              <button
                ref={cancelRef}
                type="button"
                onClick={() => close(false)}
                className="confirm-cancel rounded-full border border-line px-5 py-2.5 text-[14px] font-semibold"
              >
                {pending.cancelLabel || "Cancel"}
              </button>
              <button
                type="button"
                onClick={() => close(true)}
                className={`confirm-ok rounded-full px-6 py-2.5 text-[14px] font-bold text-white ${
                  danger ? "confirm-ok-danger" : "bg-primary"
                }`}
              >
                {pending.confirmLabel || "OK"}
              </button>
            </div>
          </div>
        </div>
      )}
    </ConfirmContext.Provider>
  );
}
