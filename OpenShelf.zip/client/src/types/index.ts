export type UserRole = "member" | "admin";

export interface User {
  id: string;

  name: string; // full name (first + last)

  firstName?: string;

  lastName?: string;

  email: string;

  phone?: string;

  role: UserRole;

  createdAt?: string;
}

export interface Copy {
  _id: string;

  barcode: string;

  shelf: string;

  condition: "New" | "Good" | "Fair" | "Damaged";

  status: "Available" | "Reserved" | "Borrowed" | "Damaged" | "Lost";

  borrowedBy?: string | null;

  borrowerName?: string | null;

  borrowDate?: string | null;

  dueDate?: string | null;
  reservedBy?: string | null;
  reservedUntil?: string | null;
}

export interface WaitlistEntry {
  _id: string;

  user: string;

  name: string;

  email: string;

  joinedAt: string;
}

export interface Book {
  _id: string;

  title: string;

  author: string;

  category: string;

  language: string;

  publisher: string;

  edition: string;

  year: number;

  isbn13: string;

  isbn10: string;

  coverImage?: string;

  format: "Hardcover" | "Paperback" | "eBook" | "Audio Book";

  status: "Available" | "Unavailable" | "Borrowed" | "Under Maintenance";

  description: string;

  nextReaderNote?: string;

  previewText?: string;

  rating: number;

  ratingCount: number;

  borrowCount: number;

  addedDate: string;

  copies: Copy[];

  waitlist: WaitlistEntry[];
}

export interface AccountSummary {
  profile: {
    name: string;

    firstName: string;

    lastName: string;

    email: string;

    phone: string;

    role: UserRole;

    since: string;
  };

  booksRead: number;

  borrowed: {
    bookId: string;
    title: string;
    dueDate: string;
    daysOverdue: number;
    fine: number;
  }[];

  waitlisted: {
    bookId: string;
    title: string;
    position: number;
    totalWaiting: number;
  }[];

  reviews: {
    bookId: string;
    title: string;
    author: string;
    rating: number;
    review: string;
    createdAt: string;
  }[];

  pendingFees: number;
}

export type RequestStatus = "Pending" | "Issued" | "Cancelled" | "Expired";

export interface BookRequest {
  _id: string;
  bookId: string;
  title: string;
  author: string;
  status: RequestStatus;
  requestedAt: string;
  expiresAt: string;
  issuedAt: string | null;
  token: string | null; // only present while Pending
}

export interface RequestLookup {
  requestId: string;
  status: RequestStatus;
  requestedAt: string;
  expiresAt: string;
  issuedAt: string | null;
  book: { id: string; title: string; author: string; availableCopies: number };
  member: { name: string; email: string };
  canIssue: boolean;
  reason: string;
}

export interface DueSoonItem {
  bookId: string;

  title: string;

  author?: string;
  coverImage?: string;
  isbn13?: string;
  isbn10?: string;

  borrowerName: string;

  dueDate: string;

  daysUntil: number;
}

export interface OverviewStats {
  totalTitles: number;

  totalCopies: number;

  available: number;

  borrowed: number;

  byCategory: Record<string, number>;

  byFormat: Record<string, number>;
}

export interface ActivityItem {
  _id: string;

  message: string;

  createdAt: string;
}

export interface PaginatedBooks {
  books: Book[];
  total: number; // books matching the current filters
  totalAll: number; // all books in the library
  page: number;
  limit: number;
  hasMore: boolean;
}

export interface CategoryCount {
  category: string;
  count: number;
}

/* ---------- Community features ---------- */

export interface DiscussionReply {
  _id: string;
  userName: string;
  mine: boolean;
  body: string;
  spoiler: boolean;
  createdAt: string;
}

export interface DiscussionThread {
  _id: string;
  bookId: string;
  bookTitle?: string;
  bookAuthor?: string;
  userName: string;
  mine: boolean;
  title: string;
  body: string;
  spoiler: boolean;
  pinned: boolean;
  locked: boolean;
  upvoteCount: number;
  upvoted: boolean;
  replyCount: number;
  lastActivityAt: string;
  createdAt: string;
  replies?: DiscussionReply[];
}

export interface ReadingListSummary {
  _id: string;
  name: string;
  description: string;
  isPublic: boolean;
  ownerName: string;
  mine: boolean;
  bookCount: number;
  followerCount: number;
  following: boolean;
  updatedAt: string;
  bookIds: string[];
  books?: {
    _id: string;
    title: string;
    author: string;
    category: string;
    coverImage?: string;
    isbn13: string;
    isbn10: string;
    rating: number;
    status: string;
  }[];
}

export interface ListMembership {
  _id: string;
  name: string;
  isPublic: boolean;
  bookCount: number;
  hasBook: boolean;
}

export interface NotificationItem {
  _id: string;
  message: string;
  link: string;
  read: boolean;
  createdAt: string;
}

/* ---------- Book Highlights ---------- */

export type QuoteKind = "literary" | "original" | "member";

export interface QuoteBook {
  _id: string;
  title: string;
  author: string;
  category: string;
  coverImage?: string;
  isbn13: string;
  isbn10: string;
  availableCount: number;
  availableCopyId: string | null;
  waitlistCount: number;
  onWaitlist: boolean;
  haveIt: boolean;
}

export interface QuoteItem {
  _id: string;
  text: string;
  author: string;
  sourceTitle: string;
  attribution: string;
  kind: QuoteKind;
  page: string;
  addedByName: string;
  mine: boolean;
  likeCount: number;
  liked: boolean;
  createdAt: string;
  // null when the source is not in the OpenShelf catalogue
  book: QuoteBook | null;
}

export interface QuotePage {
  quotes: QuoteItem[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}
