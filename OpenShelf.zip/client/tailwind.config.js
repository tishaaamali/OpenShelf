/** @type {import('tailwindcss').Config} */

// Theme-aware colors read their value from CSS variables (see src/index.css),
// so the same class (e.g. `bg-card`) switches automatically between light and dark.
const themed = (name) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        heading: ["Inter", "system-ui", "sans-serif"],
        body: ["Inter", "system-ui", "sans-serif"],
      },
      colors: {
        // Brand colors (same in both themes)
        navy: { 950: "#071B3A", 800: "#0B2E5B" },
        blue: { 600: "#0284C7", 500: "#38BDF8" },
        gold: { 500: "#F5A623", 600: "#DE8E0E" },

        // Theme-aware colors
        ink: { 900: themed("ink-900"), 600: themed("ink-600") },
        line: { DEFAULT: themed("line"), strong: themed("line-strong") },
        surface: themed("surface"),
        card: themed("card"),
        field: themed("field"),
        brand: themed("brand"),
        primary: { DEFAULT: themed("primary"), hover: themed("primary-hover") },

        success: { DEFAULT: "#2FA86A", bg: themed("success-bg") },
        warn: { DEFAULT: "#E0910F", bg: themed("warn-bg") },
        danger: { DEFAULT: "#E5484D", bg: themed("danger-bg") },
      },
    },
  },
  plugins: [],
};
